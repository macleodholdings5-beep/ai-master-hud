/* @ds-bundle: {"format":3,"namespace":"AIMasterHUDDesignSystem_8b9a29","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"ConnPill","sourcePath":"components/core/ConnPill.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Modal","sourcePath":"components/core/Modal.jsx"},{"name":"Panel","sourcePath":"components/core/Panel.jsx"},{"name":"StatusDot","sourcePath":"components/core/StatusDot.jsx"},{"name":"Tabs","sourcePath":"components/core/Tabs.jsx"},{"name":"AGENT_COLORS","sourcePath":"components/data/ChatLine.jsx"},{"name":"ChatLine","sourcePath":"components/data/ChatLine.jsx"},{"name":"CmdCard","sourcePath":"components/data/CmdCard.jsx"},{"name":"KVList","sourcePath":"components/data/KVList.jsx"},{"name":"SegBar","sourcePath":"components/data/SegBar.jsx"},{"name":"DEFAULT_STAGES","sourcePath":"components/data/StageFlow.jsx"},{"name":"StageFlow","sourcePath":"components/data/StageFlow.jsx"},{"name":"StatBar","sourcePath":"components/data/StatBar.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"SettingField","sourcePath":"components/forms/SettingField.jsx"},{"name":"SettingRow","sourcePath":"components/forms/SettingRow.jsx"},{"name":"TextArea","sourcePath":"components/forms/TextArea.jsx"},{"name":"AgentFace","sourcePath":"components/holo/AgentFace.jsx"},{"name":"HoloBlueprint","sourcePath":"components/holo/HoloBlueprint.jsx"},{"name":"RingGauge","sourcePath":"components/holo/RingGauge.jsx"},{"name":"Waveform","sourcePath":"components/holo/Waveform.jsx"}],"sourceHashes":{"components/core/Button.jsx":"5de9b0d22194","components/core/Chip.jsx":"4ea867f289bf","components/core/ConnPill.jsx":"cc6414d3d206","components/core/IconButton.jsx":"3269ef7b1494","components/core/Modal.jsx":"72980a892189","components/core/Panel.jsx":"51a383d7a9ac","components/core/StatusDot.jsx":"7b92d8c61190","components/core/Tabs.jsx":"4a5fc4a4211e","components/data/ChatLine.jsx":"7f001789397e","components/data/CmdCard.jsx":"a005ede83fe4","components/data/KVList.jsx":"65507144d8cb","components/data/SegBar.jsx":"d0a6396eca05","components/data/StageFlow.jsx":"acac60d78903","components/data/StatBar.jsx":"42b363ff3301","components/forms/Input.jsx":"711e76de6203","components/forms/Select.jsx":"f3078a3360ce","components/forms/SettingField.jsx":"d622434046aa","components/forms/SettingRow.jsx":"790b7870d6ee","components/forms/TextArea.jsx":"b2c817118a17","components/holo/AgentFace.jsx":"c52c1d0cdda1","components/holo/HoloBlueprint.jsx":"8cd171588f37","components/holo/RingGauge.jsx":"d5fa16dde339","components/holo/Waveform.jsx":"8f86c0a1c839","ui_kits/master_hud/AgentsTab.jsx":"247390266041","ui_kits/master_hud/ChatRoomTab.jsx":"a0181b7283a9","ui_kits/master_hud/HoloFace.jsx":"e235c8300d03","ui_kits/master_hud/HudData.jsx":"92ee95490029","ui_kits/master_hud/PipelineTab.jsx":"b0fd66149e93","ui_kits/master_hud/SettingsModal.jsx":"aacbd6047065","ui_kits/master_hud/VoiceTab.jsx":"9d812d2761ba","ui_kits/master_hud/WikiModal.jsx":"ffa4793901c1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AIMasterHUDDesignSystem_8b9a29 = window.AIMasterHUDDesignSystem_8b9a29 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = 'default',
  children,
  className = '',
  ...rest
}) {
  const v = variant === 'default' ? '' : ' ' + variant;
  return /*#__PURE__*/React.createElement("button", _extends({
    className: `hud-btn${v}${className ? ' ' + className : ''}`
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Chip({
  variant = 'solid',
  children,
  className = '',
  ...rest
}) {
  const v = variant === 'solid' ? '' : ' ' + variant;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `hud-chip${v}${className ? ' ' + className : ''}`
  }, rest), children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/ConnPill.jsx
try { (() => {
const GLYPHS = {
  connected: '●',
  connecting: '◌',
  offline: '○'
};
function ConnPill({
  status = 'offline',
  label
}) {
  const text = label || (status === 'connected' ? 'CONNECTED' : status === 'connecting' ? 'CONNECTING' : 'OFFLINE');
  return /*#__PURE__*/React.createElement("span", {
    className: `conn-pill ${status}`
  }, GLYPHS[status] || '○', " ", text);
}
Object.assign(__ds_scope, { ConnPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ConnPill.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function IconButton({
  glyph,
  label,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    className: `hud-icon-btn${className ? ' ' + className : ''}`,
    title: label,
    "aria-label": label
  }, rest), glyph);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Modal.jsx
try { (() => {
function Modal({
  title,
  onClose,
  children,
  width = 560
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-backdrop",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal hud-panel hud-corners",
    style: {
      width
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("button", {
    className: "hud-icon-btn",
    "aria-label": "Close",
    onClick: onClose
  }, "\u2715")), children));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Modal.jsx", error: String((e && e.message) || e) }); }

// components/core/Panel.jsx
try { (() => {
function Panel({
  title,
  corners = false,
  className = '',
  style,
  children
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: `hud-panel${corners ? ' hud-corners' : ''}${className ? ' ' + className : ''}`,
    style: style
  }, title ? /*#__PURE__*/React.createElement("h3", null, title) : null, children);
}
Object.assign(__ds_scope, { Panel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Panel.jsx", error: String((e && e.message) || e) }); }

// components/core/StatusDot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatusDot({
  status = 'offline',
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `status-dot ${status}${className ? ' ' + className : ''}`
  }, rest));
}
Object.assign(__ds_scope, { StatusDot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatusDot.jsx", error: String((e && e.message) || e) }); }

// components/core/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  active,
  onChange
}) {
  return /*#__PURE__*/React.createElement("nav", {
    className: "hud-tabs"
  }, items.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.id,
    className: `hud-tab${t.id === active ? ' active' : ''}`,
    onClick: () => onChange && onChange(t.id)
  }, t.label)));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/data/ChatLine.jsx
try { (() => {
const AGENT_COLORS = {
  Foreman: 'var(--green)',
  Scout: 'var(--cyan)',
  Draftsman: 'var(--yellow)',
  Builder: 'var(--orange)',
  Sentinel: 'var(--purple)',
  You: 'var(--white)'
};
function ChatLine({
  ts,
  agent,
  text,
  color,
  system = false,
  user = false
}) {
  const time = typeof ts === 'number' ? new Date(ts).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }) : ts;
  return /*#__PURE__*/React.createElement("div", {
    className: `chat-line${system ? ' system' : ''}${user ? ' user' : ''}`
  }, /*#__PURE__*/React.createElement("span", {
    className: "chat-ts"
  }, time), /*#__PURE__*/React.createElement("span", {
    className: "chat-agent",
    style: {
      color: color || AGENT_COLORS[agent] || 'var(--ice)'
    }
  }, agent), /*#__PURE__*/React.createElement("span", {
    className: "chat-text"
  }, text));
}
Object.assign(__ds_scope, { AGENT_COLORS, ChatLine });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ChatLine.jsx", error: String((e && e.message) || e) }); }

// components/data/CmdCard.jsx
try { (() => {
function CmdCard({
  command,
  status = 'running',
  output
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `cmd-card ${status}`
  }, /*#__PURE__*/React.createElement("code", null, "$ ", command), /*#__PURE__*/React.createElement("span", {
    className: "cmd-status"
  }, String(status).toUpperCase()), output ? /*#__PURE__*/React.createElement("pre", null, output) : null);
}
Object.assign(__ds_scope, { CmdCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/CmdCard.jsx", error: String((e && e.message) || e) }); }

// components/data/KVList.jsx
try { (() => {
function KVList({
  items = []
}) {
  return /*#__PURE__*/React.createElement("dl", {
    className: "kv"
  }, items.map(([k, v]) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: k
  }, /*#__PURE__*/React.createElement("dt", null, k), /*#__PURE__*/React.createElement("dd", null, v))));
}
Object.assign(__ds_scope, { KVList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/KVList.jsx", error: String((e && e.message) || e) }); }

// components/data/SegBar.jsx
try { (() => {
function SegBar({
  value = 0,
  color = 'white',
  label,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: style
  }, label ? /*#__PURE__*/React.createElement("div", {
    className: "hud-label",
    style: {
      marginBottom: 4
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    className: `seg-bar${color === 'cyan' ? ' cyan' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "seg-fill",
    style: {
      width: `${Math.min(100, Math.max(0, value))}%`
    }
  })));
}
Object.assign(__ds_scope, { SegBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/SegBar.jsx", error: String((e && e.message) || e) }); }

// components/data/StageFlow.jsx
try { (() => {
const DEFAULT_STAGES = ['Capture', 'Research', 'Planning', 'Review Gate', 'Build', 'Done'];
function stageClass(stage, status, index) {
  if (index < stage) return 'complete';
  if (index > stage) return '';
  return status === 'complete' ? 'complete' : status === 'waiting' ? 'waiting' : 'active';
}
function StageFlow({
  stages = DEFAULT_STAGES,
  current = 0,
  status = 'active',
  gateIndex = 3
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, stages.map((name, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: name
  }, /*#__PURE__*/React.createElement("div", {
    className: `stage-bubble ${stageClass(current, status, i)}`,
    title: name
  }, i === gateIndex ? '⭐ ' : '', name), i < stages.length - 1 && /*#__PURE__*/React.createElement("span", {
    className: "stage-arrow"
  }, "\u2192"))));
}
Object.assign(__ds_scope, { DEFAULT_STAGES, StageFlow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StageFlow.jsx", error: String((e && e.message) || e) }); }

// components/data/StatBar.jsx
try { (() => {
function StatBar({
  label,
  value,
  unit = '%',
  warn = 80,
  max = 250
}) {
  const pct = Math.min(100, unit === '%' ? value : value / max * 100);
  return /*#__PURE__*/React.createElement("div", {
    className: "stat-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "stat-label"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "stat-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: `stat-fill${value > warn ? ' hot' : ''}`,
    style: {
      width: `${pct}%`
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "stat-value"
  }, Math.round(value), unit));
}
Object.assign(__ds_scope, { StatBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatBar.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input(props) {
  return /*#__PURE__*/React.createElement("input", props);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  options = [],
  ...rest
}) {
  return /*#__PURE__*/React.createElement("select", rest, options.map(o => /*#__PURE__*/React.createElement("option", {
    key: String(o.value),
    value: o.value
  }, o.label)));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/SettingField.jsx
try { (() => {
function SettingField({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "hud-label"
  }, label), children);
}
Object.assign(__ds_scope, { SettingField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SettingField.jsx", error: String((e && e.message) || e) }); }

// components/forms/SettingRow.jsx
try { (() => {
function SettingRow({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 10,
      padding: '6px 0',
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", null, label), children);
}
Object.assign(__ds_scope, { SettingRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SettingRow.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextArea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TextArea(props) {
  return /*#__PURE__*/React.createElement("textarea", _extends({
    style: {
      minHeight: 60,
      resize: 'vertical',
      ...props.style
    }
  }, props));
}
Object.assign(__ds_scope, { TextArea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextArea.jsx", error: String((e && e.message) || e) }); }

// components/holo/AgentFace.jsx
try { (() => {
const {
  useEffect,
  useRef
} = React; // Matrix avatar — a 3D head rendered as a green particle point-cloud.
// Slow yaw rotation, blinking eyes, articulated mouth while speaking,
// glyph-rain backdrop and a scan sweep. Fully generative, no images.
const RAIN_GLYPHS = 'アイウエオカキクケコサシスセソタチツテト0123456789';
function buildHead() {
  let seed = 970421;
  const rnd = () => {
    seed = seed * 16807 % 2147483647;
    return seed / 2147483647;
  };
  const pts = [];

  // skull shell — sampled sphere, jaw taper, flattened face plane
  for (let i = 0; i < 1050; i++) {
    const th = Math.acos(2 * rnd() - 1);
    const ph = 2 * Math.PI * rnd();
    let x = Math.sin(th) * Math.cos(ph) * 0.80;
    let y = -Math.cos(th) * 1.02; // -1 crown … +1 chin
    let z = Math.sin(th) * Math.sin(ph) * 0.92;
    if (y > 0.25) {
      // taper toward the jaw
      const f = 1 - (y - 0.25) * 0.62;
      x *= f;
      z *= 1 - (y - 0.25) * 0.30;
    }
    if (z > 0.55) z = 0.55 + (z - 0.55) * 0.45; // flatten face plane
    pts.push({
      x,
      y,
      z,
      kind: 'skull',
      s: 1.5,
      a: 0.55 + rnd() * 0.45
    });
  }
  const feat = (x, y, z, kind, s = 2, a = 1) => pts.push({
    x,
    y,
    z,
    kind,
    s,
    a
  });
  for (const side of [-1, 1]) {
    // brows
    for (let i = 0; i <= 10; i++) {
      const f = i / 10;
      feat(side * (0.16 + f * 0.22), -0.28 - Math.sin(f * Math.PI) * 0.04, 0.60, 'brow', 1.8);
    }
    // eyes — iris ring + pupil
    const ex = side * 0.30,
      ey = -0.155;
    for (let i = 0; i < 14; i++) {
      const a = i / 14 * Math.PI * 2;
      feat(ex + Math.cos(a) * 0.075, ey + Math.sin(a) * 0.05, 0.585, 'eye', 1.7);
    }
    feat(ex, ey, 0.60, 'pupil', 2.6);
    // nostrils
    feat(side * 0.085, 0.255, 0.64, 'nose', 1.8);
    // ears
    for (let i = 0; i < 14; i++) {
      feat(side * (0.76 + rnd() * 0.06), -0.02 + (rnd() - 0.5) * 0.30, (rnd() - 0.5) * 0.16, 'skull', 1.4, 0.7);
    }
    // cheek lines
    for (let i = 0; i < 8; i++) {
      const f = i / 8;
      feat(side * (0.42 - f * 0.10), 0.10 + f * 0.26, 0.50 - f * 0.06, 'skull', 1.3, 0.5);
    }
  }
  // nose ridge
  for (let i = 0; i <= 8; i++) {
    const f = i / 8;
    feat(0, -0.08 + f * 0.30, 0.70 + Math.sin(f * Math.PI) * 0.10, 'nose', 1.8);
  }
  // lips — animated while speaking
  for (let i = 0; i <= 18; i++) {
    const f = i / 18;
    const x = -0.27 + f * 0.54;
    const z = 0.64 - Math.abs(x) * 0.30;
    feat(x, 0.455 - Math.sin(f * Math.PI) * 0.015, z, 'lipU', 1.9);
    feat(x, 0.505 + Math.sin(f * Math.PI) * 0.02, z, 'lipL', 1.9);
  }
  // chin
  for (let i = 0; i < 6; i++) feat((rnd() - 0.5) * 0.16, 0.72 + rnd() * 0.06, 0.46, 'skull', 1.4, 0.7);
  return pts;
}
function AgentFace({
  speaking = false,
  status = 'online',
  width = 420,
  height = 320,
  bare = false
}) {
  const canvasRef = useRef(null);
  const speakingRef = useRef(speaking);
  speakingRef.current = speaking;
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pts = buildHead();
    const w = canvas.width,
      h = canvas.height;

    // glyph-rain columns
    const cols = Math.max(8, Math.floor(w / 16));
    const rain = Array.from({
      length: cols
    }, (_, i) => ({
      x: i * 16 + 4,
      y: Math.random() * h,
      v: 0.8 + Math.random() * 1.4
    }));
    let raf,
      t = 0,
      blink = 0;
    function draw() {
      t += 1;
      if (blink <= 0 && Math.random() < 0.006) blink = 9;
      if (blink > 0) blink -= 1;
      if (bare) {
        ctx.clearRect(0, 0, w, h);
      } else {
        ctx.fillStyle = '#020806';
        ctx.fillRect(0, 0, w, h);
      }

      // matrix rain
      ctx.font = '10px "SF Mono", "Fira Code", Menlo, monospace';
      for (const c of rain) {
        c.y = (c.y + c.v) % (h + 30);
        ctx.fillStyle = 'rgba(57, 255, 122, 0.13)';
        ctx.fillText(RAIN_GLYPHS[(Math.floor(c.y / 12) + Math.floor(c.x)) % RAIN_GLYPHS.length], c.x, c.y);
        ctx.fillStyle = 'rgba(57, 255, 122, 0.05)';
        ctx.fillText(RAIN_GLYPHS[(Math.floor(c.y / 12) + 3 + Math.floor(c.x)) % RAIN_GLYPHS.length], c.x, c.y - 12);
      }

      // head
      const yaw = Math.sin(t * 0.0045) * 0.48;
      const cy = h * 0.52,
        cx = w / 2,
        scale = h * 0.40;
      const cosY = Math.cos(yaw),
        sinY = Math.sin(yaw);
      const amp = speakingRef.current ? 0.25 + Math.abs(Math.sin(t * 0.22)) * 0.75 : 0.05;
      for (const p of pts) {
        const X = p.x * cosY + p.z * sinY;
        const Z = -p.x * sinY + p.z * cosY;
        let Y = p.y;
        if (p.kind === 'lipL') Y += amp * 0.10 + (speakingRef.current ? (Math.random() - 0.5) * 0.012 : 0);
        if (p.kind === 'lipU') Y -= amp * 0.02;
        const depth = (Z + 1) / 2;
        let alpha = p.a * (0.08 + 0.9 * depth * depth);
        if ((p.kind === 'eye' || p.kind === 'pupil') && blink > 0) alpha *= 0.12;
        const isFeature = p.kind !== 'skull';
        ctx.fillStyle = isFeature ? `rgba(170, 255, 200, ${Math.min(1, alpha * 1.3)})` : `rgba(57, 255, 122, ${alpha})`;
        const sz = p.s * (0.6 + depth * 0.8);
        ctx.fillRect(cx + X * scale - sz / 2, cy + Y * scale - sz / 2, sz, sz);
      }

      // scan sweep
      const ly = t * 0.7 % (h * 1.7);
      if (ly < h) {
        const g = ctx.createLinearGradient(0, ly - 10, 0, ly + 10);
        g.addColorStop(0, 'rgba(57, 255, 122, 0)');
        g.addColorStop(0.5, 'rgba(57, 255, 122, 0.06)');
        g.addColorStop(1, 'rgba(57, 255, 122, 0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, ly - 10, w, 20);
      }

      // corner status
      ctx.font = '9px "SF Mono", "Fira Code", Menlo, monospace';
      ctx.fillStyle = 'rgba(57, 255, 122, 0.5)';
      ctx.fillText(speakingRef.current ? '● TRANSMITTING' : '● ' + String(status).toUpperCase(), 10, h - 10);
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, [status, bare]);
  if (bare) {
    return /*#__PURE__*/React.createElement("canvas", {
      ref: canvasRef,
      width: width,
      height: height,
      style: {
        display: 'block'
      }
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: `agent-face ${status}`,
    style: {
      border: '1px solid var(--border)',
      borderRadius: 2,
      overflow: 'hidden',
      boxShadow: 'var(--glow-green-frame)',
      width
    }
  }, /*#__PURE__*/React.createElement("canvas", {
    ref: canvasRef,
    width: width,
    height: height,
    style: {
      display: 'block'
    }
  }));
}
Object.assign(__ds_scope, { AgentFace });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/holo/AgentFace.jsx", error: String((e && e.message) || e) }); }

// components/holo/HoloBlueprint.jsx
try { (() => {
const {
  useEffect,
  useRef,
  useState
} = React; // Holographic exploded blueprint — modeled on the "ANALYSING DATA / REACTOR CORE"
// reference: dense particle-swarm ring assemblies along a diagonal axis, copper
// wound coils between them, a hot orange particle core, teal label boxes with
// white tracked type, and faint micro-data columns. Hover/click selects a part.
const HEX = '0123456789ABCDEF';
function makeRng(seed) {
  let s = seed;
  return () => {
    s = s * 16807 % 2147483647;
    return s / 2147483647;
  };
}
function buildGeometry(parts, coreIndex, w, h) {
  const rnd = makeRng(48271);
  const n = Math.max(parts.length, 1);
  const core = coreIndex >= 0 ? coreIndex : Math.floor((n - 1) / 2);
  const x0 = w * 0.15,
    y0 = h * 0.68,
    x1 = w * 0.85,
    y1 = h * 0.26;
  const axis = Math.atan2(y1 - y0, x1 - x0);
  const baseR = Math.min(w / (n * 2.5), h * 0.30);
  const clusters = [];
  for (let i = 0; i < n; i++) {
    const f = n === 1 ? 0.5 : i / (n - 1);
    const cx = x0 + (x1 - x0) * f,
      cy = y0 + (y1 - y0) * f;
    const isCore = i === core;
    const R = baseR * (isCore ? 0.72 : 0.86 + 0.18 * Math.sin(i * 2.1));
    const particles = [];
    if (isCore) {
      // hot particle ball — orange/white/teal
      for (let p = 0; p < 420; p++) {
        const r = (rnd() + rnd() + rnd()) / 3 * R * 0.95;
        const roll = rnd();
        particles.push({
          ang: rnd() * Math.PI * 2,
          r,
          ecc: 0.8 + rnd() * 0.2,
          speed: (rnd() - 0.5) * 0.006,
          color: roll < 0.5 ? '255,154,74' : roll < 0.72 ? '255,220,180' : roll < 0.88 ? '255,255,255' : '120,220,230',
          a: 0.35 + rnd() * 0.6,
          s: 0.8 + rnd() * 1.6
        });
      }
    } else {
      // 5 nested particle rings + 2 satellite stubs
      for (let k = 0; k < 5; k++) {
        const rf = R * (0.34 + k * 0.165);
        const count = Math.round(rf * 1.5);
        const dir = k % 2 ? 1 : -1;
        const speed = dir * (0.0022 + rnd() * 0.002);
        for (let p = 0; p < count; p++) {
          const roll = rnd();
          particles.push({
            ang: rnd() * Math.PI * 2,
            r: rf * (1 + (rnd() - 0.5) * 0.06),
            ecc: 1,
            speed,
            color: roll < 0.74 ? '120,220,230' : roll < 0.90 ? '58,214,255' : '255,154,74',
            a: 0.25 + rnd() * 0.65,
            s: 0.8 + rnd() * 1.3
          });
        }
      }
      for (const off of [-0.62, 0.62]) {
        for (let p = 0; p < 70; p++) {
          const roll = rnd();
          particles.push({
            ang: rnd() * Math.PI * 2,
            r: R * 0.30 * (1 + (rnd() - 0.5) * 0.1),
            ecc: 1,
            speed: 0.004 * (off > 0 ? -1 : 1),
            axOff: R * off,
            color: roll < 0.8 ? '120,220,230' : '255,154,74',
            a: 0.25 + rnd() * 0.5,
            s: 0.7 + rnd() * 1.1
          });
        }
      }
    }
    clusters.push({
      cx,
      cy,
      R,
      isCore,
      particles
    });
  }

  // copper coils between adjacent clusters
  const coils = [];
  for (let i = 0; i < n - 1; i++) {
    const a = clusters[i],
      b = clusters[i + 1];
    coils.push({
      x: (a.cx + b.cx) / 2,
      y: (a.cy + b.cy) / 2,
      r: baseR * 0.16
    });
  }

  // background furniture
  const speckles = Array.from({
    length: 90
  }, () => ({
    x: rnd() * w,
    y: rnd() * h,
    a: 0.03 + rnd() * 0.06
  }));
  const hexCol = rows => Array.from({
    length: rows
  }, () => Array.from({
    length: 9
  }, () => HEX[Math.floor(rnd() * 16)]).join(''));
  const dataCols = [{
    x: 8,
    y: 16,
    rows: hexCol(7)
  }, {
    x: w - 66,
    y: h * 0.55,
    rows: hexCol(6)
  }];
  return {
    clusters,
    coils,
    axis,
    baseR,
    speckles,
    dataCols,
    core
  };
}
function HoloBlueprint({
  parts = [],
  coreIndex = -1,
  selected = -1,
  onSelectPart,
  width = 820,
  height = 440
}) {
  const canvasRef = useRef(null);
  const [hover, setHover] = useState(-1);
  const stateRef = useRef({
    selected,
    hover
  });
  stateRef.current = {
    selected,
    hover
  };
  const sig = parts.map(p => p.label).join('|') + ':' + coreIndex;
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const w = canvas.width,
      h = canvas.height;
    const G = buildGeometry(parts, coreIndex, w, h);
    let raf,
      t = 0;
    const mono = (px, weight) => `${weight ? weight + ' ' : ''}${px}px "SF Mono", "Fira Code", Menlo, monospace`;
    function draw() {
      t += 1;
      const {
        selected: SEL,
        hover: HOV
      } = stateRef.current;
      ctx.clearRect(0, 0, w, h);

      // speckle + data columns
      for (const s of G.speckles) {
        ctx.fillStyle = `rgba(120, 220, 230, ${s.a})`;
        ctx.fillRect(s.x, s.y, 1.4, 1.4);
      }
      ctx.font = mono(7);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
      ctx.fillStyle = 'rgba(120, 220, 230, 0.18)';
      for (const col of G.dataCols) {
        col.rows.forEach((r, i) => ctx.fillText(r, col.x, col.y + i * 10));
      }
      ctx.fillStyle = 'rgba(120, 220, 230, 0.25)';
      ctx.fillText('// RETURN CODE', 8, G.dataCols[0].y + G.dataCols[0].rows.length * 10 + 8);

      // axis line
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.18)';
      ctx.setLineDash([2, 7]);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(w * 0.05, h * 0.74);
      ctx.lineTo(w * 0.95, h * 0.18);
      ctx.stroke();
      ctx.setLineDash([]);

      // coils — copper wound cylinders along the axis
      for (const coil of G.coils) {
        for (let j = -4; j <= 4; j++) {
          const ox = Math.cos(G.axis) * j * coil.r * 0.55;
          const oy = Math.sin(G.axis) * j * coil.r * 0.55;
          ctx.save();
          ctx.translate(coil.x + ox, coil.y + oy);
          ctx.rotate(G.axis + Math.PI / 2);
          ctx.scale(0.36, 1);
          ctx.strokeStyle = `rgba(255, 154, 74, ${0.5 - Math.abs(j) * 0.04})`;
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(0, 0, coil.r, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }
      }

      // clusters
      G.clusters.forEach((c, i) => {
        const hot = i === SEL || i === HOV;

        // dashed structural ellipses
        if (!c.isCore) {
          for (let k = 0; k < 2; k++) {
            ctx.save();
            ctx.translate(c.cx, c.cy);
            ctx.rotate(G.axis + Math.PI / 2);
            ctx.scale(0.36, 1);
            ctx.strokeStyle = `rgba(58, 214, 255, ${hot ? 0.5 : 0.22})`;
            ctx.lineWidth = 1;
            ctx.setLineDash(k ? [4, 6] : [12, 5]);
            ctx.lineDashOffset = t * (k ? -0.3 : 0.2);
            ctx.beginPath();
            ctx.arc(0, 0, c.R * (k ? 1.04 : 0.70), 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
          }
        } else {
          // core glow
          const g = ctx.createRadialGradient(c.cx, c.cy, 0, c.cx, c.cy, c.R * 1.4);
          g.addColorStop(0, 'rgba(255, 154, 74, 0.22)');
          g.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = g;
          ctx.fillRect(c.cx - c.R * 1.6, c.cy - c.R * 1.6, c.R * 3.2, c.R * 3.2);
        }

        // particle swarm
        ctx.save();
        ctx.translate(c.cx, c.cy);
        ctx.rotate(G.axis + Math.PI / 2);
        for (const p of c.particles) {
          const ang = p.ang + t * p.speed;
          const px = Math.cos(ang) * p.r * 0.36 * (p.ecc || 1);
          const py = Math.sin(ang) * p.r + (p.axOff ? 0 : 0);
          const ox = p.axOff ? p.axOff * 0.36 : 0;
          const alpha = p.a * (hot ? 1.25 : 1) * (0.75 + 0.25 * Math.sin(ang));
          ctx.fillStyle = `rgba(${p.color}, ${Math.min(1, Math.max(0.05, alpha))})`;
          ctx.fillRect(px + ox - p.s / 2, py - p.s / 2, p.s, p.s);
        }
        ctx.restore();
      });

      // callouts — teal label boxes, reference style
      ctx.textBaseline = 'middle';
      G.clusters.forEach((c, i) => {
        const hot = i === stateRef.current.selected || i === stateRef.current.hover;
        const label = (parts[i] && parts[i].label ? parts[i].label : `PART ${i + 1}`).toUpperCase();
        const detail = parts[i] && parts[i].detail ? String(parts[i].detail).toUpperCase() : '';
        const up = i % 2 === 0;
        const ly = up ? c.cy - c.R - 30 : c.cy + c.R + 30;
        ctx.strokeStyle = `rgba(58, 214, 255, ${hot ? 0.8 : 0.3})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(c.cx, up ? c.cy - c.R * 0.9 : c.cy + c.R * 0.9);
        ctx.lineTo(c.cx, ly);
        ctx.stroke();
        ctx.font = mono(10, 700);
        const tw = ctx.measureText(label).width;
        const bw = tw + 16,
          bh = 18;
        const bx = Math.min(Math.max(c.cx - 8, 4), w - bw - 4);
        const by = up ? ly - bh : ly;
        ctx.fillStyle = hot ? 'rgba(20, 64, 78, 0.95)' : 'rgba(14, 42, 52, 0.92)';
        ctx.fillRect(bx, by, bw, bh);
        ctx.strokeStyle = `rgba(58, 214, 255, ${hot ? 0.95 : 0.4})`;
        ctx.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
        ctx.fillStyle = hot ? '#ffffff' : '#cfeefb';
        ctx.textAlign = 'left';
        ctx.fillText(label, bx + 8, by + bh / 2 + 0.5);
        if (detail) {
          ctx.font = mono(8);
          ctx.fillStyle = 'rgba(122, 200, 215, 0.6)';
          ctx.fillText(detail, bx + 8, up ? by - 7 : by + bh + 8);
        }
      });

      // corner ticks
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.4)';
      ctx.lineWidth = 1;
      for (const [cx2, cy2, dx, dy] of [[6, 6, 1, 1], [w - 6, 6, -1, 1], [6, h - 6, 1, -1], [w - 6, h - 6, -1, -1]]) {
        ctx.beginPath();
        ctx.moveTo(cx2 + dx * 8, cy2);
        ctx.lineTo(cx2, cy2);
        ctx.lineTo(cx2, cy2 + dy * 8);
        ctx.stroke();
      }
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig, width, height]);
  function partAt(e) {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width * canvas.width;
    const y = (e.clientY - rect.top) / rect.height * canvas.height;
    const n = Math.max(parts.length, 1);
    const x0 = canvas.width * 0.15,
      y0 = canvas.height * 0.68;
    const x1 = canvas.width * 0.85,
      y1 = canvas.height * 0.26;
    const baseR = Math.min(canvas.width / (n * 2.5), canvas.height * 0.30);
    let best = -1,
      bestD = Infinity;
    for (let i = 0; i < n; i++) {
      const f = n === 1 ? 0.5 : i / (n - 1);
      const cx = x0 + (x1 - x0) * f,
        cy = y0 + (y1 - y0) * f;
      const d = Math.hypot(x - cx, y - cy);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    return bestD < baseR * 1.25 ? best : -1;
  }
  return /*#__PURE__*/React.createElement("canvas", {
    ref: canvasRef,
    width: width,
    height: height,
    style: {
      display: 'block',
      maxWidth: '100%',
      cursor: hover >= 0 ? 'pointer' : 'default'
    },
    onMouseMove: e => setHover(partAt(e)),
    onMouseLeave: () => setHover(-1),
    onClick: e => {
      const i = partAt(e);
      if (i >= 0 && onSelectPart) onSelectPart(i);
    }
  });
}
Object.assign(__ds_scope, { HoloBlueprint });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/holo/HoloBlueprint.jsx", error: String((e && e.message) || e) }); }

// components/holo/RingGauge.jsx
try { (() => {
const {
  useEffect,
  useRef
} = React; // Circular gauge with a hot number center — the "167" dial from the reference HUD.
function RingGauge({
  value = 0,
  label,
  size = 120,
  color = '#3ad6ff'
}) {
  const canvasRef = useRef(null);
  const valueRef = useRef(value);
  valueRef.current = value;
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let raf;
    let t = 0;
    let shown = 0;
    function draw() {
      t += 1;
      shown += (valueRef.current - shown) * 0.08;
      const s = canvas.width;
      const c = s / 2;
      const r = s / 2 - 8;
      ctx.clearRect(0, 0, s, s);

      // track
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.15)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(c, c, r, 0, Math.PI * 2);
      ctx.stroke();

      // value arc, from 12 o'clock
      const a0 = -Math.PI / 2;
      ctx.strokeStyle = color;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(c, c, r, a0, a0 + Math.PI * 2 * shown / 100);
      ctx.stroke();

      // rotating tick
      const ta = t * 0.01;
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(c, c, r - 6, ta, ta + 0.5);
      ctx.stroke();

      // center number
      ctx.fillStyle = '#eaf7ff';
      ctx.font = `700 ${Math.round(s / 4.5)}px "SF Mono", "Fira Code", Menlo, monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(58, 214, 255, 0.55)';
      ctx.shadowBlur = 8;
      ctx.fillText(String(Math.round(shown)), c, c);
      ctx.shadowBlur = 0;
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, [color]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("canvas", {
    ref: canvasRef,
    width: size,
    height: size,
    style: {
      display: 'block'
    }
  }), label ? /*#__PURE__*/React.createElement("span", {
    className: "hud-label"
  }, label) : null);
}
Object.assign(__ds_scope, { RingGauge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/holo/RingGauge.jsx", error: String((e && e.message) || e) }); }

// components/holo/Waveform.jsx
try { (() => {
const {
  useEffect,
  useRef
} = React; // Animated waveform strip: green when user speaks, cyan when agent responds.
function Waveform({
  userSpeaking = false,
  agentSpeaking = false,
  width = 600,
  height = 56
}) {
  const canvasRef = useRef(null);
  const flags = useRef({
    userSpeaking,
    agentSpeaking
  });
  flags.current = {
    userSpeaking,
    agentSpeaking
  };
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let raf;
    let t = 0;
    function draw() {
      t += 1;
      const {
        width: w,
        height: h
      } = canvas;
      ctx.clearRect(0, 0, w, h);
      const active = flags.current.userSpeaking || flags.current.agentSpeaking;
      const amp = active ? h * 0.35 : h * 0.05;
      ctx.strokeStyle = flags.current.agentSpeaking ? '#3ad6ff' : '#39ff7a';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let x = 0; x < w; x += 3) {
        const y = h / 2 + Math.sin(x * 0.05 + t * 0.2) * amp * Math.sin(x * 0.011 + t * 0.07) + (active ? (Math.random() - 0.5) * 4 : 0);
        x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke();
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("canvas", {
    ref: canvasRef,
    width: width,
    height: height,
    style: {
      display: 'block',
      background: 'var(--inset)',
      borderRadius: 2
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "hud-label",
    style: {
      position: 'absolute',
      top: 4,
      right: 8,
      fontSize: 9,
      whiteSpace: 'nowrap'
    }
  }, agentSpeaking ? 'AGENT SPEAKING' : userSpeaking ? 'LISTENING — YOU' : 'STANDBY'));
}
Object.assign(__ds_scope, { Waveform });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/holo/Waveform.jsx", error: String((e && e.message) || e) }); }

// ui_kits/master_hud/AgentsTab.jsx
try { (() => {
// Agents tab — roster, detail, per-agent settings.
const {
  Panel: AgPanel,
  Button: AgButton,
  StatusDot: AgDot,
  Select: AgSelect,
  SettingRow: AgRow,
  KVList: AgKV
} = window.AIMasterHUDDesignSystem_8b9a29;
function AgentsTab() {
  const [agents, setAgents] = React.useState(window.HudData.SEED_AGENTS);
  const [activeId, setActiveId] = React.useState('foreman');
  const agent = agents.find(a => a.id === activeId) || agents[0];
  function update(id, patch) {
    setAgents(list => list.map(a => a.id === id ? {
      ...a,
      ...patch
    } : a));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '220px minmax(0, 1fr) 320px',
      gap: 14,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(AgPanel, {
    title: "Agents",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, agents.map(a => /*#__PURE__*/React.createElement("button", {
    key: a.id,
    className: `hud-tab${a.id === agent.id ? ' active' : ''}`,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      textAlign: 'left',
      textTransform: 'none',
      letterSpacing: 0,
      fontSize: 13
    },
    onClick: () => setActiveId(a.id)
  }, /*#__PURE__*/React.createElement(AgDot, {
    status: a.status
  }), a.name)), /*#__PURE__*/React.createElement("hr", {
    className: "hud-rule"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      fontSize: 10,
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(AgDot, {
    status: "online"
  }), " idle"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(AgDot, {
    status: "processing"
  }), " processing"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(AgDot, {
    status: "warning"
  }), " warning"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(AgDot, {
    status: "offline"
  }), " offline"))), /*#__PURE__*/React.createElement(AgPanel, {
    corners: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      color: 'var(--cyan)',
      letterSpacing: 2,
      fontSize: 18
    }
  }, agent.name), /*#__PURE__*/React.createElement(AgDot, {
    status: agent.status
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--muted)',
      fontSize: 12
    }
  }, agent.description), /*#__PURE__*/React.createElement(AgKV, {
    items: [['Current task', agent.task], ['Model', agent.model], ['Provider', agent.provider], ['Reports to', agent.parent ? (agents.find(a => a.id === agent.parent) || {}).name : '— (foreman)']]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(AgButton, {
    onClick: () => update(agent.id, {
      status: 'processing',
      task: 'Restarting…'
    })
  }, "\u21BB Restart"), /*#__PURE__*/React.createElement(AgButton, {
    onClick: () => setActiveId(agent.id)
  }, "\u2605 Set active"), /*#__PURE__*/React.createElement(AgButton, {
    onClick: () => alert(`Logs for ${agent.name} — connect a gateway to stream logs.`)
  }, "\u2630 View logs"))), /*#__PURE__*/React.createElement(AgPanel, {
    title: `Settings — ${agent.name}`
  }, /*#__PURE__*/React.createElement(AgRow, {
    label: "Voice"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: agent.voiceEnabled,
    onChange: e => update(agent.id, {
      voiceEnabled: e.target.checked
    })
  })), /*#__PURE__*/React.createElement(AgRow, {
    label: "Stability"
  }, /*#__PURE__*/React.createElement(AgSelect, {
    value: agent.stability,
    onChange: e => update(agent.id, {
      stability: Number(e.target.value)
    }),
    options: [{
      value: 0,
      label: '0.0 — expressive'
    }, {
      value: 0.5,
      label: '0.5 — balanced'
    }, {
      value: 1,
      label: '1.0 — stable'
    }]
  })), /*#__PURE__*/React.createElement(AgRow, {
    label: "Latency tier"
  }, /*#__PURE__*/React.createElement(AgSelect, {
    value: agent.latencyTier,
    onChange: e => update(agent.id, {
      latencyTier: Number(e.target.value)
    }),
    options: [1, 2, 3, 4].map(t => ({
      value: t,
      label: `tier ${t}`
    }))
  })), /*#__PURE__*/React.createElement(AgRow, {
    label: "Context window"
  }, /*#__PURE__*/React.createElement(AgSelect, {
    value: agent.contextWindow,
    onChange: e => update(agent.id, {
      contextWindow: Number(e.target.value)
    }),
    options: [{
      value: 100000,
      label: '100k'
    }, {
      value: 200000,
      label: '200k'
    }, {
      value: 500000,
      label: '500k'
    }]
  })), /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: '14px 0 6px',
      fontSize: 10,
      letterSpacing: 2,
      color: 'var(--muted)'
    }
  }, "SYSTEM PROMPT (READ-ONLY)"), /*#__PURE__*/React.createElement("pre", {
    style: {
      fontSize: 11,
      color: 'var(--muted)',
      maxHeight: 180,
      overflowY: 'auto',
      margin: 0
    }
  }, agent.systemPrompt)));
}
window.AgentsTab = AgentsTab;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/master_hud/AgentsTab.jsx", error: String((e && e.message) || e) }); }

// ui_kits/master_hud/ChatRoomTab.jsx
try { (() => {
// Chat Room tab — foreman banner, agent-to-agent log, command input, hierarchy.
const {
  Panel: CrPanel,
  Button: CrButton,
  StatusDot: CrDot,
  Input: CrInput,
  ChatLine: CrLine,
  AGENT_COLORS: CR_COLORS
} = window.AIMasterHUDDesignSystem_8b9a29;
function CrHierarchyNode({
  agent,
  agents,
  depth
}) {
  const children = agents.filter(a => a.parent === agent.id);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingLeft: depth * 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 0'
    }
  }, /*#__PURE__*/React.createElement(CrDot, {
    status: agent.status
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: CR_COLORS[agent.name] || 'var(--ice)'
    }
  }, agent.name)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--muted)',
      paddingLeft: 16
    }
  }, agent.task), children.map(c => /*#__PURE__*/React.createElement(CrHierarchyNode, {
    key: c.id,
    agent: c,
    agents: agents,
    depth: depth + 1
  })));
}
function ChatRoomTab() {
  const [messages, setMessages] = React.useState(window.HudData.SEED_CHAT);
  const [input, setInput] = React.useState('');
  const logRef = React.useRef(null);
  const agents = window.HudData.SEED_AGENTS;
  const foreman = agents.find(a => !a.parent);
  React.useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [messages]);
  function submit(e) {
    e.preventDefault();
    const text = input.trim();
    if (!text) return;
    setInput('');
    const now = Date.now();
    setMessages(m => [...m, {
      id: now,
      agent: 'You',
      text,
      ts: now,
      user: true
    }]);
    setTimeout(() => {
      setMessages(m => [...m, {
        id: now + 1,
        agent: 'Foreman',
        text: `Acknowledged. Delegating: "${text}".`,
        ts: Date.now()
      }, {
        id: now + 2,
        agent: 'System',
        text: `Task assigned: ${text} → Scout.`,
        ts: Date.now(),
        system: true
      }]);
    }, 700);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0, 1fr) 280px',
      gap: 14,
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(CrPanel, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      letterSpacing: 2,
      color: 'var(--muted)'
    }
  }, "FOREMAN"), /*#__PURE__*/React.createElement(CrDot, {
    status: foreman.status
  }), /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--green)'
    }
  }, foreman.name), /*#__PURE__*/React.createElement("span", {
    className: "muted small"
  }, foreman.task)), /*#__PURE__*/React.createElement("div", {
    className: "hud-panel",
    ref: logRef,
    style: {
      flex: 1,
      overflowY: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 5
    }
  }, messages.map(m => /*#__PURE__*/React.createElement(CrLine, {
    key: m.id,
    ts: m.ts,
    agent: m.agent,
    text: m.text,
    system: m.system,
    user: m.user
  }))), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(CrInput, {
    value: input,
    onChange: e => setInput(e.target.value),
    placeholder: "Command the team\u2026 e.g. \"tell the team to research X\"",
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(CrButton, {
    type: "submit"
  }, "Send"))), /*#__PURE__*/React.createElement(CrPanel, {
    title: "Hierarchy",
    corners: true
  }, /*#__PURE__*/React.createElement(CrHierarchyNode, {
    agent: foreman,
    agents: agents,
    depth: 0
  })));
}
window.ChatRoomTab = ChatRoomTab;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/master_hud/ChatRoomTab.jsx", error: String((e && e.message) || e) }); }

// ui_kits/master_hud/HoloFace.jsx
try { (() => {
// HoloFace — original holographic woman, hand-drawn vector portrait rendered
// as a blue hologram: bezier line-art face, luminous skin shading, scanline
// raster, glitch slices, blink + articulated mouth. Plus RingDial, PlexusBG,
// MiniRing instruments. All canvas-generative; shared via window.
(function () {
  // ================= HoloFace =================
  function HoloFace({
    speaking = false,
    width = 310,
    height = 310
  }) {
    const ref = React.useRef(null);
    const spk = React.useRef(speaking);
    spk.current = speaking;
    React.useEffect(() => {
      const canvas = ref.current,
        ctx = canvas.getContext('2d');
      const S = canvas.width;
      const off = document.createElement('canvas');
      off.width = S;
      off.height = S;
      const o = off.getContext('2d');
      const sc = S * 0.55,
        cx = S / 2,
        cy0 = S * 0.37;
      let raf,
        t = 0,
        blink = 0,
        glitch = 0,
        gShift = 0,
        gY = 0;
      const X = x => cx + x * sc;
      let cy = cy0;
      const Y = y => cy + y * sc;
      function strokePath(pts, color, lw) {
        o.strokeStyle = color;
        o.lineWidth = lw;
        o.lineCap = 'round';
        o.beginPath();
        o.moveTo(X(pts[0][0]), Y(pts[0][1]));
        for (let i = 1; i < pts.length; i += 3) {
          o.bezierCurveTo(X(pts[i][0]), Y(pts[i][1]), X(pts[i + 1][0]), Y(pts[i + 1][1]), X(pts[i + 2][0]), Y(pts[i + 2][1]));
        }
        o.stroke();
      }
      function facePath() {
        o.beginPath();
        o.moveTo(X(0), Y(-0.52));
        o.bezierCurveTo(X(0.22), Y(-0.52), X(0.355), Y(-0.34), X(0.365), Y(-0.10));
        o.bezierCurveTo(X(0.372), Y(0.08), X(0.345), Y(0.18), X(0.30), Y(0.30));
        o.bezierCurveTo(X(0.24), Y(0.42), X(0.12), Y(0.50), X(0), Y(0.515));
        o.bezierCurveTo(X(-0.12), Y(0.50), X(-0.24), Y(0.42), X(-0.30), Y(0.30));
        o.bezierCurveTo(X(-0.345), Y(0.18), X(-0.372), Y(0.08), X(-0.365), Y(-0.10));
        o.bezierCurveTo(X(-0.355), Y(-0.34), X(-0.22), Y(-0.52), X(0), Y(-0.52));
        o.closePath();
      }
      function radial(x, y, r, c0, c1) {
        const g = o.createRadialGradient(X(x), Y(y), 0, X(x), Y(y), r * sc);
        g.addColorStop(0, c0);
        g.addColorStop(1, c1);
        o.fillStyle = g;
        o.fillRect(X(x) - r * sc, Y(y) - r * sc, r * sc * 2, r * sc * 2);
      }
      function drawPortrait(open, lid, gazeX) {
        o.clearRect(0, 0, S, S);

        // ---- neck + shoulders ----
        for (const s of [-1, 1]) {
          strokePath([[s * 0.16, 0.47], [s * 0.145, 0.58], [s * 0.15, 0.66], [s * 0.185, 0.745], [s * 0.27, 0.83], [s * 0.46, 0.875], [s * 0.62, 0.93]], 'rgba(120,180,240,0.55)', 1.4);
          // collarbone
          strokePath([[s * 0.05, 0.91], [s * 0.16, 0.865], [s * 0.28, 0.862], [s * 0.385, 0.88]], 'rgba(120,180,240,0.30)', 1.2);
        }
        // chest sheen
        radial(0, 0.86, 0.34, 'rgba(80,150,235,0.10)', 'rgba(0,0,0,0)');
        // circuit traces
        o.lineWidth = 1;
        o.strokeStyle = 'rgba(200,240,255,0.65)';
        for (const tr of [[[0.035, 0.62], [0.035, 0.78], [0.115, 0.78], [0.115, 0.92]], [[-0.07, 0.70], [-0.07, 0.84], [-0.20, 0.84], [-0.20, 0.95]]]) {
          o.beginPath();
          o.moveTo(X(tr[0][0]), Y(tr[0][1]));
          for (let i = 1; i < tr.length; i++) o.lineTo(X(tr[i][0]), Y(tr[i][1]));
          o.stroke();
          o.fillStyle = 'rgba(240,250,255,0.9)';
          o.fillRect(X(tr[tr.length - 1][0]) - 1.5, Y(tr[tr.length - 1][1]) - 1.5, 3, 3);
        }

        // ---- face fill + shading ----
        o.save();
        facePath();
        o.clip();
        o.fillStyle = 'rgba(70,140,230,0.13)';
        o.fillRect(0, 0, S, S);
        radial(0, -0.06, 0.46, 'rgba(140,200,255,0.16)', 'rgba(0,0,0,0)'); // center light
        radial(0, -0.30, 0.26, 'rgba(150,210,255,0.10)', 'rgba(0,0,0,0)'); // forehead
        radial(0.30, 0.06, 0.20, 'rgba(8,20,60,0.25)', 'rgba(0,0,0,0)'); // side shade
        radial(-0.30, 0.06, 0.20, 'rgba(8,20,60,0.25)', 'rgba(0,0,0,0)');
        radial(0.19, 0.17, 0.12, 'rgba(150,210,255,0.10)', 'rgba(0,0,0,0)'); // cheeks
        radial(-0.19, 0.17, 0.12, 'rgba(150,210,255,0.10)', 'rgba(0,0,0,0)');
        o.restore();
        facePath();
        o.strokeStyle = 'rgba(150,205,255,0.55)';
        o.lineWidth = 1.3;
        o.stroke();
        // under-chin shadow
        radial(0, 0.585, 0.13, 'rgba(4,12,40,0.40)', 'rgba(0,0,0,0)');

        // ---- eyes ----
        for (const s of [-1, 1]) {
          const ex = s * 0.17,
            ey = -0.005;
          const lidDrop = lid * 0.055;
          // iris (clipped by eye almond)
          o.save();
          o.beginPath();
          o.moveTo(X(ex - s * 0.085), Y(0.008));
          o.bezierCurveTo(X(ex - s * 0.03), Y(-0.038 + lidDrop), X(ex + s * 0.04), Y(-0.034 + lidDrop), X(ex + s * 0.082), Y(-0.002));
          o.bezierCurveTo(X(ex + s * 0.02), Y(0.030), X(ex - s * 0.03), Y(0.026), X(ex - s * 0.085), Y(0.008));
          o.closePath();
          o.clip();
          if (lid < 0.7) {
            const ix = ex + gazeX,
              iy = -0.004;
            o.strokeStyle = 'rgba(200,235,255,0.95)';
            o.lineWidth = 1.6;
            o.beginPath();
            o.arc(X(ix), Y(iy), 0.035 * sc, 0, Math.PI * 2);
            o.stroke();
            o.fillStyle = 'rgba(120,190,250,0.35)';
            o.beginPath();
            o.arc(X(ix), Y(iy), 0.034 * sc, 0, Math.PI * 2);
            o.fill();
            o.fillStyle = 'rgba(6,16,45,0.95)';
            o.beginPath();
            o.arc(X(ix), Y(iy), 0.0135 * sc, 0, Math.PI * 2);
            o.fill();
            o.fillStyle = 'rgba(245,252,255,0.95)';
            o.beginPath();
            o.arc(X(ix - 0.011), Y(iy - 0.011), 0.006 * sc, 0, Math.PI * 2);
            o.fill();
          }
          o.restore();
          // lids
          strokePath([[ex - s * 0.085, 0.008], [ex - s * 0.03, -0.038 + lidDrop], [ex + s * 0.04, -0.034 + lidDrop], [ex + s * 0.082, -0.002]], 'rgba(190,228,255,0.95)', 1.7);
          strokePath([[ex + s * 0.082, -0.002], [ex + s * 0.02, 0.030], [ex - s * 0.03, 0.026], [ex - s * 0.085, 0.008]], 'rgba(140,195,250,0.35)', 1.1);
          // lash flick
          strokePath([[ex + s * 0.082, -0.002], [ex + s * 0.092, -0.008], [ex + s * 0.098, -0.012], [ex + s * 0.106, -0.018]], 'rgba(190,228,255,0.8)', 1.6);
          // crease
          strokePath([[ex - s * 0.07, -0.030], [ex - s * 0.01, -0.052], [ex + s * 0.03, -0.050], [ex + s * 0.062, -0.028]], 'rgba(130,185,245,0.28)', 1);
          // brow — two-pass taper
          strokePath([[ex - s * 0.105, -0.082], [ex - s * 0.03, -0.118], [ex + s * 0.03, -0.112], [ex + s * 0.098, -0.086]], 'rgba(95,155,235,0.55)', 3);
          strokePath([[ex - s * 0.095, -0.085], [ex - s * 0.03, -0.114], [ex + s * 0.03, -0.108], [ex + s * 0.088, -0.088]], 'rgba(150,200,255,0.75)', 1.4);
          // nostril + alar
          strokePath([[s * 0.050, 0.206], [s * 0.038, 0.218], [s * 0.026, 0.219], [s * 0.018, 0.214]], 'rgba(150,200,255,0.55)', 1.2);
          strokePath([[s * 0.052, 0.204], [s * 0.066, 0.192], [s * 0.064, 0.176], [s * 0.056, 0.166]], 'rgba(130,185,245,0.35)', 1);
        }
        // nose bridge hint + tip underside
        strokePath([[0.013, -0.03], [0.020, 0.04], [0.026, 0.10], [0.030, 0.152]], 'rgba(120,180,240,0.22)', 1);
        strokePath([[-0.024, 0.224], [-0.008, 0.232], [0.008, 0.232], [0.024, 0.224]], 'rgba(150,200,255,0.5)', 1.2);

        // ---- lips ----
        const mw = 0.115,
          my = 0.345,
          op = open * 0.05;
        // upper lip fill
        o.fillStyle = 'rgba(135,185,250,0.32)';
        o.beginPath();
        o.moveTo(X(-mw), Y(my + 0.004));
        o.bezierCurveTo(X(-0.060), Y(my - 0.024), X(-0.028), Y(my - 0.031), X(-0.012), Y(my - 0.024));
        o.bezierCurveTo(X(-0.004), Y(my - 0.019), X(0.004), Y(my - 0.019), X(0.012), Y(my - 0.024));
        o.bezierCurveTo(X(0.028), Y(my - 0.031), X(0.060), Y(my - 0.024), X(mw), Y(my + 0.004));
        o.bezierCurveTo(X(0.05), Y(my + 0.011), X(-0.05), Y(my + 0.011), X(-mw), Y(my + 0.004));
        o.fill();
        // mouth interior when open
        if (op > 0.004) {
          o.fillStyle = 'rgba(4,12,38,0.88)';
          o.beginPath();
          o.ellipse(X(0), Y(my + 0.013 + op * 0.55), mw * 0.78 * sc, (op * 0.75 + 0.004) * sc, 0, 0, Math.PI * 2);
          o.fill();
          o.strokeStyle = 'rgba(235,248,255,0.45)';
          o.lineWidth = 1;
          o.beginPath();
          o.moveTo(X(-mw * 0.55), Y(my + 0.012));
          o.quadraticCurveTo(X(0), Y(my + 0.016), X(mw * 0.55), Y(my + 0.012));
          o.stroke();
        }
        // lower lip fill
        o.fillStyle = 'rgba(155,205,255,0.38)';
        o.beginPath();
        o.moveTo(X(-mw), Y(my + 0.004));
        o.bezierCurveTo(X(-0.070), Y(my + 0.054 + op), X(0.070), Y(my + 0.054 + op), X(mw), Y(my + 0.004));
        o.bezierCurveTo(X(0.05), Y(my + 0.013 + op * 0.5), X(-0.05), Y(my + 0.013 + op * 0.5), X(-mw), Y(my + 0.004));
        o.fill();
        // lip lines + highlight
        strokePath([[-mw, my + 0.004], [-0.04, my + 0.012 + op * 0.4], [0.04, my + 0.012 + op * 0.4], [mw, my + 0.004]], 'rgba(90,150,230,0.6)', 1.1);
        strokePath([[-0.045, my + 0.034 + op], [-0.015, my + 0.040 + op], [0.015, my + 0.040 + op], [0.045, my + 0.034 + op]], 'rgba(235,248,255,0.55)', 1.3);
        // chin crease
        strokePath([[-0.05, 0.445], [-0.015, 0.455], [0.015, 0.455], [0.05, 0.445]], 'rgba(120,180,240,0.18)', 1);

        // ---- hair (drawn last — covers forehead/temples) ----
        const hg = o.createLinearGradient(0, Y(-0.66), 0, Y(0.45));
        hg.addColorStop(0, 'rgba(95,155,235,0.55)');
        hg.addColorStop(0.5, 'rgba(45,90,180,0.50)');
        hg.addColorStop(1, 'rgba(20,45,110,0.42)');
        o.fillStyle = hg;
        o.beginPath();
        o.moveTo(X(-0.43), Y(0.42));
        o.bezierCurveTo(X(-0.475), Y(0.20), X(-0.465), Y(-0.20), X(-0.40), Y(-0.42));
        o.bezierCurveTo(X(-0.30), Y(-0.625), X(-0.10), Y(-0.66), X(0), Y(-0.655));
        o.bezierCurveTo(X(0.16), Y(-0.645), X(0.37), Y(-0.55), X(0.445), Y(-0.30));
        o.bezierCurveTo(X(0.478), Y(-0.10), X(0.465), Y(0.18), X(0.425), Y(0.42));
        o.lineTo(X(0.347), Y(0.40));
        o.bezierCurveTo(X(0.362), Y(0.20), X(0.364), Y(0.06), X(0.358), Y(-0.02));
        o.bezierCurveTo(X(0.20), Y(-0.26), X(0.0), Y(-0.395), X(-0.085), Y(-0.475));
        o.bezierCurveTo(X(-0.20), Y(-0.41), X(-0.305), Y(-0.245), X(-0.348), Y(-0.06));
        o.bezierCurveTo(X(-0.356), Y(0.12), X(-0.350), Y(0.28), X(-0.337), Y(0.40));
        o.closePath();
        o.fill();
        // rim light + strands
        strokePath([[-0.40, -0.42], [-0.30, -0.625], [-0.10, -0.66], [0, -0.655], [0.16, -0.645], [0.37, -0.55], [0.445, -0.30]], 'rgba(170,215,255,0.5)', 1.4);
        strokePath([[-0.085, -0.475], [0.02, -0.40], [0.20, -0.27], [0.358, -0.02]], 'rgba(170,215,255,0.45)', 1.2);
        strokePath([[-0.085, -0.475], [-0.20, -0.41], [-0.305, -0.245], [-0.348, -0.06]], 'rgba(140,195,250,0.35)', 1.1);
        strokePath([[0.42, -0.30], [0.45, -0.08], [0.44, 0.16], [0.41, 0.40]], 'rgba(140,195,250,0.30)', 1);
        strokePath([[-0.41, -0.28], [-0.44, -0.05], [-0.43, 0.18], [-0.405, 0.40]], 'rgba(140,195,250,0.30)', 1);
        strokePath([[0.05, -0.62], [0.18, -0.56], [0.30, -0.42], [0.36, -0.22]], 'rgba(150,200,255,0.25)', 1);
      }
      function draw() {
        t += 1;
        if (blink <= 0 && Math.random() < 0.008) blink = 10;
        if (blink > 0) blink -= 1;
        if (glitch <= 0 && Math.random() < 0.005) {
          glitch = 6;
          gShift = (Math.random() - 0.5) * 16;
          gY = Math.random() * S * 0.7;
        }
        if (glitch > 0) glitch -= 1;
        const amp = spk.current ? 0.3 + Math.abs(Math.sin(t * 0.215)) * 0.7 : 0.0;
        const lid = blink > 0 ? Math.sin(blink / 10 * Math.PI) : 0;
        const gazeX = Math.sin(t * 0.0017) * 0.010;
        cy = cy0 + Math.sin(t * 0.012) * 1.6 + (spk.current ? Math.sin(t * 0.4) * 0.7 : 0);
        drawPortrait(amp, lid, gazeX);
        ctx.clearRect(0, 0, S, S);
        // under-glow
        const g = ctx.createRadialGradient(S / 2, S * 0.66, 0, S / 2, S * 0.66, S * 0.6);
        g.addColorStop(0, 'rgba(70,160,255,0.14)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, S, S);

        // composite portrait with flicker + glitch slices
        ctx.globalAlpha = 0.88 + 0.12 * Math.sin(t * 0.7) * Math.sin(t * 0.13);
        if (glitch > 0) {
          const hh = 14;
          ctx.drawImage(off, 0, 0, S, gY, 0, 0, S, gY);
          ctx.drawImage(off, 0, gY, S, hh, gShift, gY, S, hh);
          ctx.drawImage(off, 0, gY + hh, S, S - gY - hh, 0, gY + hh, S, S - gY - hh);
        } else {
          ctx.drawImage(off, 0, 0);
        }
        ctx.globalAlpha = 1;

        // scanline raster — thin the hologram rows
        ctx.globalCompositeOperation = 'destination-out';
        ctx.fillStyle = 'rgba(0,0,0,0.42)';
        for (let y = t * 0.2 % 3; y < S; y += 3) ctx.fillRect(0, y, S, 1);
        ctx.globalCompositeOperation = 'source-over';
        raf = requestAnimationFrame(draw);
      }
      draw();
      return () => cancelAnimationFrame(raf);
    }, []);
    return /*#__PURE__*/React.createElement("canvas", {
      ref: ref,
      width: width,
      height: height,
      style: {
        display: 'block'
      }
    });
  }

  // ============ RingDial — gyroscopic instrument rings ============
  function RingDial({
    size = 470,
    active = false
  }) {
    const ref = React.useRef(null);
    const act = React.useRef(active);
    act.current = active;
    React.useEffect(() => {
      const canvas = ref.current,
        ctx = canvas.getContext('2d');
      const S = canvas.width,
        c = S / 2;
      let raf,
        t = 0;
      function draw() {
        t += 1;
        ctx.clearRect(0, 0, S, S);
        const boost = act.current ? 1.35 : 1;
        const fa = t * 0.0025;
        const fx = c + Math.cos(fa) * S * 0.17,
          fy = c + Math.sin(fa) * S * 0.17;
        const fg = ctx.createRadialGradient(fx, fy, 0, fx, fy, S * 0.30);
        fg.addColorStop(0, 'rgba(255, 150, 70, 0.10)');
        fg.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = fg;
        ctx.fillRect(0, 0, S, S);
        for (let i = 0; i < 96; i++) {
          const a = i / 96 * Math.PI * 2;
          const r1 = S * (i % 8 === 0 ? 0.448 : 0.458),
            r2 = S * 0.468;
          ctx.strokeStyle = `rgba(58, 214, 255, ${i % 8 === 0 ? 0.45 : 0.22})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(c + Math.cos(a) * r1, c + Math.sin(a) * r1);
          ctx.lineTo(c + Math.cos(a) * r2, c + Math.sin(a) * r2);
          ctx.stroke();
        }
        ctx.strokeStyle = `rgba(234, 247, 255, ${0.5 * boost})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(c, c, S * 0.463, t * 0.012, t * 0.012 + 0.8);
        ctx.stroke();
        ctx.strokeStyle = 'rgba(58, 214, 255, 0.35)';
        ctx.lineWidth = S * 0.020;
        ctx.setLineDash([S * 0.045, S * 0.016]);
        ctx.lineDashOffset = t * 0.18;
        ctx.beginPath();
        ctx.arc(c, c, S * 0.418, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = `rgba(234, 247, 255, ${0.75 * boost})`;
        ctx.setLineDash([S * 0.045, S * 0.32]);
        ctx.lineDashOffset = -t * 0.35;
        ctx.beginPath();
        ctx.arc(c, c, S * 0.418, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.strokeStyle = 'rgba(58, 214, 255, 0.45)';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([9, 7]);
        ctx.lineDashOffset = -t * 0.4;
        ctx.beginPath();
        ctx.arc(c, c, S * 0.382, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.font = `${Math.max(7, S * 0.018)}px "SF Mono", "Fira Code", Menlo, monospace`;
        ctx.fillStyle = 'rgba(58, 214, 255, 0.35)';
        ctx.textAlign = 'center';
        const digits = '0191821411485419';
        for (let i = 0; i < digits.length; i++) {
          const a = i / digits.length * Math.PI * 2 + t * 0.0015;
          ctx.save();
          ctx.translate(c + Math.cos(a) * S * 0.355, c + Math.sin(a) * S * 0.355);
          ctx.rotate(a + Math.PI / 2);
          ctx.fillText(digits[i], 0, 0);
          ctx.restore();
        }
        for (const [phase, rr, sq] of [[0, 0.46, 0.30], [2.1, 0.44, 0.22]]) {
          ctx.save();
          ctx.translate(c, c);
          ctx.rotate(t * 0.004 + phase);
          ctx.scale(1, sq);
          ctx.strokeStyle = `rgba(58, 214, 255, ${0.5 * boost})`;
          ctx.lineWidth = 1.3;
          ctx.setLineDash([16, 11]);
          ctx.lineDashOffset = t * 0.6;
          ctx.beginPath();
          ctx.arc(0, 0, S * rr, 0, Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);
          const na = t * 0.02 + phase;
          ctx.fillStyle = 'rgba(234, 247, 255, 0.9)';
          ctx.fillRect(Math.cos(na) * S * rr - 2, Math.sin(na) * S * rr - 2, 4, 4);
          ctx.restore();
        }
        raf = requestAnimationFrame(draw);
      }
      draw();
      return () => cancelAnimationFrame(raf);
    }, []);
    return /*#__PURE__*/React.createElement("canvas", {
      ref: ref,
      width: size,
      height: size,
      style: {
        display: 'block'
      }
    });
  }

  // ============ PlexusBG — drifting constellation field ============
  function PlexusBG({
    width = 900,
    height = 520
  }) {
    const ref = React.useRef(null);
    React.useEffect(() => {
      const canvas = ref.current,
        ctx = canvas.getContext('2d');
      const w = canvas.width,
        h = canvas.height;
      const pts = Array.from({
        length: 56
      }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.22,
        vy: (Math.random() - 0.5) * 0.22
      }));
      let raf;
      function draw() {
        ctx.clearRect(0, 0, w, h);
        for (const p of pts) {
          p.x = (p.x + p.vx + w) % w;
          p.y = (p.y + p.vy + h) % h;
        }
        for (let i = 0; i < pts.length; i++) {
          for (let j = i + 1; j < pts.length; j++) {
            const d = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y);
            if (d < 110) {
              ctx.strokeStyle = `rgba(58, 214, 255, ${(1 - d / 110) * 0.13})`;
              ctx.lineWidth = 0.7;
              ctx.beginPath();
              ctx.moveTo(pts[i].x, pts[i].y);
              ctx.lineTo(pts[j].x, pts[j].y);
              ctx.stroke();
            }
          }
        }
        ctx.fillStyle = 'rgba(159, 220, 245, 0.5)';
        for (const p of pts) ctx.fillRect(p.x - 1, p.y - 1, 1.8, 1.8);
        raf = requestAnimationFrame(draw);
      }
      draw();
      return () => cancelAnimationFrame(raf);
    }, []);
    return /*#__PURE__*/React.createElement("canvas", {
      ref: ref,
      width: width,
      height: height,
      style: {
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none'
      }
    });
  }

  // mini decimal ring gauge
  function MiniRing({
    value = 50,
    size = 38
  }) {
    const ref = React.useRef(null);
    React.useEffect(() => {
      const c = ref.current,
        ctx = c.getContext('2d');
      const s = c.width,
        m = s / 2,
        r = s / 2 - 4;
      ctx.clearRect(0, 0, s, s);
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.20)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(m, m, r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = '#eaf7ff';
      ctx.beginPath();
      ctx.arc(m, m, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (value / 100));
      ctx.stroke();
    }, [value]);
    return /*#__PURE__*/React.createElement("canvas", {
      ref: ref,
      width: size,
      height: size,
      style: {
        display: 'block'
      }
    });
  }

  // ============ HoloPortrait — image-based hyperreal hologram ============
  // Drop ANY portrait image onto the avatar; it is gradient-mapped to a blue
  // hologram (navy → electric blue → white-hot), vignetted, scanlined, and
  // animated with flicker/glitch/scan-sweep. Persists in localStorage.
  function HoloPortrait({
    speaking = false,
    size = 310
  }) {
    const canvasRef = React.useRef(null);
    const baseRef = React.useRef(null);
    const fileRef = React.useRef(null);
    const [hasImg, setHasImg] = React.useState(false);
    const spk = React.useRef(speaking);
    spk.current = speaking;
    const S = size * 2; // internal resolution

    function processImage(img) {
      const base = document.createElement('canvas');
      base.width = S;
      base.height = S;
      const b = base.getContext('2d');
      const sc = Math.max(S / img.width, S / img.height);
      const dw = img.width * sc,
        dh = img.height * sc;
      b.drawImage(img, (S - dw) / 2, (S - dh) / 2 * 0.6, dw, dh); // bias crop upward (faces sit high)
      const id = b.getImageData(0, 0, S, S);
      const d = id.data;
      const cxn = S / 2,
        cyn = S / 2;
      for (let i = 0; i < d.length; i += 4) {
        const lum = Math.pow((0.30 * d[i] + 0.59 * d[i + 1] + 0.11 * d[i + 2]) / 255, 0.85);
        let r, g, bl;
        if (lum < 0.5) {
          const t2 = lum * 2;
          r = 8 + (60 - 8) * t2;
          g = 20 + (140 - 20) * t2;
          bl = 60 + (255 - 60) * t2;
        } else {
          const t2 = (lum - 0.5) * 2;
          r = 60 + (215 - 60) * t2;
          g = 140 + (242 - 140) * t2;
          bl = 255;
        }
        d[i] = r;
        d[i + 1] = g;
        d[i + 2] = bl;
        // circular vignette fade → hologram floats
        const px = i / 4 % S,
          py = i / 4 / S | 0;
        const dist = Math.hypot(px - cxn, py - cyn) / (S / 2);
        const fade = dist > 0.72 ? Math.max(0, 1 - (dist - 0.72) / 0.26) : 1;
        d[i + 3] = Math.min(d[i + 3], 255 * fade * (0.35 + 0.65 * lum + 0.25));
      }
      b.putImageData(id, 0, 0);
      baseRef.current = base;
      setHasImg(true);
    }
    function loadDataUrl(url) {
      const img = new Image();
      img.onload = () => processImage(img);
      img.src = url;
    }
    function handleFile(file) {
      if (!file || !file.type.startsWith('image/')) return;
      const img = new Image();
      img.onload = () => {
        // downscale before persisting
        const m = 1000 / Math.max(img.width, img.height);
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * Math.min(1, m));
        c.height = Math.round(img.height * Math.min(1, m));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        const url = c.toDataURL('image/jpeg', 0.86);
        try {
          localStorage.setItem('hud-avatar-img', url);
        } catch (e) {}
        loadDataUrl(url);
      };
      img.src = URL.createObjectURL(file);
    }
    React.useEffect(() => {
      const saved = localStorage.getItem('hud-avatar-img');
      if (saved) loadDataUrl(saved);
    }, []);
    React.useEffect(() => {
      if (!hasImg) return;
      const canvas = canvasRef.current,
        ctx = canvas.getContext('2d');
      let raf,
        t = 0,
        glitch = 0,
        gY = 0,
        gShift = 0;
      function draw() {
        t += 1;
        if (glitch <= 0 && Math.random() < 0.006) {
          glitch = 6;
          gY = Math.random() * S * 0.8;
          gShift = (Math.random() - 0.5) * 26;
        }
        if (glitch > 0) glitch -= 1;
        const base = baseRef.current;
        ctx.clearRect(0, 0, S, S);

        // under-glow
        const g = ctx.createRadialGradient(S / 2, S * 0.62, 0, S / 2, S * 0.62, S * 0.62);
        g.addColorStop(0, 'rgba(70,160,255,0.15)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, S, S);

        // breathing + flicker
        const breathe = 1 + Math.sin(t * 0.013) * 0.004;
        const boost = spk.current ? 0.12 + 0.10 * Math.abs(Math.sin(t * 0.22)) : 0;
        ctx.globalAlpha = 0.86 + 0.14 * Math.sin(t * 0.7) * Math.sin(t * 0.13) + boost;
        ctx.save();
        ctx.translate(S / 2, S / 2 + Math.sin(t * 0.011) * 3);
        ctx.scale(breathe, breathe);
        if (glitch > 0) {
          const hh = 22;
          ctx.drawImage(base, 0, 0, S, gY, -S / 2, -S / 2, S, gY);
          ctx.drawImage(base, 0, gY, S, hh, -S / 2 + gShift, -S / 2 + gY, S, hh);
          ctx.drawImage(base, 0, gY + hh, S, S - gY - hh, -S / 2, -S / 2 + gY + hh, S, S - gY - hh);
        } else {
          ctx.drawImage(base, -S / 2, -S / 2);
        }
        // speaking: additive double-exposure shimmer
        if (spk.current) {
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = 0.10 + 0.08 * Math.abs(Math.sin(t * 0.22));
          ctx.drawImage(base, -S / 2 + Math.sin(t * 0.3) * 2.5, -S / 2);
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.restore();
        ctx.globalAlpha = 1;

        // scan sweep band
        const sy = t * 2.2 % (S * 1.4);
        if (sy < S) {
          ctx.globalCompositeOperation = 'lighter';
          const sg = ctx.createLinearGradient(0, sy - 16, 0, sy + 16);
          sg.addColorStop(0, 'rgba(120,200,255,0)');
          sg.addColorStop(0.5, 'rgba(160,220,255,0.10)');
          sg.addColorStop(1, 'rgba(120,200,255,0)');
          ctx.fillStyle = sg;
          ctx.fillRect(0, sy - 16, S, 32);
          ctx.fillStyle = 'rgba(200,240,255,0.16)';
          ctx.fillRect(0, sy, S, 2);
          ctx.globalCompositeOperation = 'source-over';
        }

        // scanline raster
        ctx.globalCompositeOperation = 'destination-out';
        ctx.fillStyle = 'rgba(0,0,0,0.38)';
        for (let y = t * 0.25 % 4; y < S; y += 4) ctx.fillRect(0, y, S, 1.4);
        ctx.globalCompositeOperation = 'source-over';
        raf = requestAnimationFrame(draw);
      }
      draw();
      return () => cancelAnimationFrame(raf);
    }, [hasImg]);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: size,
        height: size,
        cursor: 'pointer'
      },
      title: "Drop a portrait image to set the avatar",
      onDragOver: e => e.preventDefault(),
      onDrop: e => {
        e.preventDefault();
        handleFile(e.dataTransfer.files && e.dataTransfer.files[0]);
      },
      onClick: () => fileRef.current && fileRef.current.click()
    }, /*#__PURE__*/React.createElement("input", {
      ref: fileRef,
      type: "file",
      accept: "image/*",
      style: {
        display: 'none'
      },
      onChange: e => handleFile(e.target.files && e.target.files[0])
    }), hasImg ? /*#__PURE__*/React.createElement("canvas", {
      ref: canvasRef,
      width: S,
      height: S,
      style: {
        display: 'block',
        width: size,
        height: size
      }
    }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(HoloFace, {
      speaking: spk.current,
      width: size,
      height: size
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: '50%',
        bottom: 6,
        transform: 'translateX(-50%)',
        fontSize: 8,
        letterSpacing: 1,
        color: 'var(--cyan)',
        whiteSpace: 'nowrap',
        background: 'rgba(4,12,30,0.7)',
        padding: '3px 8px',
        border: '1px solid var(--border)'
      }
    }, "\u2B21 DROP A PORTRAIT IMAGE HERE \u2014 RENDERED AS HOLOGRAM")));
  }
  Object.assign(window, {
    HoloFace,
    HoloPortrait,
    RingDial,
    PlexusBG,
    MiniRing
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/master_hud/HoloFace.jsx", error: String((e && e.message) || e) }); }

// ui_kits/master_hud/HudData.jsx
try { (() => {
// Canonical demo-mode data — shared via window.HudData (no module imports in-browser).
(function () {
  const SEED_AGENTS = [{
    id: 'foreman',
    name: 'Foreman',
    status: 'online',
    parent: null,
    description: 'Head agent / primary coordinator. Delegates tasks to sub-agents.',
    task: 'Idle — awaiting commands',
    model: 'claude-opus-4.6',
    provider: 'Anthropic',
    voiceEnabled: true,
    stability: 0.5,
    latencyTier: 3,
    contextWindow: 200000,
    systemPrompt: 'You are Foreman, the coordinator of the OpenClaw agent fleet. Receive operator commands, break them into tasks, and delegate to sub-agents.'
  }, {
    id: 'scout',
    name: 'Scout',
    status: 'processing',
    parent: 'foreman',
    description: 'Research agent. Gathers sources, articles, and videos for new ideas.',
    task: 'Researching: local-first sync engines',
    model: 'claude-sonnet-4.6',
    provider: 'OpenRouter',
    voiceEnabled: false,
    stability: 0.5,
    latencyTier: 3,
    contextWindow: 200000,
    systemPrompt: 'You are Scout. Research topics thoroughly and return structured source lists.'
  }, {
    id: 'draftsman',
    name: 'Draftsman',
    status: 'online',
    parent: 'foreman',
    description: 'Planning agent. Turns research into structured build plans.',
    task: 'Idle',
    model: 'claude-sonnet-4.6',
    provider: 'Anthropic',
    voiceEnabled: false,
    stability: 0.5,
    latencyTier: 3,
    contextWindow: 200000,
    systemPrompt: 'You are Draftsman. Synthesize research into actionable build plans.'
  }, {
    id: 'builder',
    name: 'Builder',
    status: 'warning',
    parent: 'foreman',
    description: 'Build agent. Hands plans off to Claude Code and streams progress.',
    task: 'Slow response — retrying terminal handoff',
    model: 'claude-opus-4.6',
    provider: 'Anthropic',
    voiceEnabled: false,
    stability: 0.5,
    latencyTier: 2,
    contextWindow: 200000,
    systemPrompt: 'You are Builder. Convert plans to requirements docs and drive Claude Code builds.'
  }, {
    id: 'sentinel',
    name: 'Sentinel',
    status: 'offline',
    parent: 'foreman',
    description: 'Home lab monitor. Watches system health and security status.',
    task: '—',
    model: 'claude-haiku-4.5',
    provider: 'OpenRouter',
    voiceEnabled: false,
    stability: 0.5,
    latencyTier: 3,
    contextWindow: 200000,
    systemPrompt: 'You are Sentinel. Report system metrics and flag anomalies.'
  }];
  const SEED_CHAT = [{
    id: 1,
    agent: 'System',
    text: 'Multi-agent session started.',
    ts: Date.now() - 360000,
    system: true
  }, {
    id: 2,
    agent: 'Foreman',
    text: 'Team status check. Report in.',
    ts: Date.now() - 300000
  }, {
    id: 3,
    agent: 'Scout',
    text: 'Online. Research queue: 1 active topic.',
    ts: Date.now() - 290000
  }, {
    id: 4,
    agent: 'Draftsman',
    text: 'Online. No pending plans.',
    ts: Date.now() - 280000
  }, {
    id: 5,
    agent: 'Builder',
    text: 'Online. Terminal bridge latency elevated (1.2s).',
    ts: Date.now() - 270000
  }, {
    id: 6,
    agent: 'System',
    text: 'Task assigned: research "local-first sync engines" → Scout.',
    ts: Date.now() - 120000,
    system: true
  }];
  const SEED_IDEAS = [{
    id: 'idea-1',
    title: 'Voice-controlled home lab dashboard',
    capturedAt: Date.now() - 86400000 * 3,
    stage: 5,
    stageStatus: 'complete',
    research: {
      sources: 14,
      videos: 3,
      summary: 'Strong prior art: Home Assistant voice, OpenHAB. Gap: agent-native control.'
    },
    plan: 'Electron HUD + Realtime API voice + OpenClaw gateway command routing.',
    buildLog: ['Scaffolded repo', 'Voice pipeline wired', 'Gateway integration complete', '✓ Built'],
    output: 'github.com/you/ai-master-hud'
  }, {
    id: 'idea-2',
    title: 'Local-first notes sync engine',
    capturedAt: Date.now() - 86400000,
    stage: 1,
    stageStatus: 'active',
    research: {
      sources: 6,
      videos: 2,
      summary: 'Researching…'
    },
    plan: null,
    buildLog: [],
    output: null
  }, {
    id: 'idea-3',
    title: 'Agent-written morning briefing podcast',
    capturedAt: Date.now() - 3600000 * 4,
    stage: 3,
    stageStatus: 'waiting',
    research: {
      sources: 9,
      videos: 1,
      summary: 'TTS pipelines mature; differentiator is personal context from agent memory.'
    },
    plan: '1) Nightly cron agent gathers calendar/news. 2) Script generation. 3) TTS render. 4) Push to podcast feed.',
    buildLog: [],
    output: null
  }];
  const SEED_WIKI = [{
    id: 'w1',
    agent: 'Builder',
    errorType: 'TerminalTimeout',
    date: '2026-06-08',
    title: 'Claude Code handoff hangs when terminal session is stale',
    resolution: 'Kill stale tmux session before handoff: `tmux kill-session -t build || true`, then respawn.'
  }, {
    id: 'w2',
    agent: 'Scout',
    errorType: 'RateLimit429',
    date: '2026-06-05',
    title: 'Research bursts hit OpenRouter rate limits',
    resolution: 'Added exponential backoff (2s/4s/8s) and batched source fetches to 5 concurrent.'
  }, {
    id: 'w3',
    agent: 'Foreman',
    errorType: 'WebSocketDrop',
    date: '2026-06-01',
    title: 'Gateway WS drops on home lab sleep',
    resolution: 'Disabled PC sleep; client auto-reconnects with backoff.'
  }];
  const PROJECTS = [{
    id: 'hud',
    name: 'AI Master HUD',
    status: '✓ Built',
    repo: 'github.com/you/ai-master-hud',
    parts: [{
      label: 'Gateway',
      detail: 'ws bridge',
      task: 'OpenClaw gateway routing — auth, exec, chat',
      health: 92
    }, {
      label: 'Voice pipeline',
      detail: 'realtime api',
      task: 'Speech-to-speech, 200–300ms latency',
      health: 84
    }, {
      label: 'Reactor core',
      detail: 'agent fleet',
      task: 'Foreman + 4 sub-agents, task delegation',
      health: 71
    }, {
      label: 'Idea pipeline',
      detail: '6 stages',
      task: 'Capture → Build with human review gate',
      health: 88
    }]
  }, {
    id: 'sync',
    name: 'Notes Sync Engine',
    status: 'Researching',
    repo: '—',
    parts: [{
      label: 'CRDT core',
      detail: 'merge engine',
      task: 'Conflict-free replicated document model',
      health: 38
    }, {
      label: 'Storage',
      detail: 'local-first',
      task: 'SQLite + filesystem snapshots',
      health: 52
    }, {
      label: 'Sync relay',
      detail: 'transport',
      task: 'E2E-encrypted relay over WebSocket',
      health: 21
    }]
  }, {
    id: 'podcast',
    name: 'Briefing Podcast',
    status: 'At review gate',
    repo: '—',
    parts: [{
      label: 'Cron agent',
      detail: 'nightly',
      task: 'Gathers calendar, news, agent memory',
      health: 64
    }, {
      label: 'Script gen',
      detail: 'writer',
      task: 'Personal-context script generation',
      health: 57
    }, {
      label: 'TTS render',
      detail: 'voice',
      task: 'Render + master audio output',
      health: 43
    }, {
      label: 'Feed push',
      detail: 'publish',
      task: 'Private podcast RSS feed',
      health: 30
    }]
  }, {
    id: 'cnc',
    name: 'CNC Workbench',
    status: 'Physical build',
    repo: 'garage',
    parts: [{
      label: 'Frame',
      detail: 'extrusion',
      task: '2040 aluminium gantry frame, squared + braced',
      health: 90
    }, {
      label: 'Gantry',
      detail: 'motion',
      task: 'Dual Y steppers, linear rails, belt tension',
      health: 66
    }, {
      label: 'Spindle',
      detail: 'cutter',
      task: '500W spindle, ER11 collet, PWM speed control',
      health: 48
    }, {
      label: 'Controller',
      detail: 'grbl',
      task: 'GRBL32 board, limit switches, e-stop wiring',
      health: 35
    }]
  }];
  function driftStats(prev) {
    const drift = (v, amt, min, max) => Math.min(max, Math.max(min, v + (Math.random() - 0.5) * amt));
    const p = prev || {
      cpu: 34,
      mem: 58,
      disk: 71,
      latency: 42
    };
    return {
      cpu: drift(p.cpu, 12, 3, 97),
      mem: drift(p.mem, 4, 20, 95),
      disk: drift(p.disk, 0.4, 50, 92),
      latency: drift(p.latency, 18, 12, 240),
      firewall: true,
      threats: 0
    };
  }
  window.HudData = {
    SEED_AGENTS,
    SEED_CHAT,
    SEED_IDEAS,
    SEED_WIKI,
    PROJECTS,
    driftStats
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/master_hud/HudData.jsx", error: String((e && e.message) || e) }); }

// ui_kits/master_hud/PipelineTab.jsx
try { (() => {
// Idea Pipeline tab — capture zone + idea cards with ⭐ review gate.
const {
  Panel: PiPanel,
  Button: PiButton,
  Input: PiInput,
  StageFlow: PiStageFlow
} = window.AIMasterHUDDesignSystem_8b9a29;
function PipelineTab() {
  const [ideas, setIdeas] = React.useState(window.HudData.SEED_IDEAS);
  const [title, setTitle] = React.useState('');
  const [expanded, setExpanded] = React.useState({});
  const [feedback, setFeedback] = React.useState({});
  function capture(e) {
    e.preventDefault();
    const t = title.trim();
    if (!t) return;
    setTitle('');
    setIdeas(prev => [{
      id: `idea-${Date.now()}`,
      title: t,
      capturedAt: Date.now(),
      stage: 0,
      stageStatus: 'active',
      research: null,
      plan: null,
      buildLog: [],
      output: null
    }, ...prev]);
  }
  function review(id, approve) {
    setIdeas(prev => prev.map(i => {
      if (i.id !== id) return i;
      return approve ? {
        ...i,
        stage: 4,
        stageStatus: 'active'
      } : {
        ...i,
        stage: 2,
        stageStatus: 'active'
      };
    }));
  }
  const sorted = [...ideas].sort((a, b) => b.capturedAt - a.capturedAt);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      maxWidth: 1100,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(PiPanel, {
    title: "Capture Zone",
    corners: true
  }, /*#__PURE__*/React.createElement("p", {
    className: "muted small",
    style: {
      margin: '0 0 10px'
    }
  }, "Voice: say \"capture this idea: \u2026\" in the Voice Chat tab \u2014 or type it here."), /*#__PURE__*/React.createElement("form", {
    onSubmit: capture,
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(PiInput, {
    value: title,
    onChange: e => setTitle(e.target.value),
    placeholder: "capture this idea\u2026",
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(PiButton, {
    type: "submit",
    variant: "solid"
  }, "+ Capture"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, sorted.map(idea => {
    const atGate = idea.stage === 3 && idea.stageStatus === 'waiting';
    const isExp = !!expanded[idea.id];
    return /*#__PURE__*/React.createElement("div", {
      key: idea.id,
      className: "hud-panel",
      style: {
        boxShadow: atGate ? 'var(--glow-gate)' : 'none',
        borderColor: atGate ? 'var(--yellow)' : undefined
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        gap: 10,
        cursor: 'pointer',
        marginBottom: 10
      },
      onClick: () => setExpanded(ex => ({
        ...ex,
        [idea.id]: !ex[idea.id]
      }))
    }, /*#__PURE__*/React.createElement("strong", null, idea.title), /*#__PURE__*/React.createElement("span", {
      className: "muted small"
    }, new Date(idea.capturedAt).toLocaleString())), /*#__PURE__*/React.createElement(PiStageFlow, {
      current: idea.stage,
      status: idea.stageStatus
    }), idea.research && /*#__PURE__*/React.createElement("p", {
      className: "muted small",
      style: {
        marginTop: 8
      }
    }, "\uD83D\uDCDA ", idea.research.sources, " sources \xB7 \uD83C\uDFAC ", idea.research.videos, " videos \u2014 ", idea.research.summary), atGate && /*#__PURE__*/React.createElement("div", {
      style: {
        borderTop: '1px dashed var(--yellow)',
        marginTop: 10,
        paddingTop: 10
      }
    }, /*#__PURE__*/React.createElement("h4", {
      style: {
        margin: '0 0 8px',
        color: 'var(--yellow)',
        fontSize: 11,
        letterSpacing: 2
      }
    }, "\u2B50 REVIEW GATE \u2014 HUMAN APPROVAL REQUIRED"), /*#__PURE__*/React.createElement("pre", {
      style: {
        background: 'var(--inset)',
        padding: 8,
        borderRadius: 2,
        fontSize: 12,
        marginBottom: 8
      }
    }, idea.plan), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement(PiButton, {
      variant: "approve",
      onClick: () => review(idea.id, true)
    }, "\u2713 Good, go ahead"), /*#__PURE__*/React.createElement(PiInput, {
      value: feedback[idea.id] || '',
      onChange: e => setFeedback(f => ({
        ...f,
        [idea.id]: e.target.value
      })),
      placeholder: "what needs to change?",
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement(PiButton, {
      variant: "reject",
      onClick: () => review(idea.id, false)
    }, "\u21A9 Need changes"))), idea.output && /*#__PURE__*/React.createElement("p", {
      style: {
        color: 'var(--green)',
        marginTop: 8,
        fontSize: 12
      }
    }, "\u2713 Built \u2192 ", /*#__PURE__*/React.createElement("code", null, idea.output)), isExp && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 10,
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("h4", {
      style: {
        margin: 0,
        fontSize: 10,
        letterSpacing: 2,
        color: 'var(--muted)'
      }
    }, "BUILD LOG"), idea.buildLog.length ? /*#__PURE__*/React.createElement("pre", {
      style: {
        margin: 0
      }
    }, idea.buildLog.join('\n')) : /*#__PURE__*/React.createElement("p", {
      className: "muted small",
      style: {
        margin: 0
      }
    }, "No build activity yet.")));
  })));
}
window.PipelineTab = PipelineTab;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/master_hud/PipelineTab.jsx", error: String((e && e.message) || e) }); }

// ui_kits/master_hud/SettingsModal.jsx
try { (() => {
// Settings modal — gateway, keys, transcript toggle. Persists to localStorage.
const {
  Modal: StModal,
  Button: StButton,
  Input: StInput,
  SettingRow: StRow,
  SettingField: StField
} = window.AIMasterHUDDesignSystem_8b9a29;
const ST_DEFAULTS = {
  gatewayUrl: '',
  gatewayToken: '',
  openaiApiKey: '',
  showTranscript: true
};
function SettingsModal({
  onClose
}) {
  const saved = (() => {
    try {
      return JSON.parse(localStorage.getItem('hud-settings') || '{}');
    } catch (err) {
      return {};
    }
  })();
  const [draft, setDraft] = React.useState({
    ...ST_DEFAULTS,
    ...saved
  });
  function save(e) {
    e.preventDefault();
    localStorage.setItem('hud-settings', JSON.stringify(draft));
    onClose();
  }
  return /*#__PURE__*/React.createElement(StModal, {
    title: "\u2699 SETTINGS",
    onClose: onClose
  }, /*#__PURE__*/React.createElement("form", {
    onSubmit: save,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(StField, {
    label: "OpenClaw gateway URL (WebSocket)"
  }, /*#__PURE__*/React.createElement(StInput, {
    value: draft.gatewayUrl,
    onChange: e => setDraft({
      ...draft,
      gatewayUrl: e.target.value
    }),
    placeholder: "ws://homelab.local:18789 \u2014 leave empty for demo mode"
  })), /*#__PURE__*/React.createElement(StField, {
    label: "Gateway auth token"
  }, /*#__PURE__*/React.createElement(StInput, {
    type: "password",
    value: draft.gatewayToken,
    onChange: e => setDraft({
      ...draft,
      gatewayToken: e.target.value
    }),
    placeholder: "optional"
  })), /*#__PURE__*/React.createElement(StField, {
    label: "OpenAI API key (Realtime voice)"
  }, /*#__PURE__*/React.createElement(StInput, {
    type: "password",
    value: draft.openaiApiKey,
    onChange: e => setDraft({
      ...draft,
      openaiApiKey: e.target.value
    }),
    placeholder: "sk-\u2026"
  })), /*#__PURE__*/React.createElement(StRow, {
    label: "Show live transcript"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: draft.showTranscript,
    onChange: e => setDraft({
      ...draft,
      showTranscript: e.target.checked
    })
  })), /*#__PURE__*/React.createElement("p", {
    className: "muted small"
  }, "Remote access: point the gateway URL at a Tailscale Funnel / ngrok tunnel to your home lab. Keys are stored locally only."), /*#__PURE__*/React.createElement(StButton, {
    type: "submit",
    variant: "solid"
  }, "Save & reconnect")));
}
window.SettingsModal = SettingsModal;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/master_hud/SettingsModal.jsx", error: String((e && e.message) || e) }); }

// ui_kits/master_hud/VoiceTab.jsx
try { (() => {
// Voice stage — cinematic FUI per reference imagery. Borderless micro-data
// columns on the dark field, ghost typography, always-on ambient listening
// (no start/stop — the agent hears you and speaks when spoken to).
const {
  Chip,
  SegBar,
  Waveform,
  HoloBlueprint
} = window.AIMasterHUDDesignSystem_8b9a29;
const {
  PROJECTS,
  driftStats
} = window.HudData;

// auto-running ambient conversation (no API key in demo)
const VOICE_DEMO_SCRIPT = [[1800, a => a.agent('Online. Listening.')], [4200, a => a.user('Hey, what is the team working on?')], [6200, a => a.agent('Scout is researching local-first sync engines. Builder is retrying a terminal handoff. All else idle.')], [10200, a => a.user('Bring up the master HUD project.')], [11800, a => {
  a.agent('Bringing up AI MASTER HUD. Four assemblies online — reactor core shows elevated load.');
  a.bringUp('hud');
}]];

// --- tiny canvas sparkline (frequency-display trace) ---
function SparkLine({
  value,
  width = 184,
  height = 30
}) {
  const ref = React.useRef(null);
  const hist = React.useRef([]);
  React.useEffect(() => {
    const h = hist.current;
    h.push(value);
    if (h.length > 56) h.shift();
    const c = ref.current,
      ctx = c.getContext('2d');
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.strokeStyle = 'rgba(120, 220, 230, 0.75)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    h.forEach((v, i) => {
      const x = i / 55 * c.width;
      const y = c.height - 3 - v / 100 * (c.height - 6);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
    const lx = (h.length - 1) / 55 * c.width;
    const ly = c.height - 3 - h[h.length - 1] / 100 * (c.height - 6);
    ctx.fillStyle = '#eaf7ff';
    ctx.fillRect(lx - 1.5, ly - 1.5, 3, 3);
  }, [value]);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    width: width,
    height: height,
    style: {
      display: 'block'
    }
  });
}

// --- knob dial (READ / WRITE style) ---
function Knob({
  value,
  label
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const c = ref.current,
      ctx = c.getContext('2d');
    const s = c.width,
      cx = s / 2,
      cy = s / 2,
      r = s / 2 - 5;
    ctx.clearRect(0, 0, s, s);
    const a0 = Math.PI * 0.75,
      a1 = Math.PI * 2.25;
    ctx.strokeStyle = 'rgba(58, 214, 255, 0.18)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, cy, r, a0, a1);
    ctx.stroke();
    ctx.strokeStyle = '#3ad6ff';
    ctx.beginPath();
    ctx.arc(cx, cy, r, a0, a0 + (a1 - a0) * (value / 100));
    ctx.stroke();
    ctx.fillStyle = '#eaf7ff';
    ctx.beginPath();
    ctx.arc(cx, cy, r * 0.42, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#06222c';
    const na = a0 + (a1 - a0) * (value / 100);
    ctx.fillRect(cx + Math.cos(na) * r * 0.28 - 1, cy + Math.sin(na) * r * 0.28 - 1, 2.5, 2.5);
  }, [value]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    width: 46,
    height: 46,
    style: {
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 8,
      letterSpacing: 1,
      color: 'var(--muted)'
    }
  }, label));
}
function Capsule({
  value,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "capsule"
  }, /*#__PURE__*/React.createElement("div", {
    className: "track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fill",
    style: {
      height: `${value}%`
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "cap-label"
  }, label));
}
function VoiceTab() {
  const [userSpeaking, setUserSpeaking] = React.useState(false);
  const [agentSpeaking, setAgentSpeaking] = React.useState(false);
  const [transcript, setTranscript] = React.useState([]);
  const [mode, setMode] = React.useState('avatar'); // avatar | blueprint
  const [projectId, setProjectId] = React.useState('hud');
  const [selPart, setSelPart] = React.useState(0);
  const [stats, setStats] = React.useState(driftStats());
  const [lastCommand, setLastCommand] = React.useState(null);
  const [manualCmd, setManualCmd] = React.useState('');
  const [par, setPar] = React.useState({
    x: 0,
    y: 0
  }); // mouse parallax -1..1
  const rootRef = React.useRef(null);
  const timers = React.useRef([]);
  function onParallax(e) {
    const r = rootRef.current && rootRef.current.getBoundingClientRect();
    if (!r) return;
    setPar({
      x: (e.clientX - r.left) / r.width * 2 - 1,
      y: (e.clientY - r.top) / r.height * 2 - 1
    });
  }
  const project = PROJECTS.find(p => p.id === projectId) || PROJECTS[0];
  const part = project.parts[Math.min(selPart, project.parts.length - 1)];
  function addLine(role, text) {
    setTranscript(t => [...t.slice(-30), {
      role,
      text
    }]);
  }
  function bringUp(idOrName) {
    const p = PROJECTS.find(x => x.id === idOrName || x.name.toLowerCase().includes(String(idOrName).toLowerCase()));
    if (p) {
      setProjectId(p.id);
      setSelPart(0);
      setMode('blueprint');
      return p;
    }
    return null;
  }

  // always-on: telemetry drift + ambient conversation start automatically
  React.useEffect(() => {
    const iv = setInterval(() => setStats(s => driftStats(s)), 1400);
    const api = {
      user: text => {
        setUserSpeaking(true);
        addLine('user', text);
        timers.current.push(setTimeout(() => setUserSpeaking(false), 1500));
      },
      agent: text => {
        setAgentSpeaking(true);
        addLine('agent', text);
        timers.current.push(setTimeout(() => setAgentSpeaking(false), 2600));
      },
      bringUp
    };
    VOICE_DEMO_SCRIPT.forEach(([delay, fn]) => timers.current.push(setTimeout(() => fn(api), delay)));
    return () => {
      clearInterval(iv);
      timers.current.forEach(clearTimeout);
    };
  }, []);
  function runManual(e) {
    e.preventDefault();
    const cmd = manualCmd.trim();
    if (!cmd) return;
    setManualCmd('');
    const up = cmd.match(/^bring up (.+)$/i);
    if (up) {
      const p = bringUp(up[1]);
      addLine('agent', p ? `Bringing up ${p.name.toUpperCase()}.` : `No project matching "${up[1]}".`);
      return;
    }
    if (/^(stand down|close|avatar)$/i.test(cmd)) {
      setMode('avatar');
      addLine('agent', 'Standing down.');
      return;
    }
    setLastCommand({
      command: cmd,
      status: 'RUNNING'
    });
    timers.current.push(setTimeout(() => setLastCommand({
      command: cmd,
      status: 'OK · EXECUTED ON HOMELAB'
    }), 900));
  }
  const railStyle = {
    display: 'flex',
    flexDirection: 'column',
    paddingTop: 6,
    transition: 'transform 0.25s ease-out'
  };
  const chipMini = {
    fontSize: 9,
    padding: '2px 8px'
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: rootRef,
    onMouseMove: onParallax,
    onMouseLeave: () => setPar({
      x: 0,
      y: 0
    }),
    style: {
      display: 'grid',
      gridTemplateColumns: '200px minmax(0, 1fr) 230px',
      gap: 22,
      height: '100%',
      perspective: 1400,
      transformStyle: 'preserve-3d'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...railStyle,
      transformOrigin: 'left center',
      transform: `rotateY(${16 + par.x * 3}deg) rotateX(${-par.y * 2.5}deg) translateZ(-26px)`
    }
  }, [['CPU . LOAD', stats.cpu, `${Math.round(stats.cpu)}%`], ['MEM . POOL', stats.mem, `${Math.round(stats.mem)}%`], ['NET . LINK', Math.min(100, stats.latency / 2.4), `${Math.round(stats.latency)}MS`]].map(([label, v, read]) => /*#__PURE__*/React.createElement("div", {
    className: "fui-module",
    key: label
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    style: chipMini
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 9,
      color: 'var(--ice)'
    }
  }, read)), /*#__PURE__*/React.createElement(SparkLine, {
    value: v
  }), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "FRONT VIEW"), /*#__PURE__*/React.createElement("span", null, "OPEN PLATE"), /*#__PURE__*/React.createElement("b", null, "R87")))), /*#__PURE__*/React.createElement("div", {
    className: "fui-module"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hud-label",
    style: {
      fontSize: 9
    }
  }, "MAINT . INT"), /*#__PURE__*/React.createElement("div", {
    className: "seg-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "seg-fill",
    style: {
      width: `${Math.round(100 - stats.cpu)}%`
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "\u229EFILL . IN"), /*#__PURE__*/React.createElement("span", null, "\u229EACTIVE . ID"))), /*#__PURE__*/React.createElement("div", {
    className: "fui-module"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(window.MiniRing, {
    value: Math.round(stats.cpu)
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#eaf7ff'
    }
  }, "0.0981243"), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "DRIFT . IDX")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(window.MiniRing, {
    value: Math.round(stats.mem)
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#eaf7ff'
    }
  }, "1.1892656"), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "SYNC . RATIO"))))), /*#__PURE__*/React.createElement("div", {
    className: "fui-module",
    style: {
      alignSelf: 'stretch'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "hud-label",
    style: {
      fontSize: 9
    }
  }, "L O A D I N G"), /*#__PURE__*/React.createElement("div", {
    className: "hatch-bar",
    style: {
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "hatch-fill",
    style: {
      width: `${Math.round(stats.disk)}%`
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "fui-module"
  }, /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "FIREWALL"), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--green)'
    }
  }, "ACTIVE")), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "THREATS"), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--green)'
    }
  }, "NONE")), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "CAM-01"), /*#__PURE__*/React.createElement("b", null, "NO FEED"))), /*#__PURE__*/React.createElement("div", {
    className: "tick-ruler",
    style: {
      marginTop: 16
    }
  })), /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10,
      minWidth: 0,
      transformStyle: 'preserve-3d'
    }
  }, /*#__PURE__*/React.createElement(window.PlexusBG, {
    width: 900,
    height: 560
  }), /*#__PURE__*/React.createElement("div", {
    className: "ghost-type",
    style: {
      top: -6,
      fontSize: 64,
      filter: 'blur(1.5px)',
      transform: 'translateZ(-80px)'
    }
  }, mode === 'avatar' ? 'FOREMAN' : project.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10,
      transformStyle: 'preserve-3d',
      transition: 'transform 0.25s ease-out',
      transform: `rotateY(${par.x * 5}deg) rotateX(${-par.y * 5}deg) translateZ(14px)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    style: chipMini
  }, mode === 'avatar' ? 'PARTICLE VIEW' : 'ATOM_VIEW'), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      letterSpacing: 3,
      color: '#eaf7ff',
      textShadow: 'var(--text-glow-cyan)'
    }
  }, mode === 'avatar' ? 'FOREMAN' : project.name.toUpperCase()), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 9,
      letterSpacing: 1,
      color: agentSpeaking ? 'var(--cyan)' : 'var(--muted)'
    }
  }, agentSpeaking ? '● SPEAKING' : userSpeaking ? '● HEARING YOU' : '● LISTENING')), mode === 'avatar' ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: 440,
      height: 440,
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement(window.RingDial, {
    size: 440,
    active: agentSpeaking
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(window.HoloPortrait, {
    speaking: agentSpeaking,
    size: 310
  }))) : /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 780
    }
  }, /*#__PURE__*/React.createElement(HoloBlueprint, {
    width: 780,
    height: 360,
    parts: project.parts,
    selected: selPart,
    onSelectPart: setSelPart
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 26,
      alignItems: 'flex-start',
      borderTop: '1px solid var(--border)',
      paddingTop: 10,
      marginTop: 4,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 200,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    style: chipMini
  }, part.label), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '6px 0 6px',
      fontSize: 11,
      color: 'var(--text)'
    }
  }, part.task), /*#__PURE__*/React.createElement(SegBar, {
    value: part.health,
    color: "cyan",
    style: {
      maxWidth: 230
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "hud-label",
    style: {
      fontSize: 8,
      marginBottom: 5
    }
  }, "SYSTEM_CHECK"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18
    }
  }, project.parts.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: p.label,
    style: {
      cursor: 'pointer',
      opacity: i === selPart ? 1 : 0.55
    },
    onClick: () => setSelPart(i)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      fontWeight: 700,
      color: '#eaf7ff',
      textShadow: i === selPart ? 'var(--text-glow-cyan)' : 'none'
    }
  }, p.health, "%"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 7,
      color: 'var(--muted)',
      letterSpacing: 1
    }
  }, String(p.label).slice(0, 10).toUpperCase()))))), /*#__PURE__*/React.createElement("button", {
    className: "hud-btn",
    style: {
      fontSize: 9,
      padding: '4px 10px'
    },
    onClick: () => setMode('avatar')
  }, "\u25E4 Stand down")))), /*#__PURE__*/React.createElement("div", {
    style: {
      transform: 'perspective(800px) rotateX(7deg)',
      transformOrigin: 'center bottom'
    }
  }, /*#__PURE__*/React.createElement(Waveform, {
    userSpeaking: userSpeaking,
    agentSpeaking: agentSpeaking,
    width: 560,
    height: 44
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 640,
      flex: 1,
      overflowY: 'auto',
      minHeight: 48,
      borderTop: '1px solid var(--border)',
      paddingTop: 8,
      transform: 'perspective(900px) rotateX(9deg)',
      transformOrigin: 'center top'
    }
  }, transcript.length === 0 ? /*#__PURE__*/React.createElement("p", {
    className: "muted",
    style: {
      margin: 0,
      fontSize: 11
    }
  }, "Ambient channel open \u2014 speak naturally, or say \"bring up notes sync\".") : transcript.map((l, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    style: {
      margin: '3px 0',
      fontSize: 11
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: l.role === 'user' ? 'var(--cyan)' : l.role === 'agent' ? 'var(--green)' : 'var(--yellow)'
    }
  }, l.role === 'user' ? 'YOU' : 'FOREMAN'), ' ', l.text)))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...railStyle,
      transformOrigin: 'right center',
      transform: `rotateY(${-16 + par.x * 3}deg) rotateX(${-par.y * 2.5}deg) translateZ(-26px)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "fui-module"
  }, /*#__PURE__*/React.createElement(Chip, {
    style: chipMini
  }, "COLLIDE . SET"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Knob, {
    value: stats.cpu,
    label: "READ"
  }), /*#__PURE__*/React.createElement(Knob, {
    value: 62,
    label: "WRITE"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "pill-white",
    onClick: () => addLine('agent', 'Port scan complete. No anomalies.')
  }, "Ports"), /*#__PURE__*/React.createElement("button", {
    className: "pill-white",
    onClick: () => addLine('agent', 'Scanning… clear.')
  }, "Scans"), /*#__PURE__*/React.createElement("button", {
    className: "pill-white dim"
  }, "Write")))), /*#__PURE__*/React.createElement("div", {
    className: "fui-module"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Capsule, {
    value: Math.round(stats.mem),
    label: "Fields"
  }), /*#__PURE__*/React.createElement(Capsule, {
    value: 34,
    label: "Nulls"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "DATA . COMP"), /*#__PURE__*/React.createElement("b", null, ".1")), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "CON . POS"), /*#__PURE__*/React.createElement("b", null, "4]")), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, "ALT"), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--green)'
    }
  }, "LOCKED"))))), /*#__PURE__*/React.createElement("div", {
    className: "fui-module"
  }, /*#__PURE__*/React.createElement(Chip, {
    style: chipMini
  }, "Projects"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, PROJECTS.map(p => /*#__PURE__*/React.createElement("button", {
    key: p.id,
    className: `hud-tab${mode === 'blueprint' && p.id === projectId ? ' active' : ''}`,
    style: {
      textAlign: 'left',
      textTransform: 'none',
      letterSpacing: 0,
      fontSize: 11,
      padding: '4px 8px'
    },
    onClick: () => bringUp(p.id)
  }, "\u25E2 ", p.name, " ", /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 9
    }
  }, "\u2014 ", p.status))))), lastCommand && /*#__PURE__*/React.createElement("div", {
    className: "fui-module"
  }, /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--cyan)'
    }
  }, "$ ", lastCommand.command)), /*#__PURE__*/React.createElement("div", {
    className: "micro-row"
  }, /*#__PURE__*/React.createElement("span", null, lastCommand.status))), /*#__PURE__*/React.createElement("form", {
    onSubmit: runManual,
    style: {
      marginTop: 'auto',
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: manualCmd,
    onChange: e => setManualCmd(e.target.value),
    placeholder: "type or say: \"bring up notes sync\"",
    style: {
      width: '100%',
      background: 'transparent',
      border: 'none',
      borderBottom: '1px solid var(--border)',
      borderRadius: 0,
      padding: '6px 2px',
      fontSize: 10
    }
  }))));
}
window.VoiceTab = VoiceTab;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/master_hud/VoiceTab.jsx", error: String((e && e.message) || e) }); }

// ui_kits/master_hud/WikiModal.jsx
try { (() => {
// Troubleshooting Wiki modal — searchable error log with add form.
const {
  Modal: WkModal,
  Button: WkButton,
  Input: WkInput,
  TextArea: WkTextArea
} = window.AIMasterHUDDesignSystem_8b9a29;
function WikiModal({
  onClose
}) {
  const [entries, setEntries] = React.useState(window.HudData.SEED_WIKI);
  const [query, setQuery] = React.useState('');
  const [adding, setAdding] = React.useState(false);
  const [draft, setDraft] = React.useState({
    agent: '',
    errorType: '',
    title: '',
    resolution: ''
  });
  const q = query.toLowerCase();
  const results = entries.filter(e => !q || [e.agent, e.errorType, e.title, e.resolution].some(f => f.toLowerCase().includes(q)));
  function save(e) {
    e.preventDefault();
    if (!draft.title.trim()) return;
    setEntries(prev => [{
      ...draft,
      id: String(Date.now()),
      date: new Date().toISOString().slice(0, 10)
    }, ...prev]);
    setDraft({
      agent: '',
      errorType: '',
      title: '',
      resolution: ''
    });
    setAdding(false);
  }
  return /*#__PURE__*/React.createElement(WkModal, {
    title: "\uD83D\uDEE0 TROUBLESHOOTING WIKI",
    onClose: onClose,
    width: 560
  }, /*#__PURE__*/React.createElement(WkInput, {
    value: query,
    onChange: e => setQuery(e.target.value),
    placeholder: "search by agent, error type, keyword\u2026",
    autoFocus: true,
    style: {
      width: '100%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      overflowY: 'auto',
      maxHeight: 320
    }
  }, results.length === 0 ? /*#__PURE__*/React.createElement("p", {
    className: "muted"
  }, "No entries match.") : results.map(e => /*#__PURE__*/React.createElement("div", {
    key: e.id,
    style: {
      border: '1px solid var(--border)',
      borderRadius: 2,
      padding: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      fontSize: 10,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cyan)'
    }
  }, e.agent), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--orange)'
    }
  }, e.errorType), /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, e.date)), /*#__PURE__*/React.createElement("strong", {
    style: {
      fontSize: 12
    }
  }, e.title), /*#__PURE__*/React.createElement("p", {
    className: "muted small",
    style: {
      margin: '4px 0 0'
    }
  }, e.resolution)))), adding ? /*#__PURE__*/React.createElement("form", {
    onSubmit: save,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(WkInput, {
    placeholder: "agent",
    value: draft.agent,
    onChange: e => setDraft({
      ...draft,
      agent: e.target.value
    }),
    style: {
      flex: 1,
      minWidth: 0
    }
  }), /*#__PURE__*/React.createElement(WkInput, {
    placeholder: "error type",
    value: draft.errorType,
    onChange: e => setDraft({
      ...draft,
      errorType: e.target.value
    }),
    style: {
      flex: 1,
      minWidth: 0
    }
  })), /*#__PURE__*/React.createElement(WkInput, {
    placeholder: "issue title",
    value: draft.title,
    onChange: e => setDraft({
      ...draft,
      title: e.target.value
    })
  }), /*#__PURE__*/React.createElement(WkTextArea, {
    placeholder: "resolution",
    value: draft.resolution,
    onChange: e => setDraft({
      ...draft,
      resolution: e.target.value
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(WkButton, {
    type: "submit"
  }, "Save"), /*#__PURE__*/React.createElement(WkButton, {
    type: "button",
    onClick: () => setAdding(false)
  }, "Cancel"))) : /*#__PURE__*/React.createElement(WkButton, {
    onClick: () => setAdding(true)
  }, "+ Log issue & fix"));
}
window.WikiModal = WikiModal;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/master_hud/WikiModal.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.ConnPill = __ds_scope.ConnPill;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.StatusDot = __ds_scope.StatusDot;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.AGENT_COLORS = __ds_scope.AGENT_COLORS;

__ds_ns.ChatLine = __ds_scope.ChatLine;

__ds_ns.CmdCard = __ds_scope.CmdCard;

__ds_ns.KVList = __ds_scope.KVList;

__ds_ns.SegBar = __ds_scope.SegBar;

__ds_ns.DEFAULT_STAGES = __ds_scope.DEFAULT_STAGES;

__ds_ns.StageFlow = __ds_scope.StageFlow;

__ds_ns.StatBar = __ds_scope.StatBar;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.SettingField = __ds_scope.SettingField;

__ds_ns.SettingRow = __ds_scope.SettingRow;

__ds_ns.TextArea = __ds_scope.TextArea;

__ds_ns.AgentFace = __ds_scope.AgentFace;

__ds_ns.HoloBlueprint = __ds_scope.HoloBlueprint;

__ds_ns.RingGauge = __ds_scope.RingGauge;

__ds_ns.Waveform = __ds_scope.Waveform;

})();
