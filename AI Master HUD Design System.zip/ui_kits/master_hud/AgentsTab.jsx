// Agents tab — roster, detail, per-agent settings.
const { Panel: AgPanel, Button: AgButton, StatusDot: AgDot, Select: AgSelect,
        SettingRow: AgRow, KVList: AgKV } = window.AIMasterHUDDesignSystem_8b9a29;

function AgentsTab() {
  const [agents, setAgents] = React.useState(window.HudData.SEED_AGENTS);
  const [activeId, setActiveId] = React.useState('foreman');
  const agent = agents.find((a) => a.id === activeId) || agents[0];

  function update(id, patch) {
    setAgents((list) => list.map((a) => (a.id === id ? { ...a, ...patch } : a)));
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '220px minmax(0, 1fr) 320px', gap: 14, alignItems: 'start' }}>
      <AgPanel title="Agents" style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {agents.map((a) => (
          <button
            key={a.id}
            className={`hud-tab${a.id === agent.id ? ' active' : ''}`}
            style={{ display: 'flex', alignItems: 'center', gap: 8, textAlign: 'left', textTransform: 'none', letterSpacing: 0, fontSize: 13 }}
            onClick={() => setActiveId(a.id)}
          >
            <AgDot status={a.status} />
            {a.name}
          </button>
        ))}
        <hr className="hud-rule" />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 10, color: 'var(--muted)' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap' }}><AgDot status="online" /> idle</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><AgDot status="processing" /> processing</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><AgDot status="warning" /> warning</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><AgDot status="offline" /> offline</span>
        </div>
      </AgPanel>

      <AgPanel corners>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <h2 style={{ margin: 0, color: 'var(--cyan)', letterSpacing: 2, fontSize: 18 }}>{agent.name}</h2>
          <AgDot status={agent.status} />
        </div>
        <p style={{ color: 'var(--muted)', fontSize: 12 }}>{agent.description}</p>
        <AgKV items={[
          ['Current task', agent.task],
          ['Model', agent.model],
          ['Provider', agent.provider],
          ['Reports to', agent.parent ? (agents.find((a) => a.id === agent.parent) || {}).name : '— (foreman)'],
        ]} />
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <AgButton onClick={() => update(agent.id, { status: 'processing', task: 'Restarting…' })}>↻ Restart</AgButton>
          <AgButton onClick={() => setActiveId(agent.id)}>★ Set active</AgButton>
          <AgButton onClick={() => alert(`Logs for ${agent.name} — connect a gateway to stream logs.`)}>☰ View logs</AgButton>
        </div>
      </AgPanel>

      <AgPanel title={`Settings — ${agent.name}`}>
        <AgRow label="Voice">
          <input type="checkbox" checked={agent.voiceEnabled} onChange={(e) => update(agent.id, { voiceEnabled: e.target.checked })} />
        </AgRow>
        <AgRow label="Stability">
          <AgSelect
            value={agent.stability}
            onChange={(e) => update(agent.id, { stability: Number(e.target.value) })}
            options={[
              { value: 0, label: '0.0 — expressive' },
              { value: 0.5, label: '0.5 — balanced' },
              { value: 1, label: '1.0 — stable' },
            ]}
          />
        </AgRow>
        <AgRow label="Latency tier">
          <AgSelect
            value={agent.latencyTier}
            onChange={(e) => update(agent.id, { latencyTier: Number(e.target.value) })}
            options={[1, 2, 3, 4].map((t) => ({ value: t, label: `tier ${t}` }))}
          />
        </AgRow>
        <AgRow label="Context window">
          <AgSelect
            value={agent.contextWindow}
            onChange={(e) => update(agent.id, { contextWindow: Number(e.target.value) })}
            options={[
              { value: 100000, label: '100k' },
              { value: 200000, label: '200k' },
              { value: 500000, label: '500k' },
            ]}
          />
        </AgRow>
        <h4 style={{ margin: '14px 0 6px', fontSize: 10, letterSpacing: 2, color: 'var(--muted)' }}>SYSTEM PROMPT (READ-ONLY)</h4>
        <pre style={{ fontSize: 11, color: 'var(--muted)', maxHeight: 180, overflowY: 'auto', margin: 0 }}>{agent.systemPrompt}</pre>
      </AgPanel>
    </div>
  );
}

window.AgentsTab = AgentsTab;
