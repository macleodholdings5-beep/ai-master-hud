// Voice stage — cinematic FUI per reference imagery. Borderless micro-data
// columns on the dark field, ghost typography, always-on ambient listening
// (no start/stop — the agent hears you and speaks when spoken to).
const { Chip, SegBar, Waveform, HoloBlueprint } = window.AIMasterHUDDesignSystem_8b9a29;
const { PROJECTS, driftStats } = window.HudData;

// auto-running ambient conversation (no API key in demo)
const VOICE_DEMO_SCRIPT = [
  [1800,  (a) => a.agent('Online. Listening.')],
  [4200,  (a) => a.user('Hey, what is the team working on?')],
  [6200,  (a) => a.agent('Scout is researching local-first sync engines. Builder is retrying a terminal handoff. All else idle.')],
  [10200, (a) => a.user('Bring up the master HUD project.')],
  [11800, (a) => { a.agent('Bringing up AI MASTER HUD. Four assemblies online — reactor core shows elevated load.'); a.bringUp('hud'); }],
];

// --- tiny canvas sparkline (frequency-display trace) ---
function SparkLine({ value, width = 184, height = 30 }) {
  const ref = React.useRef(null);
  const hist = React.useRef([]);
  React.useEffect(() => {
    const h = hist.current;
    h.push(value);
    if (h.length > 56) h.shift();
    const c = ref.current, ctx = c.getContext('2d');
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.strokeStyle = 'rgba(120, 220, 230, 0.75)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    h.forEach((v, i) => {
      const x = (i / 55) * c.width;
      const y = c.height - 3 - (v / 100) * (c.height - 6);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
    const lx = ((h.length - 1) / 55) * c.width;
    const ly = c.height - 3 - (h[h.length - 1] / 100) * (c.height - 6);
    ctx.fillStyle = '#eaf7ff';
    ctx.fillRect(lx - 1.5, ly - 1.5, 3, 3);
  }, [value]);
  return <canvas ref={ref} width={width} height={height} style={{ display: 'block' }}></canvas>;
}

// --- knob dial (READ / WRITE style) ---
function Knob({ value, label }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const c = ref.current, ctx = c.getContext('2d');
    const s = c.width, cx = s / 2, cy = s / 2, r = s / 2 - 5;
    ctx.clearRect(0, 0, s, s);
    const a0 = Math.PI * 0.75, a1 = Math.PI * 2.25;
    ctx.strokeStyle = 'rgba(58, 214, 255, 0.18)';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(cx, cy, r, a0, a1); ctx.stroke();
    ctx.strokeStyle = '#3ad6ff';
    ctx.beginPath(); ctx.arc(cx, cy, r, a0, a0 + (a1 - a0) * (value / 100)); ctx.stroke();
    ctx.fillStyle = '#eaf7ff';
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.42, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#06222c';
    const na = a0 + (a1 - a0) * (value / 100);
    ctx.fillRect(cx + Math.cos(na) * r * 0.28 - 1, cy + Math.sin(na) * r * 0.28 - 1, 2.5, 2.5);
  }, [value]);
  return (
    <div style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
      <canvas ref={ref} width={46} height={46} style={{ display: 'block' }}></canvas>
      <span style={{ fontSize: 8, letterSpacing: 1, color: 'var(--muted)' }}>{label}</span>
    </div>
  );
}

function Capsule({ value, label }) {
  return (
    <div className="capsule">
      <div className="track"><div className="fill" style={{ height: `${value}%` }}></div></div>
      <span className="cap-label">{label}</span>
    </div>
  );
}

function VoiceTab() {
  const [userSpeaking, setUserSpeaking] = React.useState(false);
  const [agentSpeaking, setAgentSpeaking] = React.useState(false);
  const [transcript, setTranscript] = React.useState([]);
  const [mode, setMode] = React.useState('avatar'); // avatar | blueprint
  const [projectId, setProjectId] = React.useState('hud');
  const [selPart, setSelPart] = React.useState(0);
  const [stats, setStats] = React.useState(driftStats());
  const [lastCommand, setLastCommand] = React.useState(null);
  const [manualCmd, setManualCmd] = React.useState('');
  const [par, setPar] = React.useState({ x: 0, y: 0 }); // mouse parallax -1..1
  const rootRef = React.useRef(null);
  const timers = React.useRef([]);

  function onParallax(e) {
    const r = rootRef.current && rootRef.current.getBoundingClientRect();
    if (!r) return;
    setPar({
      x: ((e.clientX - r.left) / r.width) * 2 - 1,
      y: ((e.clientY - r.top) / r.height) * 2 - 1,
    });
  }

  const project = PROJECTS.find((p) => p.id === projectId) || PROJECTS[0];
  const part = project.parts[Math.min(selPart, project.parts.length - 1)];

  function addLine(role, text) {
    setTranscript((t) => [...t.slice(-30), { role, text }]);
  }

  function bringUp(idOrName) {
    const p = PROJECTS.find(
      (x) => x.id === idOrName || x.name.toLowerCase().includes(String(idOrName).toLowerCase())
    );
    if (p) { setProjectId(p.id); setSelPart(0); setMode('blueprint'); return p; }
    return null;
  }

  // always-on: telemetry drift + ambient conversation start automatically
  React.useEffect(() => {
    const iv = setInterval(() => setStats((s) => driftStats(s)), 1400);
    const api = {
      user: (text) => { setUserSpeaking(true); addLine('user', text); timers.current.push(setTimeout(() => setUserSpeaking(false), 1500)); },
      agent: (text) => { setAgentSpeaking(true); addLine('agent', text); timers.current.push(setTimeout(() => setAgentSpeaking(false), 2600)); },
      bringUp,
    };
    VOICE_DEMO_SCRIPT.forEach(([delay, fn]) => timers.current.push(setTimeout(() => fn(api), delay)));
    return () => { clearInterval(iv); timers.current.forEach(clearTimeout); };
  }, []);

  function runManual(e) {
    e.preventDefault();
    const cmd = manualCmd.trim();
    if (!cmd) return;
    setManualCmd('');
    const up = cmd.match(/^bring up (.+)$/i);
    if (up) {
      const p = bringUp(up[1]);
      addLine('agent', p ? `Bringing up ${p.name.toUpperCase()}.` : `No project matching "${up[1]}".`);
      return;
    }
    if (/^(stand down|close|avatar)$/i.test(cmd)) { setMode('avatar'); addLine('agent', 'Standing down.'); return; }
    setLastCommand({ command: cmd, status: 'RUNNING' });
    timers.current.push(setTimeout(() => setLastCommand({ command: cmd, status: 'OK · EXECUTED ON HOMELAB' }), 900));
  }

  const railStyle = { display: 'flex', flexDirection: 'column', paddingTop: 6, transition: 'transform 0.25s ease-out' };
  const chipMini = { fontSize: 9, padding: '2px 8px' };

  return (
    <div
      ref={rootRef}
      onMouseMove={onParallax}
      onMouseLeave={() => setPar({ x: 0, y: 0 })}
      style={{ display: 'grid', gridTemplateColumns: '200px minmax(0, 1fr) 230px', gap: 22, height: '100%', perspective: 1400, transformStyle: 'preserve-3d' }}
    >

      {/* ---- left rail: frequency displays — angled glass panel ---- */}
      <div style={{ ...railStyle, transformOrigin: 'left center', transform: `rotateY(${16 + par.x * 3}deg) rotateX(${-par.y * 2.5}deg) translateZ(-26px)` }}>
        {[['CPU . LOAD', stats.cpu, `${Math.round(stats.cpu)}%`],
          ['MEM . POOL', stats.mem, `${Math.round(stats.mem)}%`],
          ['NET . LINK', Math.min(100, stats.latency / 2.4), `${Math.round(stats.latency)}MS`]].map(([label, v, read]) => (
          <div className="fui-module" key={label}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Chip style={chipMini}>{label}</Chip>
              <span style={{ fontSize: 9, color: 'var(--ice)' }}>{read}</span>
            </div>
            <SparkLine value={v} />
            <div className="micro-row"><span>FRONT VIEW</span><span>OPEN PLATE</span><b>R87</b></div>
          </div>
        ))}
        <div className="fui-module">
          <span className="hud-label" style={{ fontSize: 9 }}>MAINT . INT</span>
          <div className="seg-bar"><div className="seg-fill" style={{ width: `${Math.round(100 - stats.cpu)}%` }}></div></div>
          <div className="micro-row"><span>⊞FILL . IN</span><span>⊞ACTIVE . ID</span></div>
        </div>
        <div className="fui-module">
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <window.MiniRing value={Math.round(stats.cpu)} />
            <div>
              <div style={{ fontSize: 12, color: '#eaf7ff' }}>0.0981243</div>
              <div className="micro-row"><span>DRIFT . IDX</span></div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <window.MiniRing value={Math.round(stats.mem)} />
            <div>
              <div style={{ fontSize: 12, color: '#eaf7ff' }}>1.1892656</div>
              <div className="micro-row"><span>SYNC . RATIO</span></div>
            </div>
          </div>
        </div>
        <div className="fui-module" style={{ alignSelf: 'stretch' }}>
          <span className="hud-label" style={{ fontSize: 9 }}>L O A D I N G</span>
          <div className="hatch-bar" style={{ width: '100%' }}><div className="hatch-fill" style={{ width: `${Math.round(stats.disk)}%` }}></div></div>
        </div>
        <div className="fui-module">
          <div className="micro-row"><span>FIREWALL</span><b style={{ color: 'var(--green)' }}>ACTIVE</b></div>
          <div className="micro-row"><span>THREATS</span><b style={{ color: 'var(--green)' }}>NONE</b></div>
          <div className="micro-row"><span>CAM-01</span><b>NO FEED</b></div>
        </div>
        <div className="tick-ruler" style={{ marginTop: 16 }}></div>
      </div>

      {/* ---- center: stage ---- */}
      {/* ---- center: stage — parallax hologram ---- */}
      <section style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, minWidth: 0, transformStyle: 'preserve-3d' }}>
        <window.PlexusBG width={900} height={560} />
        <div className="ghost-type" style={{ top: -6, fontSize: 64, filter: 'blur(1.5px)', transform: 'translateZ(-80px)' }}>
          {mode === 'avatar' ? 'FOREMAN' : project.name}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, transformStyle: 'preserve-3d', transition: 'transform 0.25s ease-out', transform: `rotateY(${par.x * 5}deg) rotateX(${-par.y * 5}deg) translateZ(14px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, zIndex: 1 }}>
          <Chip style={chipMini}>{mode === 'avatar' ? 'PARTICLE VIEW' : 'ATOM_VIEW'}</Chip>
          <span style={{ fontSize: 13, letterSpacing: 3, color: '#eaf7ff', textShadow: 'var(--text-glow-cyan)' }}>
            {mode === 'avatar' ? 'FOREMAN' : project.name.toUpperCase()}
          </span>
          <span style={{ fontSize: 9, letterSpacing: 1, color: agentSpeaking ? 'var(--cyan)' : 'var(--muted)' }}>
            {agentSpeaking ? '● SPEAKING' : userSpeaking ? '● HEARING YOU' : '● LISTENING'}
          </span>
        </div>

        {mode === 'avatar' ? (
          <div style={{ position: 'relative', width: 440, height: 440, zIndex: 1 }}>
            <window.RingDial size={440} active={agentSpeaking} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <window.HoloPortrait speaking={agentSpeaking} size={310} />
            </div>
          </div>
        ) : (
          <div style={{ width: '100%', maxWidth: 780 }}>
            <HoloBlueprint
              width={780}
              height={360}
              parts={project.parts}
              selected={selPart}
              onSelectPart={setSelPart}
            />
            <div style={{ display: 'flex', gap: 26, alignItems: 'flex-start', borderTop: '1px solid var(--border)', paddingTop: 10, marginTop: 4, flexWrap: 'wrap' }}>
              <div style={{ minWidth: 200, flex: 1 }}>
                <Chip style={chipMini}>{part.label}</Chip>
                <p style={{ margin: '6px 0 6px', fontSize: 11, color: 'var(--text)' }}>{part.task}</p>
                <SegBar value={part.health} color="cyan" style={{ maxWidth: 230 }} />
              </div>
              <div>
                <div className="hud-label" style={{ fontSize: 8, marginBottom: 5 }}>SYSTEM_CHECK</div>
                <div style={{ display: 'flex', gap: 18 }}>
                  {project.parts.map((p, i) => (
                    <div key={p.label} style={{ cursor: 'pointer', opacity: i === selPart ? 1 : 0.55 }} onClick={() => setSelPart(i)}>
                      <div style={{ fontSize: 17, fontWeight: 700, color: '#eaf7ff', textShadow: i === selPart ? 'var(--text-glow-cyan)' : 'none' }}>{p.health}%</div>
                      <div style={{ fontSize: 7, color: 'var(--muted)', letterSpacing: 1 }}>{String(p.label).slice(0, 10).toUpperCase()}</div>
                    </div>
                  ))}
                </div>
              </div>
              <button className="hud-btn" style={{ fontSize: 9, padding: '4px 10px' }} onClick={() => setMode('avatar')}>◤ Stand down</button>
            </div>
          </div>
        )}
        </div>

        <div style={{ transform: 'perspective(800px) rotateX(7deg)', transformOrigin: 'center bottom' }}>
          <Waveform userSpeaking={userSpeaking} agentSpeaking={agentSpeaking} width={560} height={44} />
        </div>

        <div style={{ width: '100%', maxWidth: 640, flex: 1, overflowY: 'auto', minHeight: 48, borderTop: '1px solid var(--border)', paddingTop: 8, transform: 'perspective(900px) rotateX(9deg)', transformOrigin: 'center top' }}>
          {transcript.length === 0 ? (
            <p className="muted" style={{ margin: 0, fontSize: 11 }}>Ambient channel open — speak naturally, or say "bring up notes sync".</p>
          ) : (
            transcript.map((l, i) => (
              <p key={i} style={{ margin: '3px 0', fontSize: 11 }}>
                <strong style={{ color: l.role === 'user' ? 'var(--cyan)' : l.role === 'agent' ? 'var(--green)' : 'var(--yellow)' }}>
                  {l.role === 'user' ? 'YOU' : 'FOREMAN'}
                </strong>{' '}
                {l.text}
              </p>
            ))
          )}
        </div>
      </section>

      {/* ---- right rail — angled glass panel ---- */}
      <div style={{ ...railStyle, transformOrigin: 'right center', transform: `rotateY(${-16 + par.x * 3}deg) rotateX(${-par.y * 2.5}deg) translateZ(-26px)` }}>
        <div className="fui-module">
          <Chip style={chipMini}>COLLIDE . SET</Chip>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <Knob value={stats.cpu} label="READ" />
            <Knob value={62} label="WRITE" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              <button className="pill-white" onClick={() => addLine('agent', 'Port scan complete. No anomalies.')}>Ports</button>
              <button className="pill-white" onClick={() => addLine('agent', 'Scanning… clear.')}>Scans</button>
              <button className="pill-white dim">Write</button>
            </div>
          </div>
        </div>
        <div className="fui-module">
          <div style={{ display: 'flex', gap: 18 }}>
            <Capsule value={Math.round(stats.mem)} label="Fields" />
            <Capsule value={34} label="Nulls" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4, justifyContent: 'center' }}>
              <div className="micro-row"><span>DATA . COMP</span><b>.1</b></div>
              <div className="micro-row"><span>CON . POS</span><b>4]</b></div>
              <div className="micro-row"><span>ALT</span><b style={{ color: 'var(--green)' }}>LOCKED</b></div>
            </div>
          </div>
        </div>
        <div className="fui-module">
          <Chip style={chipMini}>Projects</Chip>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {PROJECTS.map((p) => (
              <button
                key={p.id}
                className={`hud-tab${mode === 'blueprint' && p.id === projectId ? ' active' : ''}`}
                style={{ textAlign: 'left', textTransform: 'none', letterSpacing: 0, fontSize: 11, padding: '4px 8px' }}
                onClick={() => bringUp(p.id)}
              >
                ◢ {p.name} <span className="muted" style={{ fontSize: 9 }}>— {p.status}</span>
              </button>
            ))}
          </div>
        </div>
        {lastCommand && (
          <div className="fui-module">
            <div className="micro-row"><b style={{ color: 'var(--cyan)' }}>$ {lastCommand.command}</b></div>
            <div className="micro-row"><span>{lastCommand.status}</span></div>
          </div>
        )}
        <form onSubmit={runManual} style={{ marginTop: 'auto', paddingTop: 14 }}>
          <input
            value={manualCmd}
            onChange={(e) => setManualCmd(e.target.value)}
            placeholder='type or say: "bring up notes sync"'
            style={{ width: '100%', background: 'transparent', border: 'none', borderBottom: '1px solid var(--border)', borderRadius: 0, padding: '6px 2px', fontSize: 10 }}
          />
        </form>
      </div>
    </div>
  );
}

window.VoiceTab = VoiceTab;
