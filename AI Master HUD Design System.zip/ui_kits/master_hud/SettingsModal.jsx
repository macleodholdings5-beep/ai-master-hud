// Settings modal — gateway, keys, transcript toggle. Persists to localStorage.
const { Modal: StModal, Button: StButton, Input: StInput, SettingRow: StRow,
        SettingField: StField } = window.AIMasterHUDDesignSystem_8b9a29;

const ST_DEFAULTS = { gatewayUrl: '', gatewayToken: '', openaiApiKey: '', showTranscript: true };

function SettingsModal({ onClose }) {
  const saved = (() => { try { return JSON.parse(localStorage.getItem('hud-settings') || '{}'); } catch (err) { return {}; } })();
  const [draft, setDraft] = React.useState({ ...ST_DEFAULTS, ...saved });

  function save(e) {
    e.preventDefault();
    localStorage.setItem('hud-settings', JSON.stringify(draft));
    onClose();
  }

  return (
    <StModal title="⚙ SETTINGS" onClose={onClose}>
      <form onSubmit={save} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <StField label="OpenClaw gateway URL (WebSocket)">
          <StInput value={draft.gatewayUrl} onChange={(e) => setDraft({ ...draft, gatewayUrl: e.target.value })} placeholder="ws://homelab.local:18789 — leave empty for demo mode" />
        </StField>
        <StField label="Gateway auth token">
          <StInput type="password" value={draft.gatewayToken} onChange={(e) => setDraft({ ...draft, gatewayToken: e.target.value })} placeholder="optional" />
        </StField>
        <StField label="OpenAI API key (Realtime voice)">
          <StInput type="password" value={draft.openaiApiKey} onChange={(e) => setDraft({ ...draft, openaiApiKey: e.target.value })} placeholder="sk-…" />
        </StField>
        <StRow label="Show live transcript">
          <input type="checkbox" checked={draft.showTranscript} onChange={(e) => setDraft({ ...draft, showTranscript: e.target.checked })} />
        </StRow>
        <p className="muted small">Remote access: point the gateway URL at a Tailscale Funnel / ngrok tunnel to your home lab. Keys are stored locally only.</p>
        <StButton type="submit" variant="solid">Save &amp; reconnect</StButton>
      </form>
    </StModal>
  );
}

window.SettingsModal = SettingsModal;
