// Idea Pipeline tab — capture zone + idea cards with ⭐ review gate.
const { Panel: PiPanel, Button: PiButton, Input: PiInput,
        StageFlow: PiStageFlow } = window.AIMasterHUDDesignSystem_8b9a29;

function PipelineTab() {
  const [ideas, setIdeas] = React.useState(window.HudData.SEED_IDEAS);
  const [title, setTitle] = React.useState('');
  const [expanded, setExpanded] = React.useState({});
  const [feedback, setFeedback] = React.useState({});

  function capture(e) {
    e.preventDefault();
    const t = title.trim();
    if (!t) return;
    setTitle('');
    setIdeas((prev) => [
      { id: `idea-${Date.now()}`, title: t, capturedAt: Date.now(), stage: 0, stageStatus: 'active', research: null, plan: null, buildLog: [], output: null },
      ...prev,
    ]);
  }

  function review(id, approve) {
    setIdeas((prev) => prev.map((i) => {
      if (i.id !== id) return i;
      return approve
        ? { ...i, stage: 4, stageStatus: 'active' }
        : { ...i, stage: 2, stageStatus: 'active' };
    }));
  }

  const sorted = [...ideas].sort((a, b) => b.capturedAt - a.capturedAt);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14, maxWidth: 1100, margin: '0 auto' }}>
      <PiPanel title="Capture Zone" corners>
        <p className="muted small" style={{ margin: '0 0 10px' }}>
          Voice: say "capture this idea: …" in the Voice Chat tab — or type it here.
        </p>
        <form onSubmit={capture} style={{ display: 'flex', gap: 8 }}>
          <PiInput value={title} onChange={(e) => setTitle(e.target.value)} placeholder="capture this idea…" style={{ flex: 1 }} />
          <PiButton type="submit" variant="solid">+ Capture</PiButton>
        </form>
      </PiPanel>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {sorted.map((idea) => {
          const atGate = idea.stage === 3 && idea.stageStatus === 'waiting';
          const isExp = !!expanded[idea.id];
          return (
            <div key={idea.id} className="hud-panel" style={{ boxShadow: atGate ? 'var(--glow-gate)' : 'none', borderColor: atGate ? 'var(--yellow)' : undefined }}>
              <div
                style={{ display: 'flex', justifyContent: 'space-between', gap: 10, cursor: 'pointer', marginBottom: 10 }}
                onClick={() => setExpanded((ex) => ({ ...ex, [idea.id]: !ex[idea.id] }))}
              >
                <strong>{idea.title}</strong>
                <span className="muted small">{new Date(idea.capturedAt).toLocaleString()}</span>
              </div>
              <PiStageFlow current={idea.stage} status={idea.stageStatus} />
              {idea.research && (
                <p className="muted small" style={{ marginTop: 8 }}>
                  📚 {idea.research.sources} sources · 🎬 {idea.research.videos} videos — {idea.research.summary}
                </p>
              )}
              {atGate && (
                <div style={{ borderTop: '1px dashed var(--yellow)', marginTop: 10, paddingTop: 10 }}>
                  <h4 style={{ margin: '0 0 8px', color: 'var(--yellow)', fontSize: 11, letterSpacing: 2 }}>⭐ REVIEW GATE — HUMAN APPROVAL REQUIRED</h4>
                  <pre style={{ background: 'var(--inset)', padding: 8, borderRadius: 2, fontSize: 12, marginBottom: 8 }}>{idea.plan}</pre>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <PiButton variant="approve" onClick={() => review(idea.id, true)}>✓ Good, go ahead</PiButton>
                    <PiInput
                      value={feedback[idea.id] || ''}
                      onChange={(e) => setFeedback((f) => ({ ...f, [idea.id]: e.target.value }))}
                      placeholder="what needs to change?"
                      style={{ flex: 1 }}
                    />
                    <PiButton variant="reject" onClick={() => review(idea.id, false)}>↩ Need changes</PiButton>
                  </div>
                </div>
              )}
              {idea.output && (
                <p style={{ color: 'var(--green)', marginTop: 8, fontSize: 12 }}>✓ Built → <code>{idea.output}</code></p>
              )}
              {isExp && (
                <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <h4 style={{ margin: 0, fontSize: 10, letterSpacing: 2, color: 'var(--muted)' }}>BUILD LOG</h4>
                  {idea.buildLog.length ? (
                    <pre style={{ margin: 0 }}>{idea.buildLog.join('\n')}</pre>
                  ) : (
                    <p className="muted small" style={{ margin: 0 }}>No build activity yet.</p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.PipelineTab = PipelineTab;
