// Chat Room tab — foreman banner, agent-to-agent log, command input, hierarchy.
const { Panel: CrPanel, Button: CrButton, StatusDot: CrDot, Input: CrInput,
        ChatLine: CrLine, AGENT_COLORS: CR_COLORS } = window.AIMasterHUDDesignSystem_8b9a29;

function CrHierarchyNode({ agent, agents, depth }) {
  const children = agents.filter((a) => a.parent === agent.id);
  return (
    <div style={{ paddingLeft: depth * 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 0' }}>
        <CrDot status={agent.status} />
        <span style={{ fontWeight: 700, color: CR_COLORS[agent.name] || 'var(--ice)' }}>{agent.name}</span>
      </div>
      <div style={{ fontSize: 10, color: 'var(--muted)', paddingLeft: 16 }}>{agent.task}</div>
      {children.map((c) => (
        <CrHierarchyNode key={c.id} agent={c} agents={agents} depth={depth + 1} />
      ))}
    </div>
  );
}

function ChatRoomTab() {
  const [messages, setMessages] = React.useState(window.HudData.SEED_CHAT);
  const [input, setInput] = React.useState('');
  const logRef = React.useRef(null);
  const agents = window.HudData.SEED_AGENTS;
  const foreman = agents.find((a) => !a.parent);

  React.useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [messages]);

  function submit(e) {
    e.preventDefault();
    const text = input.trim();
    if (!text) return;
    setInput('');
    const now = Date.now();
    setMessages((m) => [...m, { id: now, agent: 'You', text, ts: now, user: true }]);
    setTimeout(() => {
      setMessages((m) => [
        ...m,
        { id: now + 1, agent: 'Foreman', text: `Acknowledged. Delegating: "${text}".`, ts: Date.now() },
        { id: now + 2, agent: 'System', text: `Task assigned: ${text} → Scout.`, ts: Date.now(), system: true },
      ]);
    }, 700);
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 280px', gap: 14, height: '100%' }}>
      <section style={{ display: 'flex', flexDirection: 'column', gap: 10, minWidth: 0 }}>
        <CrPanel style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 10, letterSpacing: 2, color: 'var(--muted)' }}>FOREMAN</span>
          <CrDot status={foreman.status} />
          <strong style={{ color: 'var(--green)' }}>{foreman.name}</strong>
          <span className="muted small">{foreman.task}</span>
        </CrPanel>
        <div className="hud-panel" ref={logRef} style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 5 }}>
          {messages.map((m) => (
            <CrLine key={m.id} ts={m.ts} agent={m.agent} text={m.text} system={m.system} user={m.user} />
          ))}
        </div>
        <form onSubmit={submit} style={{ display: 'flex', gap: 8 }}>
          <CrInput
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder='Command the team… e.g. "tell the team to research X"'
            style={{ flex: 1 }}
          />
          <CrButton type="submit">Send</CrButton>
        </form>
      </section>
      <CrPanel title="Hierarchy" corners>
        <CrHierarchyNode agent={foreman} agents={agents} depth={0} />
      </CrPanel>
    </div>
  );
}

window.ChatRoomTab = ChatRoomTab;
