// Troubleshooting Wiki modal — searchable error log with add form.
const { Modal: WkModal, Button: WkButton, Input: WkInput,
        TextArea: WkTextArea } = window.AIMasterHUDDesignSystem_8b9a29;

function WikiModal({ onClose }) {
  const [entries, setEntries] = React.useState(window.HudData.SEED_WIKI);
  const [query, setQuery] = React.useState('');
  const [adding, setAdding] = React.useState(false);
  const [draft, setDraft] = React.useState({ agent: '', errorType: '', title: '', resolution: '' });

  const q = query.toLowerCase();
  const results = entries.filter(
    (e) => !q || [e.agent, e.errorType, e.title, e.resolution].some((f) => f.toLowerCase().includes(q))
  );

  function save(e) {
    e.preventDefault();
    if (!draft.title.trim()) return;
    setEntries((prev) => [
      { ...draft, id: String(Date.now()), date: new Date().toISOString().slice(0, 10) },
      ...prev,
    ]);
    setDraft({ agent: '', errorType: '', title: '', resolution: '' });
    setAdding(false);
  }

  return (
    <WkModal title="🛠 TROUBLESHOOTING WIKI" onClose={onClose} width={560}>
      <WkInput
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="search by agent, error type, keyword…"
        autoFocus
        style={{ width: '100%' }}
      />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, overflowY: 'auto', maxHeight: 320 }}>
        {results.length === 0 ? (
          <p className="muted">No entries match.</p>
        ) : results.map((e) => (
          <div key={e.id} style={{ border: '1px solid var(--border)', borderRadius: 2, padding: 8 }}>
            <div style={{ display: 'flex', gap: 10, fontSize: 10, marginBottom: 4 }}>
              <span style={{ color: 'var(--cyan)' }}>{e.agent}</span>
              <span style={{ color: 'var(--orange)' }}>{e.errorType}</span>
              <span className="muted">{e.date}</span>
            </div>
            <strong style={{ fontSize: 12 }}>{e.title}</strong>
            <p className="muted small" style={{ margin: '4px 0 0' }}>{e.resolution}</p>
          </div>
        ))}
      </div>
      {adding ? (
        <form onSubmit={save} style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ display: 'flex', gap: 8 }}>
            <WkInput placeholder="agent" value={draft.agent} onChange={(e) => setDraft({ ...draft, agent: e.target.value })} style={{ flex: 1, minWidth: 0 }} />
            <WkInput placeholder="error type" value={draft.errorType} onChange={(e) => setDraft({ ...draft, errorType: e.target.value })} style={{ flex: 1, minWidth: 0 }} />
          </div>
          <WkInput placeholder="issue title" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
          <WkTextArea placeholder="resolution" value={draft.resolution} onChange={(e) => setDraft({ ...draft, resolution: e.target.value })} />
          <div style={{ display: 'flex', gap: 8 }}>
            <WkButton type="submit">Save</WkButton>
            <WkButton type="button" onClick={() => setAdding(false)}>Cancel</WkButton>
          </div>
        </form>
      ) : (
        <WkButton onClick={() => setAdding(true)}>+ Log issue &amp; fix</WkButton>
      )}
    </WkModal>
  );
}

window.WikiModal = WikiModal;
