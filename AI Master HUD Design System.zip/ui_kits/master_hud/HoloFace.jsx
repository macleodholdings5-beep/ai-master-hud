// HoloFace — original holographic woman, hand-drawn vector portrait rendered
// as a blue hologram: bezier line-art face, luminous skin shading, scanline
// raster, glitch slices, blink + articulated mouth. Plus RingDial, PlexusBG,
// MiniRing instruments. All canvas-generative; shared via window.
(function () {

  // ================= HoloFace =================
  function HoloFace({ speaking = false, width = 310, height = 310 }) {
    const ref = React.useRef(null);
    const spk = React.useRef(speaking);
    spk.current = speaking;

    React.useEffect(() => {
      const canvas = ref.current, ctx = canvas.getContext('2d');
      const S = canvas.width;
      const off = document.createElement('canvas');
      off.width = S; off.height = S;
      const o = off.getContext('2d');

      const sc = S * 0.55, cx = S / 2, cy0 = S * 0.37;
      let raf, t = 0, blink = 0, glitch = 0, gShift = 0, gY = 0;

      const X = (x) => cx + x * sc;
      let cy = cy0;
      const Y = (y) => cy + y * sc;

      function strokePath(pts, color, lw) {
        o.strokeStyle = color; o.lineWidth = lw; o.lineCap = 'round';
        o.beginPath();
        o.moveTo(X(pts[0][0]), Y(pts[0][1]));
        for (let i = 1; i < pts.length; i += 3) {
          o.bezierCurveTo(X(pts[i][0]), Y(pts[i][1]), X(pts[i + 1][0]), Y(pts[i + 1][1]), X(pts[i + 2][0]), Y(pts[i + 2][1]));
        }
        o.stroke();
      }

      function facePath() {
        o.beginPath();
        o.moveTo(X(0), Y(-0.52));
        o.bezierCurveTo(X(0.22), Y(-0.52), X(0.355), Y(-0.34), X(0.365), Y(-0.10));
        o.bezierCurveTo(X(0.372), Y(0.08), X(0.345), Y(0.18), X(0.30), Y(0.30));
        o.bezierCurveTo(X(0.24), Y(0.42), X(0.12), Y(0.50), X(0), Y(0.515));
        o.bezierCurveTo(X(-0.12), Y(0.50), X(-0.24), Y(0.42), X(-0.30), Y(0.30));
        o.bezierCurveTo(X(-0.345), Y(0.18), X(-0.372), Y(0.08), X(-0.365), Y(-0.10));
        o.bezierCurveTo(X(-0.355), Y(-0.34), X(-0.22), Y(-0.52), X(0), Y(-0.52));
        o.closePath();
      }

      function radial(x, y, r, c0, c1) {
        const g = o.createRadialGradient(X(x), Y(y), 0, X(x), Y(y), r * sc);
        g.addColorStop(0, c0); g.addColorStop(1, c1);
        o.fillStyle = g;
        o.fillRect(X(x) - r * sc, Y(y) - r * sc, r * sc * 2, r * sc * 2);
      }

      function drawPortrait(open, lid, gazeX) {
        o.clearRect(0, 0, S, S);

        // ---- neck + shoulders ----
        for (const s of [-1, 1]) {
          strokePath([[s * 0.16, 0.47], [s * 0.145, 0.58], [s * 0.15, 0.66], [s * 0.185, 0.745],
                      [s * 0.27, 0.83], [s * 0.46, 0.875], [s * 0.62, 0.93]], 'rgba(120,180,240,0.55)', 1.4);
          // collarbone
          strokePath([[s * 0.05, 0.91], [s * 0.16, 0.865], [s * 0.28, 0.862], [s * 0.385, 0.88]], 'rgba(120,180,240,0.30)', 1.2);
        }
        // chest sheen
        radial(0, 0.86, 0.34, 'rgba(80,150,235,0.10)', 'rgba(0,0,0,0)');
        // circuit traces
        o.lineWidth = 1;
        o.strokeStyle = 'rgba(200,240,255,0.65)';
        for (const tr of [[[0.035, 0.62], [0.035, 0.78], [0.115, 0.78], [0.115, 0.92]],
                          [[-0.07, 0.70], [-0.07, 0.84], [-0.20, 0.84], [-0.20, 0.95]]]) {
          o.beginPath();
          o.moveTo(X(tr[0][0]), Y(tr[0][1]));
          for (let i = 1; i < tr.length; i++) o.lineTo(X(tr[i][0]), Y(tr[i][1]));
          o.stroke();
          o.fillStyle = 'rgba(240,250,255,0.9)';
          o.fillRect(X(tr[tr.length - 1][0]) - 1.5, Y(tr[tr.length - 1][1]) - 1.5, 3, 3);
        }

        // ---- face fill + shading ----
        o.save();
        facePath();
        o.clip();
        o.fillStyle = 'rgba(70,140,230,0.13)';
        o.fillRect(0, 0, S, S);
        radial(0, -0.06, 0.46, 'rgba(140,200,255,0.16)', 'rgba(0,0,0,0)');   // center light
        radial(0, -0.30, 0.26, 'rgba(150,210,255,0.10)', 'rgba(0,0,0,0)');   // forehead
        radial(0.30, 0.06, 0.20, 'rgba(8,20,60,0.25)', 'rgba(0,0,0,0)');     // side shade
        radial(-0.30, 0.06, 0.20, 'rgba(8,20,60,0.25)', 'rgba(0,0,0,0)');
        radial(0.19, 0.17, 0.12, 'rgba(150,210,255,0.10)', 'rgba(0,0,0,0)'); // cheeks
        radial(-0.19, 0.17, 0.12, 'rgba(150,210,255,0.10)', 'rgba(0,0,0,0)');
        o.restore();
        facePath();
        o.strokeStyle = 'rgba(150,205,255,0.55)';
        o.lineWidth = 1.3;
        o.stroke();
        // under-chin shadow
        radial(0, 0.585, 0.13, 'rgba(4,12,40,0.40)', 'rgba(0,0,0,0)');

        // ---- eyes ----
        for (const s of [-1, 1]) {
          const ex = s * 0.17, ey = -0.005;
          const lidDrop = lid * 0.055;
          // iris (clipped by eye almond)
          o.save();
          o.beginPath();
          o.moveTo(X(ex - s * 0.085), Y(0.008));
          o.bezierCurveTo(X(ex - s * 0.03), Y(-0.038 + lidDrop), X(ex + s * 0.04), Y(-0.034 + lidDrop), X(ex + s * 0.082), Y(-0.002));
          o.bezierCurveTo(X(ex + s * 0.02), Y(0.030), X(ex - s * 0.03), Y(0.026), X(ex - s * 0.085), Y(0.008));
          o.closePath();
          o.clip();
          if (lid < 0.7) {
            const ix = ex + gazeX, iy = -0.004;
            o.strokeStyle = 'rgba(200,235,255,0.95)';
            o.lineWidth = 1.6;
            o.beginPath(); o.arc(X(ix), Y(iy), 0.035 * sc, 0, Math.PI * 2); o.stroke();
            o.fillStyle = 'rgba(120,190,250,0.35)';
            o.beginPath(); o.arc(X(ix), Y(iy), 0.034 * sc, 0, Math.PI * 2); o.fill();
            o.fillStyle = 'rgba(6,16,45,0.95)';
            o.beginPath(); o.arc(X(ix), Y(iy), 0.0135 * sc, 0, Math.PI * 2); o.fill();
            o.fillStyle = 'rgba(245,252,255,0.95)';
            o.beginPath(); o.arc(X(ix - 0.011), Y(iy - 0.011), 0.006 * sc, 0, Math.PI * 2); o.fill();
          }
          o.restore();
          // lids
          strokePath([[ex - s * 0.085, 0.008], [ex - s * 0.03, -0.038 + lidDrop], [ex + s * 0.04, -0.034 + lidDrop], [ex + s * 0.082, -0.002]],
            'rgba(190,228,255,0.95)', 1.7);
          strokePath([[ex + s * 0.082, -0.002], [ex + s * 0.02, 0.030], [ex - s * 0.03, 0.026], [ex - s * 0.085, 0.008]],
            'rgba(140,195,250,0.35)', 1.1);
          // lash flick
          strokePath([[ex + s * 0.082, -0.002], [ex + s * 0.092, -0.008], [ex + s * 0.098, -0.012], [ex + s * 0.106, -0.018]],
            'rgba(190,228,255,0.8)', 1.6);
          // crease
          strokePath([[ex - s * 0.07, -0.030], [ex - s * 0.01, -0.052], [ex + s * 0.03, -0.050], [ex + s * 0.062, -0.028]],
            'rgba(130,185,245,0.28)', 1);
          // brow — two-pass taper
          strokePath([[ex - s * 0.105, -0.082], [ex - s * 0.03, -0.118], [ex + s * 0.03, -0.112], [ex + s * 0.098, -0.086]],
            'rgba(95,155,235,0.55)', 3);
          strokePath([[ex - s * 0.095, -0.085], [ex - s * 0.03, -0.114], [ex + s * 0.03, -0.108], [ex + s * 0.088, -0.088]],
            'rgba(150,200,255,0.75)', 1.4);
          // nostril + alar
          strokePath([[s * 0.050, 0.206], [s * 0.038, 0.218], [s * 0.026, 0.219], [s * 0.018, 0.214]], 'rgba(150,200,255,0.55)', 1.2);
          strokePath([[s * 0.052, 0.204], [s * 0.066, 0.192], [s * 0.064, 0.176], [s * 0.056, 0.166]], 'rgba(130,185,245,0.35)', 1);
        }
        // nose bridge hint + tip underside
        strokePath([[0.013, -0.03], [0.020, 0.04], [0.026, 0.10], [0.030, 0.152]], 'rgba(120,180,240,0.22)', 1);
        strokePath([[-0.024, 0.224], [-0.008, 0.232], [0.008, 0.232], [0.024, 0.224]], 'rgba(150,200,255,0.5)', 1.2);

        // ---- lips ----
        const mw = 0.115, my = 0.345, op = open * 0.05;
        // upper lip fill
        o.fillStyle = 'rgba(135,185,250,0.32)';
        o.beginPath();
        o.moveTo(X(-mw), Y(my + 0.004));
        o.bezierCurveTo(X(-0.060), Y(my - 0.024), X(-0.028), Y(my - 0.031), X(-0.012), Y(my - 0.024));
        o.bezierCurveTo(X(-0.004), Y(my - 0.019), X(0.004), Y(my - 0.019), X(0.012), Y(my - 0.024));
        o.bezierCurveTo(X(0.028), Y(my - 0.031), X(0.060), Y(my - 0.024), X(mw), Y(my + 0.004));
        o.bezierCurveTo(X(0.05), Y(my + 0.011), X(-0.05), Y(my + 0.011), X(-mw), Y(my + 0.004));
        o.fill();
        // mouth interior when open
        if (op > 0.004) {
          o.fillStyle = 'rgba(4,12,38,0.88)';
          o.beginPath();
          o.ellipse(X(0), Y(my + 0.013 + op * 0.55), mw * 0.78 * sc, (op * 0.75 + 0.004) * sc, 0, 0, Math.PI * 2);
          o.fill();
          o.strokeStyle = 'rgba(235,248,255,0.45)';
          o.lineWidth = 1;
          o.beginPath();
          o.moveTo(X(-mw * 0.55), Y(my + 0.012));
          o.quadraticCurveTo(X(0), Y(my + 0.016), X(mw * 0.55), Y(my + 0.012));
          o.stroke();
        }
        // lower lip fill
        o.fillStyle = 'rgba(155,205,255,0.38)';
        o.beginPath();
        o.moveTo(X(-mw), Y(my + 0.004));
        o.bezierCurveTo(X(-0.070), Y(my + 0.054 + op), X(0.070), Y(my + 0.054 + op), X(mw), Y(my + 0.004));
        o.bezierCurveTo(X(0.05), Y(my + 0.013 + op * 0.5), X(-0.05), Y(my + 0.013 + op * 0.5), X(-mw), Y(my + 0.004));
        o.fill();
        // lip lines + highlight
        strokePath([[-mw, my + 0.004], [-0.04, my + 0.012 + op * 0.4], [0.04, my + 0.012 + op * 0.4], [mw, my + 0.004]], 'rgba(90,150,230,0.6)', 1.1);
        strokePath([[-0.045, my + 0.034 + op], [-0.015, my + 0.040 + op], [0.015, my + 0.040 + op], [0.045, my + 0.034 + op]], 'rgba(235,248,255,0.55)', 1.3);
        // chin crease
        strokePath([[-0.05, 0.445], [-0.015, 0.455], [0.015, 0.455], [0.05, 0.445]], 'rgba(120,180,240,0.18)', 1);

        // ---- hair (drawn last — covers forehead/temples) ----
        const hg = o.createLinearGradient(0, Y(-0.66), 0, Y(0.45));
        hg.addColorStop(0, 'rgba(95,155,235,0.55)');
        hg.addColorStop(0.5, 'rgba(45,90,180,0.50)');
        hg.addColorStop(1, 'rgba(20,45,110,0.42)');
        o.fillStyle = hg;
        o.beginPath();
        o.moveTo(X(-0.43), Y(0.42));
        o.bezierCurveTo(X(-0.475), Y(0.20), X(-0.465), Y(-0.20), X(-0.40), Y(-0.42));
        o.bezierCurveTo(X(-0.30), Y(-0.625), X(-0.10), Y(-0.66), X(0), Y(-0.655));
        o.bezierCurveTo(X(0.16), Y(-0.645), X(0.37), Y(-0.55), X(0.445), Y(-0.30));
        o.bezierCurveTo(X(0.478), Y(-0.10), X(0.465), Y(0.18), X(0.425), Y(0.42));
        o.lineTo(X(0.347), Y(0.40));
        o.bezierCurveTo(X(0.362), Y(0.20), X(0.364), Y(0.06), X(0.358), Y(-0.02));
        o.bezierCurveTo(X(0.20), Y(-0.26), X(0.0), Y(-0.395), X(-0.085), Y(-0.475));
        o.bezierCurveTo(X(-0.20), Y(-0.41), X(-0.305), Y(-0.245), X(-0.348), Y(-0.06));
        o.bezierCurveTo(X(-0.356), Y(0.12), X(-0.350), Y(0.28), X(-0.337), Y(0.40));
        o.closePath();
        o.fill();
        // rim light + strands
        strokePath([[-0.40, -0.42], [-0.30, -0.625], [-0.10, -0.66], [0, -0.655],
                    [0.16, -0.645], [0.37, -0.55], [0.445, -0.30]], 'rgba(170,215,255,0.5)', 1.4);
        strokePath([[-0.085, -0.475], [0.02, -0.40], [0.20, -0.27], [0.358, -0.02]], 'rgba(170,215,255,0.45)', 1.2);
        strokePath([[-0.085, -0.475], [-0.20, -0.41], [-0.305, -0.245], [-0.348, -0.06]], 'rgba(140,195,250,0.35)', 1.1);
        strokePath([[0.42, -0.30], [0.45, -0.08], [0.44, 0.16], [0.41, 0.40]], 'rgba(140,195,250,0.30)', 1);
        strokePath([[-0.41, -0.28], [-0.44, -0.05], [-0.43, 0.18], [-0.405, 0.40]], 'rgba(140,195,250,0.30)', 1);
        strokePath([[0.05, -0.62], [0.18, -0.56], [0.30, -0.42], [0.36, -0.22]], 'rgba(150,200,255,0.25)', 1);
      }

      function draw() {
        t += 1;
        if (blink <= 0 && Math.random() < 0.008) blink = 10;
        if (blink > 0) blink -= 1;
        if (glitch <= 0 && Math.random() < 0.005) { glitch = 6; gShift = (Math.random() - 0.5) * 16; gY = Math.random() * S * 0.7; }
        if (glitch > 0) glitch -= 1;

        const amp = spk.current ? 0.3 + Math.abs(Math.sin(t * 0.215)) * 0.7 : 0.0;
        const lid = blink > 0 ? Math.sin((blink / 10) * Math.PI) : 0;
        const gazeX = Math.sin(t * 0.0017) * 0.010;
        cy = cy0 + Math.sin(t * 0.012) * 1.6 + (spk.current ? Math.sin(t * 0.4) * 0.7 : 0);

        drawPortrait(amp, lid, gazeX);

        ctx.clearRect(0, 0, S, S);
        // under-glow
        const g = ctx.createRadialGradient(S / 2, S * 0.66, 0, S / 2, S * 0.66, S * 0.6);
        g.addColorStop(0, 'rgba(70,160,255,0.14)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, S, S);

        // composite portrait with flicker + glitch slices
        ctx.globalAlpha = 0.88 + 0.12 * Math.sin(t * 0.7) * Math.sin(t * 0.13);
        if (glitch > 0) {
          const hh = 14;
          ctx.drawImage(off, 0, 0, S, gY, 0, 0, S, gY);
          ctx.drawImage(off, 0, gY, S, hh, gShift, gY, S, hh);
          ctx.drawImage(off, 0, gY + hh, S, S - gY - hh, 0, gY + hh, S, S - gY - hh);
        } else {
          ctx.drawImage(off, 0, 0);
        }
        ctx.globalAlpha = 1;

        // scanline raster — thin the hologram rows
        ctx.globalCompositeOperation = 'destination-out';
        ctx.fillStyle = 'rgba(0,0,0,0.42)';
        for (let y = (t * 0.2) % 3; y < S; y += 3) ctx.fillRect(0, y, S, 1);
        ctx.globalCompositeOperation = 'source-over';

        raf = requestAnimationFrame(draw);
      }
      draw();
      return () => cancelAnimationFrame(raf);
    }, []);

    return <canvas ref={ref} width={width} height={height} style={{ display: 'block' }}></canvas>;
  }

  // ============ RingDial — gyroscopic instrument rings ============
  function RingDial({ size = 470, active = false }) {
    const ref = React.useRef(null);
    const act = React.useRef(active);
    act.current = active;

    React.useEffect(() => {
      const canvas = ref.current, ctx = canvas.getContext('2d');
      const S = canvas.width, c = S / 2;
      let raf, t = 0;

      function draw() {
        t += 1;
        ctx.clearRect(0, 0, S, S);
        const boost = act.current ? 1.35 : 1;

        const fa = t * 0.0025;
        const fx = c + Math.cos(fa) * S * 0.17, fy = c + Math.sin(fa) * S * 0.17;
        const fg = ctx.createRadialGradient(fx, fy, 0, fx, fy, S * 0.30);
        fg.addColorStop(0, 'rgba(255, 150, 70, 0.10)');
        fg.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = fg;
        ctx.fillRect(0, 0, S, S);

        for (let i = 0; i < 96; i++) {
          const a = (i / 96) * Math.PI * 2;
          const r1 = S * (i % 8 === 0 ? 0.448 : 0.458), r2 = S * 0.468;
          ctx.strokeStyle = `rgba(58, 214, 255, ${i % 8 === 0 ? 0.45 : 0.22})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(c + Math.cos(a) * r1, c + Math.sin(a) * r1);
          ctx.lineTo(c + Math.cos(a) * r2, c + Math.sin(a) * r2);
          ctx.stroke();
        }
        ctx.strokeStyle = `rgba(234, 247, 255, ${0.5 * boost})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(c, c, S * 0.463, t * 0.012, t * 0.012 + 0.8);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(58, 214, 255, 0.35)';
        ctx.lineWidth = S * 0.020;
        ctx.setLineDash([S * 0.045, S * 0.016]);
        ctx.lineDashOffset = t * 0.18;
        ctx.beginPath(); ctx.arc(c, c, S * 0.418, 0, Math.PI * 2); ctx.stroke();
        ctx.strokeStyle = `rgba(234, 247, 255, ${0.75 * boost})`;
        ctx.setLineDash([S * 0.045, S * 0.32]);
        ctx.lineDashOffset = -t * 0.35;
        ctx.beginPath(); ctx.arc(c, c, S * 0.418, 0, Math.PI * 2); ctx.stroke();
        ctx.setLineDash([]);

        ctx.strokeStyle = 'rgba(58, 214, 255, 0.45)';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([9, 7]);
        ctx.lineDashOffset = -t * 0.4;
        ctx.beginPath(); ctx.arc(c, c, S * 0.382, 0, Math.PI * 2); ctx.stroke();
        ctx.setLineDash([]);

        ctx.font = `${Math.max(7, S * 0.018)}px "SF Mono", "Fira Code", Menlo, monospace`;
        ctx.fillStyle = 'rgba(58, 214, 255, 0.35)';
        ctx.textAlign = 'center';
        const digits = '0191821411485419';
        for (let i = 0; i < digits.length; i++) {
          const a = (i / digits.length) * Math.PI * 2 + t * 0.0015;
          ctx.save();
          ctx.translate(c + Math.cos(a) * S * 0.355, c + Math.sin(a) * S * 0.355);
          ctx.rotate(a + Math.PI / 2);
          ctx.fillText(digits[i], 0, 0);
          ctx.restore();
        }

        for (const [phase, rr, sq] of [[0, 0.46, 0.30], [2.1, 0.44, 0.22]]) {
          ctx.save();
          ctx.translate(c, c);
          ctx.rotate(t * 0.004 + phase);
          ctx.scale(1, sq);
          ctx.strokeStyle = `rgba(58, 214, 255, ${0.5 * boost})`;
          ctx.lineWidth = 1.3;
          ctx.setLineDash([16, 11]);
          ctx.lineDashOffset = t * 0.6;
          ctx.beginPath(); ctx.arc(0, 0, S * rr, 0, Math.PI * 2); ctx.stroke();
          ctx.setLineDash([]);
          const na = t * 0.02 + phase;
          ctx.fillStyle = 'rgba(234, 247, 255, 0.9)';
          ctx.fillRect(Math.cos(na) * S * rr - 2, Math.sin(na) * S * rr - 2, 4, 4);
          ctx.restore();
        }

        raf = requestAnimationFrame(draw);
      }
      draw();
      return () => cancelAnimationFrame(raf);
    }, []);

    return <canvas ref={ref} width={size} height={size} style={{ display: 'block' }}></canvas>;
  }

  // ============ PlexusBG — drifting constellation field ============
  function PlexusBG({ width = 900, height = 520 }) {
    const ref = React.useRef(null);
    React.useEffect(() => {
      const canvas = ref.current, ctx = canvas.getContext('2d');
      const w = canvas.width, h = canvas.height;
      const pts = Array.from({ length: 56 }, () => ({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.22, vy: (Math.random() - 0.5) * 0.22,
      }));
      let raf;
      function draw() {
        ctx.clearRect(0, 0, w, h);
        for (const p of pts) {
          p.x = (p.x + p.vx + w) % w;
          p.y = (p.y + p.vy + h) % h;
        }
        for (let i = 0; i < pts.length; i++) {
          for (let j = i + 1; j < pts.length; j++) {
            const d = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y);
            if (d < 110) {
              ctx.strokeStyle = `rgba(58, 214, 255, ${(1 - d / 110) * 0.13})`;
              ctx.lineWidth = 0.7;
              ctx.beginPath();
              ctx.moveTo(pts[i].x, pts[i].y);
              ctx.lineTo(pts[j].x, pts[j].y);
              ctx.stroke();
            }
          }
        }
        ctx.fillStyle = 'rgba(159, 220, 245, 0.5)';
        for (const p of pts) ctx.fillRect(p.x - 1, p.y - 1, 1.8, 1.8);
        raf = requestAnimationFrame(draw);
      }
      draw();
      return () => cancelAnimationFrame(raf);
    }, []);
    return (
      <canvas
        ref={ref}
        width={width}
        height={height}
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}
      ></canvas>
    );
  }

  // mini decimal ring gauge
  function MiniRing({ value = 50, size = 38 }) {
    const ref = React.useRef(null);
    React.useEffect(() => {
      const c = ref.current, ctx = c.getContext('2d');
      const s = c.width, m = s / 2, r = s / 2 - 4;
      ctx.clearRect(0, 0, s, s);
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.20)';
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(m, m, r, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = '#eaf7ff';
      ctx.beginPath(); ctx.arc(m, m, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (value / 100)); ctx.stroke();
    }, [value]);
    return <canvas ref={ref} width={size} height={size} style={{ display: 'block' }}></canvas>;
  }

  // ============ HoloPortrait — image-based hyperreal hologram ============
  // Drop ANY portrait image onto the avatar; it is gradient-mapped to a blue
  // hologram (navy → electric blue → white-hot), vignetted, scanlined, and
  // animated with flicker/glitch/scan-sweep. Persists in localStorage.
  function HoloPortrait({ speaking = false, size = 310 }) {
    const canvasRef = React.useRef(null);
    const baseRef = React.useRef(null);
    const fileRef = React.useRef(null);
    const [hasImg, setHasImg] = React.useState(false);
    const spk = React.useRef(speaking);
    spk.current = speaking;

    const S = size * 2; // internal resolution

    function processImage(img) {
      const base = document.createElement('canvas');
      base.width = S; base.height = S;
      const b = base.getContext('2d');
      const sc = Math.max(S / img.width, S / img.height);
      const dw = img.width * sc, dh = img.height * sc;
      b.drawImage(img, (S - dw) / 2, (S - dh) / 2 * 0.6, dw, dh); // bias crop upward (faces sit high)
      const id = b.getImageData(0, 0, S, S);
      const d = id.data;
      const cxn = S / 2, cyn = S / 2;
      for (let i = 0; i < d.length; i += 4) {
        const lum = Math.pow((0.30 * d[i] + 0.59 * d[i + 1] + 0.11 * d[i + 2]) / 255, 0.85);
        let r, g, bl;
        if (lum < 0.5) {
          const t2 = lum * 2;
          r = 8 + (60 - 8) * t2; g = 20 + (140 - 20) * t2; bl = 60 + (255 - 60) * t2;
        } else {
          const t2 = (lum - 0.5) * 2;
          r = 60 + (215 - 60) * t2; g = 140 + (242 - 140) * t2; bl = 255;
        }
        d[i] = r; d[i + 1] = g; d[i + 2] = bl;
        // circular vignette fade → hologram floats
        const px = (i / 4) % S, py = (i / 4 / S) | 0;
        const dist = Math.hypot(px - cxn, py - cyn) / (S / 2);
        const fade = dist > 0.72 ? Math.max(0, 1 - (dist - 0.72) / 0.26) : 1;
        d[i + 3] = Math.min(d[i + 3], 255 * fade * (0.35 + 0.65 * lum + 0.25));
      }
      b.putImageData(id, 0, 0);
      baseRef.current = base;
      setHasImg(true);
    }

    function loadDataUrl(url) {
      const img = new Image();
      img.onload = () => processImage(img);
      img.src = url;
    }

    function handleFile(file) {
      if (!file || !file.type.startsWith('image/')) return;
      const img = new Image();
      img.onload = () => {
        // downscale before persisting
        const m = 1000 / Math.max(img.width, img.height);
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * Math.min(1, m));
        c.height = Math.round(img.height * Math.min(1, m));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        const url = c.toDataURL('image/jpeg', 0.86);
        try { localStorage.setItem('hud-avatar-img', url); } catch (e) {}
        loadDataUrl(url);
      };
      img.src = URL.createObjectURL(file);
    }

    React.useEffect(() => {
      const saved = localStorage.getItem('hud-avatar-img');
      if (saved) loadDataUrl(saved);
    }, []);

    React.useEffect(() => {
      if (!hasImg) return;
      const canvas = canvasRef.current, ctx = canvas.getContext('2d');
      let raf, t = 0, glitch = 0, gY = 0, gShift = 0;

      function draw() {
        t += 1;
        if (glitch <= 0 && Math.random() < 0.006) { glitch = 6; gY = Math.random() * S * 0.8; gShift = (Math.random() - 0.5) * 26; }
        if (glitch > 0) glitch -= 1;
        const base = baseRef.current;
        ctx.clearRect(0, 0, S, S);

        // under-glow
        const g = ctx.createRadialGradient(S / 2, S * 0.62, 0, S / 2, S * 0.62, S * 0.62);
        g.addColorStop(0, 'rgba(70,160,255,0.15)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, S, S);

        // breathing + flicker
        const breathe = 1 + Math.sin(t * 0.013) * 0.004;
        const boost = spk.current ? 0.12 + 0.10 * Math.abs(Math.sin(t * 0.22)) : 0;
        ctx.globalAlpha = 0.86 + 0.14 * Math.sin(t * 0.7) * Math.sin(t * 0.13) + boost;
        ctx.save();
        ctx.translate(S / 2, S / 2 + Math.sin(t * 0.011) * 3);
        ctx.scale(breathe, breathe);
        if (glitch > 0) {
          const hh = 22;
          ctx.drawImage(base, 0, 0, S, gY, -S / 2, -S / 2, S, gY);
          ctx.drawImage(base, 0, gY, S, hh, -S / 2 + gShift, -S / 2 + gY, S, hh);
          ctx.drawImage(base, 0, gY + hh, S, S - gY - hh, -S / 2, -S / 2 + gY + hh, S, S - gY - hh);
        } else {
          ctx.drawImage(base, -S / 2, -S / 2);
        }
        // speaking: additive double-exposure shimmer
        if (spk.current) {
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = 0.10 + 0.08 * Math.abs(Math.sin(t * 0.22));
          ctx.drawImage(base, -S / 2 + Math.sin(t * 0.3) * 2.5, -S / 2);
          ctx.globalCompositeOperation = 'source-over';
        }
        ctx.restore();
        ctx.globalAlpha = 1;

        // scan sweep band
        const sy = (t * 2.2) % (S * 1.4);
        if (sy < S) {
          ctx.globalCompositeOperation = 'lighter';
          const sg = ctx.createLinearGradient(0, sy - 16, 0, sy + 16);
          sg.addColorStop(0, 'rgba(120,200,255,0)');
          sg.addColorStop(0.5, 'rgba(160,220,255,0.10)');
          sg.addColorStop(1, 'rgba(120,200,255,0)');
          ctx.fillStyle = sg;
          ctx.fillRect(0, sy - 16, S, 32);
          ctx.fillStyle = 'rgba(200,240,255,0.16)';
          ctx.fillRect(0, sy, S, 2);
          ctx.globalCompositeOperation = 'source-over';
        }

        // scanline raster
        ctx.globalCompositeOperation = 'destination-out';
        ctx.fillStyle = 'rgba(0,0,0,0.38)';
        for (let y = (t * 0.25) % 4; y < S; y += 4) ctx.fillRect(0, y, S, 1.4);
        ctx.globalCompositeOperation = 'source-over';

        raf = requestAnimationFrame(draw);
      }
      draw();
      return () => cancelAnimationFrame(raf);
    }, [hasImg]);

    return (
      <div
        style={{ position: 'relative', width: size, height: size, cursor: 'pointer' }}
        title="Drop a portrait image to set the avatar"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files && e.dataTransfer.files[0]); }}
        onClick={() => fileRef.current && fileRef.current.click()}
      >
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          style={{ display: 'none' }}
          onChange={(e) => handleFile(e.target.files && e.target.files[0])}
        />
        {hasImg ? (
          <canvas ref={canvasRef} width={S} height={S} style={{ display: 'block', width: size, height: size }}></canvas>
        ) : (
          <>
            <HoloFace speaking={spk.current} width={size} height={size} />
            <div style={{
              position: 'absolute', left: '50%', bottom: 6, transform: 'translateX(-50%)',
              fontSize: 8, letterSpacing: 1, color: 'var(--cyan)', whiteSpace: 'nowrap',
              background: 'rgba(4,12,30,0.7)', padding: '3px 8px', border: '1px solid var(--border)',
            }}>
              ⬡ DROP A PORTRAIT IMAGE HERE — RENDERED AS HOLOGRAM
            </div>
          </>
        )}
      </div>
    );
  }

  Object.assign(window, { HoloFace, HoloPortrait, RingDial, PlexusBG, MiniRing });
})();
