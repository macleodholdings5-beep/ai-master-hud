---
name: ai-master-hud-design
description: Use this skill to generate well-branded interfaces and assets for the AI Master HUD — a holographic JARVIS-style control center for a personal multi-agent AI ecosystem. Contains essential design guidelines, colors, type, fonts, component tokens, and a full UI kit for prototyping and production.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (prototypes, mockups, slides, etc), copy assets out and create static HTML files for the user to view. Load the design system via the compiled `_ds_bundle.js` and reference `styles.css` for tokens.

If working on production code, read the token files under `tokens/` and component source under `components/` to understand the exact CSS custom properties, class names, and React component API.

Key facts for any agent using this skill:

- **One typeface everywhere**: `--mono` stack (SF Mono → Fira Code → Menlo). No second font; Fira Code loads from Google Fonts for non-mac platforms.
- **Primary accent is cyan** (`#3ad6ff`). Matrix green (`#39ff7a`) is reserved for the agent avatar and online status dots only.
- **All surfaces are near-black translucent panels** (`rgba(10,22,36,0.55)`) with 1px hairline cyan borders and 2px radius. No drop shadows — depth comes from neon glows.
- **Corner brackets** (`.hud-corners` class) mark important hero frames.
- **Two bar types**: `.stat-bar` (solid, for telemetry) and `.seg-bar` (segmented blocks, for progress/loading — the JARVIS ▮▮▮▯▯ look).
- **Labels are UPPERCASE with wide letter-spacing** (1–3px). Body copy is sentence case. No marketing voice.
- **The Voice Chat tab has two modes**: AVATAR (matrix green pixel face, `AgentFace`) and BLUEPRINT (`HoloBlueprint` — exploded wireframe ring assemblies on a diagonal axis with warm orange core). Switch is triggered by "bring up <project>".
- **Glyph iconography**: no icon fonts or SVGs — only unicode glyphs (◢◤ ● ◌ ○ ▶ ■ ✓ ↩ ↻ ★ ☰ → ✕) and a small set of functional emoji (⚙ 🛠 ⭐ 📚 🎬).
- **Agent identity colors**: Foreman=green, Scout=cyan, Draftsman=yellow, Builder=orange, Sentinel=purple, You=white.

If the user invokes this skill without other guidance, ask what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts OR production code depending on the need.
