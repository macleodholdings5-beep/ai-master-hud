Top-bar navigation tabs for the HUD shell.

```jsx
<Tabs
  items={[{ id: 'voice', label: 'Voice Chat' }, { id: 'agents', label: 'Agents' }]}
  active={tab}
  onChange={setTab}
/>
```
