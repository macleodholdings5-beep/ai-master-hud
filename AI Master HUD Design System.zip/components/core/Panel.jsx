import React from 'react';

export function Panel({ title, corners = false, className = '', style, children }) {
  return (
    <section className={`hud-panel${corners ? ' hud-corners' : ''}${className ? ' ' + className : ''}`} style={style}>
      {title ? <h3>{title}</h3> : null}
      {children}
    </section>
  );
}
