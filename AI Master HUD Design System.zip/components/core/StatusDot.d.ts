/** 9px glowing status dot: green online / cyan processing (pulses) / orange warning / red offline. */
export interface StatusDotProps extends React.HTMLAttributes<HTMLSpanElement> {
  status?: 'online' | 'processing' | 'warning' | 'offline';
}
export declare function StatusDot(props: StatusDotProps): JSX.Element;
