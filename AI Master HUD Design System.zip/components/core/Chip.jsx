import React from 'react';

export function Chip({ variant = 'solid', children, className = '', ...rest }) {
  const v = variant === 'solid' ? '' : ' ' + variant;
  return (
    <span className={`hud-chip${v}${className ? ' ' + className : ''}`} {...rest}>
      {children}
    </span>
  );
}
