Centered HUD modal (settings, wiki) on a dark scrim; click outside or ✕ to close.

```jsx
<Modal title="⚙ SETTINGS" onClose={close}>
  <p>…fields…</p>
</Modal>
```
