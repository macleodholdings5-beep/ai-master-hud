import React from 'react';

export function StatusDot({ status = 'offline', className = '', ...rest }) {
  return <span className={`status-dot ${status}${className ? ' ' + className : ''}`} {...rest} />;
}
