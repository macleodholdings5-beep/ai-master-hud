import React from 'react';

export function Button({ variant = 'default', children, className = '', ...rest }) {
  const v = variant === 'default' ? '' : ' ' + variant;
  return (
    <button className={`hud-btn${v}${className ? ' ' + className : ''}`} {...rest}>
      {children}
    </button>
  );
}
