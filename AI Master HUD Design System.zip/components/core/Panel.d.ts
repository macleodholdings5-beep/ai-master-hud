/** Translucent HUD panel with hairline border and uppercase micro-heading. */
export interface PanelProps {
  /** Uppercase micro-heading rendered at the top of the panel */
  title?: string;
  /** Adds the signature corner brackets (.hud-corners) */
  corners?: boolean;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
export declare function Panel(props: PanelProps): JSX.Element;
