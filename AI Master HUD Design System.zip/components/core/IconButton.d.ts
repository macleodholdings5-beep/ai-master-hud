/** Small square glyph button for chrome actions (⚙, ✕, ☰). */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** A single unicode glyph, e.g. "⚙" "✕" "↻" */
  glyph: string;
  /** Accessible label / tooltip */
  label?: string;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
