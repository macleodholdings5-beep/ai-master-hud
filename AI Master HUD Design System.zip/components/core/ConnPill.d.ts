/** Connection state pill (● GATEWAY / ◌ CONNECTING / ○ OFFLINE) for the top bar. */
export interface ConnPillProps {
  status?: 'connected' | 'connecting' | 'offline';
  /** Override label text, e.g. "DEMO MODE" */
  label?: string;
}
export declare function ConnPill(props: ConnPillProps): JSX.Element;
