import React from 'react';

const GLYPHS = { connected: '●', connecting: '◌', offline: '○' };

export function ConnPill({ status = 'offline', label }) {
  const text = label || (status === 'connected' ? 'CONNECTED' : status === 'connecting' ? 'CONNECTING' : 'OFFLINE');
  return (
    <span className={`conn-pill ${status}`}>
      {GLYPHS[status] || '○'} {text}
    </span>
  );
}
