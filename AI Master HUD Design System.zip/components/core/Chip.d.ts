/** Filled cyan title chip — the "FREQUENCY DISPLAY" bar from the reference HUDs. */
export interface ChipProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** solid (filled cyan) | hollow (outline) | alert (filled red) */
  variant?: 'solid' | 'hollow' | 'alert';
  children?: React.ReactNode;
}
export declare function Chip(props: ChipProps): JSX.Element;
