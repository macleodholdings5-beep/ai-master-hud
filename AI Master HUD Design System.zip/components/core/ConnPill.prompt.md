Connection state indicator for the top bar; glyph + uppercase label.

```jsx
<ConnPill status="connected" label="DEMO MODE" />
<ConnPill status="connecting" />
```
