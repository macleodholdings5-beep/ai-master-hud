Glowing agent/system status dot; the universal state indicator.

```jsx
<StatusDot status="online" />
<StatusDot status="processing" />
```

- `online` green · `processing` cyan + pulse · `warning` orange · `offline` red.
