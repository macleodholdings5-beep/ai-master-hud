Square glyph-only button for window chrome and inline actions.

```jsx
<IconButton glyph="⚙" label="Settings" onClick={openSettings} />
<IconButton glyph="✕" label="Close" onClick={onClose} />
```

- Use the canonical glyph set (⚙ ✕ ↻ ★ ☰); one glyph per action, no icon fonts.
