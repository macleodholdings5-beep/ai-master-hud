Uppercase HUD action button; lead the label with a glyph (`▶ START VOICE`, `✓ GOOD, GO AHEAD`).

```jsx
<Button onClick={run}>▶ Start voice</Button>
<Button variant="approve">✓ Good, go ahead</Button>
<Button variant="reject">↩ Need changes</Button>
```

- Variants: `default` cyan outline · `solid` filled cyan (rare, strongest CTA) · `approve` green · `reject` orange · `danger` red.
- Labels auto-uppercase via CSS; write them in sentence case.
