/** HUD action button — uppercase, hairline cyan border, tinted fill. */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** default (cyan outline) | solid (filled cyan) | approve (green) | reject (orange) | danger (red) */
  variant?: 'default' | 'solid' | 'approve' | 'reject' | 'danger';
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
