Translucent holographic panel — the base container for every HUD surface; use `corners` for important frames.

```jsx
<Panel title="Home Lab" corners>
  <p>Telemetry content…</p>
</Panel>
```

- `title` renders as the dim uppercase tracked heading (`HOME LAB`).
- `corners` adds bright corner brackets — reserve for hero/primary frames.
