import React from 'react';

export function Tabs({ items = [], active, onChange }) {
  return (
    <nav className="hud-tabs">
      {items.map((t) => (
        <button
          key={t.id}
          className={`hud-tab${t.id === active ? ' active' : ''}`}
          onClick={() => onChange && onChange(t.id)}
        >
          {t.label}
        </button>
      ))}
    </nav>
  );
}
