/** Centered modal on a dark scrim; bracket-cornered panel with ✕ close. */
export interface ModalProps {
  title?: string;
  onClose?: () => void;
  width?: number;
  children?: React.ReactNode;
}
export declare function Modal(props: ModalProps): JSX.Element;
