import React from 'react';

export function IconButton({ glyph, label, className = '', ...rest }) {
  return (
    <button className={`hud-icon-btn${className ? ' ' + className : ''}`} title={label} aria-label={label} {...rest}>
      {glyph}
    </button>
  );
}
