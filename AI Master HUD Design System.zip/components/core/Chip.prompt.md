Filled cyan label chip used as a section title bar inside holographic panels.

```jsx
<Chip>Frequency display</Chip>
<Chip variant="hollow">Read</Chip>
<Chip variant="alert">Failed</Chip>
```

- `solid` for module titles; `hollow` for secondary tags; `alert` red, only for failures.
