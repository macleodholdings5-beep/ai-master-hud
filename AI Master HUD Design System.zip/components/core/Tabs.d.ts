/** Top-bar tab strip — uppercase, hairline active outline. */
export interface TabsProps {
  items: Array<{ id: string; label: string }>;
  active?: string;
  onChange?: (id: string) => void;
}
export declare function Tabs(props: TabsProps): JSX.Element;
