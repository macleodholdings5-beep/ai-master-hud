import React from 'react';

export function Modal({ title, onClose, children, width = 560 }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal hud-panel hud-corners"
        style={{ width }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ margin: 0 }}>{title}</h3>
          <button className="hud-icon-btn" aria-label="Close" onClick={onClose}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
