import React from 'react';

export function SegBar({ value = 0, color = 'white', label, style }) {
  return (
    <div style={style}>
      {label ? <div className="hud-label" style={{ marginBottom: 4 }}>{label}</div> : null}
      <div className={`seg-bar${color === 'cyan' ? ' cyan' : ''}`}>
        <div className="seg-fill" style={{ width: `${Math.min(100, Math.max(0, value))}%` }}></div>
      </div>
    </div>
  );
}
