Telemetry bar row for system stats (CPU/MEM/DISK/NET).

```jsx
<StatBar label="CPU" value={34} />
<StatBar label="NET" value={42} unit="ms" warn={150} />
```
