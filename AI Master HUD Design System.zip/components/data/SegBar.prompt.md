Segmented block progress bar — use for build/loading progress, not telemetry.

```jsx
<SegBar label="Maint . int" value={64} />
<SegBar value={30} color="cyan" />
```
