/** Executed-command feedback card: $ command, STATUS, optional output well. */
export interface CmdCardProps {
  command: string;
  status?: 'ok' | 'failed' | 'running';
  output?: string;
}
export declare function CmdCard(props: CmdCardProps): JSX.Element;
