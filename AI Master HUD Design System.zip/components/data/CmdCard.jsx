import React from 'react';

export function CmdCard({ command, status = 'running', output }) {
  return (
    <div className={`cmd-card ${status}`}>
      <code>$ {command}</code>
      <span className="cmd-status">{String(status).toUpperCase()}</span>
      {output ? <pre>{output}</pre> : null}
    </div>
  );
}
