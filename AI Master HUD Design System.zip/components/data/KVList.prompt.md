Key/value detail grid — dim uppercase keys, body-color values.

```jsx
<KVList items={[
  ['Current task', 'Researching: local-first sync engines'],
  ['Model', 'claude-sonnet-4.6'],
  ['Provider', 'OpenRouter'],
]} />
```
