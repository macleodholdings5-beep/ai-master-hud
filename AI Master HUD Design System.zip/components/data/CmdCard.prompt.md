Command execution feedback card; border color tracks status.

```jsx
<CmdCard command="uptime" status="ok" output="14:32 up 12 days, load 0.42" />
<CmdCard command="restart sentinel" status="running" />
```
