/** Telemetry bar row: LABEL ▍▍▍▍▍ 42%. Cyan fill, turns orange past `warn`. */
export interface StatBarProps {
  label: string;
  value: number;
  /** "%" (default) or a unit like "ms" */
  unit?: string;
  /** Threshold above which the fill turns orange */
  warn?: number;
  /** Full-scale value for non-% units */
  max?: number;
}
export declare function StatBar(props: StatBarProps): JSX.Element;
