Six-stage idea pipeline flow with → arrows and the ⭐ human review gate.

```jsx
<StageFlow current={3} status="waiting" />
<StageFlow stages={['Plan', 'Build', 'Ship']} current={1} gateIndex={-1} />
```
