/** Pipeline stage flow: bubbles joined by → arrows. Gray pending / cyan active / yellow waiting / green complete. */
export interface StageFlowProps {
  /** Stage names; defaults to the six idea-pipeline stages */
  stages?: string[];
  /** Index of the current stage */
  current?: number;
  /** State of the current stage */
  status?: 'active' | 'waiting' | 'complete';
  /** Which stage gets the ⭐ human-gate marker (default 3); -1 for none */
  gateIndex?: number;
}
export declare function StageFlow(props: StageFlowProps): JSX.Element;
