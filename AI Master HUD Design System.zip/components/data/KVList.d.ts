/** Two-column key/value grid (agent detail: model, provider, current task…). */
export interface KVListProps {
  /** Array of [key, value] pairs */
  items: Array<[string, React.ReactNode]>;
}
export declare function KVList(props: KVListProps): JSX.Element;
