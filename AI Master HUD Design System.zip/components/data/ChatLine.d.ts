/** One line of agent-to-agent chat: timestamp, colored agent name, message. */
export interface ChatLineProps {
  /** Epoch ms or preformatted "HH:MM" string */
  ts: number | string;
  agent: string;
  text: string;
  /** Override identity color; defaults from the canonical AGENT_COLORS map */
  color?: string;
  /** Yellow italic system message */
  system?: boolean;
  /** White operator message */
  user?: boolean;
}
export declare function ChatLine(props: ChatLineProps): JSX.Element;
