Chat-room log line; agent names carry fixed identity colors (also exports `AGENT_COLORS`).

```jsx
<ChatLine ts={Date.now()} agent="Foreman" text="Team status check. Report in." />
<ChatLine ts="14:02" agent="System" text="Task assigned: research X → Scout." system />
```
