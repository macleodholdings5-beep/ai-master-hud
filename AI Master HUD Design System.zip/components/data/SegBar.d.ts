/** Segmented block progress bar (▮▮▮▮▯▯) — the JARVIS loader look. */
export interface SegBarProps {
  /** 0–100 */
  value?: number;
  /** white-hot (default) or cyan segments */
  color?: 'white' | 'cyan';
  /** Optional micro-label above the bar, e.g. "MAINT . INT" */
  label?: string;
  style?: React.CSSProperties;
}
export declare function SegBar(props: SegBarProps): JSX.Element;
