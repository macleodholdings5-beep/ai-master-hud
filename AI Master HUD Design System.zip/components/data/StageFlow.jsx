import React from 'react';

export const DEFAULT_STAGES = ['Capture', 'Research', 'Planning', 'Review Gate', 'Build', 'Done'];

function stageClass(stage, status, index) {
  if (index < stage) return 'complete';
  if (index > stage) return '';
  return status === 'complete' ? 'complete' : status === 'waiting' ? 'waiting' : 'active';
}

export function StageFlow({ stages = DEFAULT_STAGES, current = 0, status = 'active', gateIndex = 3 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
      {stages.map((name, i) => (
        <React.Fragment key={name}>
          <div className={`stage-bubble ${stageClass(current, status, i)}`} title={name}>
            {i === gateIndex ? '⭐ ' : ''}{name}
          </div>
          {i < stages.length - 1 && <span className="stage-arrow">→</span>}
        </React.Fragment>
      ))}
    </div>
  );
}
