import React from 'react';

export const AGENT_COLORS = {
  Foreman: 'var(--green)',
  Scout: 'var(--cyan)',
  Draftsman: 'var(--yellow)',
  Builder: 'var(--orange)',
  Sentinel: 'var(--purple)',
  You: 'var(--white)',
};

export function ChatLine({ ts, agent, text, color, system = false, user = false }) {
  const time = typeof ts === 'number'
    ? new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
    : ts;
  return (
    <div className={`chat-line${system ? ' system' : ''}${user ? ' user' : ''}`}>
      <span className="chat-ts">{time}</span>
      <span className="chat-agent" style={{ color: color || AGENT_COLORS[agent] || 'var(--ice)' }}>{agent}</span>
      <span className="chat-text">{text}</span>
    </div>
  );
}
