import React from 'react';

export function StatBar({ label, value, unit = '%', warn = 80, max = 250 }) {
  const pct = Math.min(100, unit === '%' ? value : (value / max) * 100);
  return (
    <div className="stat-row">
      <span className="stat-label">{label}</span>
      <div className="stat-bar">
        <div className={`stat-fill${value > warn ? ' hot' : ''}`} style={{ width: `${pct}%` }}></div>
      </div>
      <span className="stat-value">{Math.round(value)}{unit}</span>
    </div>
  );
}
