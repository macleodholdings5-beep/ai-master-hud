Circular gauge dial with glowing center number — for percentages and scores.

```jsx
<RingGauge value={84} label="Radiation check" />
<RingGauge value={57} size={90} color="#ff9a4a" />
```
