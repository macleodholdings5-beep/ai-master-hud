Live voice waveform with corner state label (STANDBY / LISTENING — YOU / AGENT SPEAKING).

```jsx
<Waveform userSpeaking={micActive} agentSpeaking={agentTalking} />
```

- Green wave = operator; cyan wave = agent — matching transcript name colors.
