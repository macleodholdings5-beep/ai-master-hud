import React, { useEffect, useRef, useState } from 'react';

// Holographic exploded blueprint — modeled on the "ANALYSING DATA / REACTOR CORE"
// reference: dense particle-swarm ring assemblies along a diagonal axis, copper
// wound coils between them, a hot orange particle core, teal label boxes with
// white tracked type, and faint micro-data columns. Hover/click selects a part.

const HEX = '0123456789ABCDEF';

function makeRng(seed) {
  let s = seed;
  return () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
}

function buildGeometry(parts, coreIndex, w, h) {
  const rnd = makeRng(48271);
  const n = Math.max(parts.length, 1);
  const core = coreIndex >= 0 ? coreIndex : Math.floor((n - 1) / 2);
  const x0 = w * 0.15, y0 = h * 0.68, x1 = w * 0.85, y1 = h * 0.26;
  const axis = Math.atan2(y1 - y0, x1 - x0);
  const baseR = Math.min(w / (n * 2.5), h * 0.30);

  const clusters = [];
  for (let i = 0; i < n; i++) {
    const f = n === 1 ? 0.5 : i / (n - 1);
    const cx = x0 + (x1 - x0) * f, cy = y0 + (y1 - y0) * f;
    const isCore = i === core;
    const R = baseR * (isCore ? 0.72 : 0.86 + 0.18 * Math.sin(i * 2.1));
    const particles = [];

    if (isCore) {
      // hot particle ball — orange/white/teal
      for (let p = 0; p < 420; p++) {
        const r = ((rnd() + rnd() + rnd()) / 3) * R * 0.95;
        const roll = rnd();
        particles.push({
          ang: rnd() * Math.PI * 2, r, ecc: 0.8 + rnd() * 0.2,
          speed: (rnd() - 0.5) * 0.006,
          color: roll < 0.5 ? '255,154,74' : roll < 0.72 ? '255,220,180' : roll < 0.88 ? '255,255,255' : '120,220,230',
          a: 0.35 + rnd() * 0.6, s: 0.8 + rnd() * 1.6,
        });
      }
    } else {
      // 5 nested particle rings + 2 satellite stubs
      for (let k = 0; k < 5; k++) {
        const rf = R * (0.34 + k * 0.165);
        const count = Math.round(rf * 1.5);
        const dir = k % 2 ? 1 : -1;
        const speed = dir * (0.0022 + rnd() * 0.002);
        for (let p = 0; p < count; p++) {
          const roll = rnd();
          particles.push({
            ang: rnd() * Math.PI * 2, r: rf * (1 + (rnd() - 0.5) * 0.06), ecc: 1,
            speed,
            color: roll < 0.74 ? '120,220,230' : roll < 0.90 ? '58,214,255' : '255,154,74',
            a: 0.25 + rnd() * 0.65, s: 0.8 + rnd() * 1.3,
          });
        }
      }
      for (const off of [-0.62, 0.62]) {
        for (let p = 0; p < 70; p++) {
          const roll = rnd();
          particles.push({
            ang: rnd() * Math.PI * 2, r: R * 0.30 * (1 + (rnd() - 0.5) * 0.1), ecc: 1,
            speed: 0.004 * (off > 0 ? -1 : 1), axOff: R * off,
            color: roll < 0.8 ? '120,220,230' : '255,154,74',
            a: 0.25 + rnd() * 0.5, s: 0.7 + rnd() * 1.1,
          });
        }
      }
    }
    clusters.push({ cx, cy, R, isCore, particles });
  }

  // copper coils between adjacent clusters
  const coils = [];
  for (let i = 0; i < n - 1; i++) {
    const a = clusters[i], b = clusters[i + 1];
    coils.push({ x: (a.cx + b.cx) / 2, y: (a.cy + b.cy) / 2, r: baseR * 0.16 });
  }

  // background furniture
  const speckles = Array.from({ length: 90 }, () => ({ x: rnd() * w, y: rnd() * h, a: 0.03 + rnd() * 0.06 }));
  const hexCol = (rows) => Array.from({ length: rows }, () =>
    Array.from({ length: 9 }, () => HEX[Math.floor(rnd() * 16)]).join('')
  );
  const dataCols = [
    { x: 8, y: 16, rows: hexCol(7) },
    { x: w - 66, y: h * 0.55, rows: hexCol(6) },
  ];

  return { clusters, coils, axis, baseR, speckles, dataCols, core };
}

export function HoloBlueprint({
  parts = [],
  coreIndex = -1,
  selected = -1,
  onSelectPart,
  width = 820,
  height = 440,
}) {
  const canvasRef = useRef(null);
  const [hover, setHover] = useState(-1);
  const stateRef = useRef({ selected, hover });
  stateRef.current = { selected, hover };
  const sig = parts.map((p) => p.label).join('|') + ':' + coreIndex;

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    const G = buildGeometry(parts, coreIndex, w, h);
    let raf, t = 0;

    const mono = (px, weight) => `${weight ? weight + ' ' : ''}${px}px "SF Mono", "Fira Code", Menlo, monospace`;

    function draw() {
      t += 1;
      const { selected: SEL, hover: HOV } = stateRef.current;
      ctx.clearRect(0, 0, w, h);

      // speckle + data columns
      for (const s of G.speckles) {
        ctx.fillStyle = `rgba(120, 220, 230, ${s.a})`;
        ctx.fillRect(s.x, s.y, 1.4, 1.4);
      }
      ctx.font = mono(7);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
      ctx.fillStyle = 'rgba(120, 220, 230, 0.18)';
      for (const col of G.dataCols) {
        col.rows.forEach((r, i) => ctx.fillText(r, col.x, col.y + i * 10));
      }
      ctx.fillStyle = 'rgba(120, 220, 230, 0.25)';
      ctx.fillText('// RETURN CODE', 8, G.dataCols[0].y + G.dataCols[0].rows.length * 10 + 8);

      // axis line
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.18)';
      ctx.setLineDash([2, 7]);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(w * 0.05, h * 0.74);
      ctx.lineTo(w * 0.95, h * 0.18);
      ctx.stroke();
      ctx.setLineDash([]);

      // coils — copper wound cylinders along the axis
      for (const coil of G.coils) {
        for (let j = -4; j <= 4; j++) {
          const ox = Math.cos(G.axis) * j * coil.r * 0.55;
          const oy = Math.sin(G.axis) * j * coil.r * 0.55;
          ctx.save();
          ctx.translate(coil.x + ox, coil.y + oy);
          ctx.rotate(G.axis + Math.PI / 2);
          ctx.scale(0.36, 1);
          ctx.strokeStyle = `rgba(255, 154, 74, ${0.5 - Math.abs(j) * 0.04})`;
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(0, 0, coil.r, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }
      }

      // clusters
      G.clusters.forEach((c, i) => {
        const hot = i === SEL || i === HOV;

        // dashed structural ellipses
        if (!c.isCore) {
          for (let k = 0; k < 2; k++) {
            ctx.save();
            ctx.translate(c.cx, c.cy);
            ctx.rotate(G.axis + Math.PI / 2);
            ctx.scale(0.36, 1);
            ctx.strokeStyle = `rgba(58, 214, 255, ${hot ? 0.5 : 0.22})`;
            ctx.lineWidth = 1;
            ctx.setLineDash(k ? [4, 6] : [12, 5]);
            ctx.lineDashOffset = t * (k ? -0.3 : 0.2);
            ctx.beginPath();
            ctx.arc(0, 0, c.R * (k ? 1.04 : 0.70), 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
          }
        } else {
          // core glow
          const g = ctx.createRadialGradient(c.cx, c.cy, 0, c.cx, c.cy, c.R * 1.4);
          g.addColorStop(0, 'rgba(255, 154, 74, 0.22)');
          g.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = g;
          ctx.fillRect(c.cx - c.R * 1.6, c.cy - c.R * 1.6, c.R * 3.2, c.R * 3.2);
        }

        // particle swarm
        ctx.save();
        ctx.translate(c.cx, c.cy);
        ctx.rotate(G.axis + Math.PI / 2);
        for (const p of c.particles) {
          const ang = p.ang + t * p.speed;
          const px = Math.cos(ang) * p.r * 0.36 * (p.ecc || 1);
          const py = Math.sin(ang) * p.r + (p.axOff ? 0 : 0);
          const ox = p.axOff ? p.axOff * 0.36 : 0;
          const alpha = p.a * (hot ? 1.25 : 1) * (0.75 + 0.25 * Math.sin(ang));
          ctx.fillStyle = `rgba(${p.color}, ${Math.min(1, Math.max(0.05, alpha))})`;
          ctx.fillRect(px + ox - p.s / 2, py - p.s / 2, p.s, p.s);
        }
        ctx.restore();
      });

      // callouts — teal label boxes, reference style
      ctx.textBaseline = 'middle';
      G.clusters.forEach((c, i) => {
        const hot = i === stateRef.current.selected || i === stateRef.current.hover;
        const label = (parts[i] && parts[i].label ? parts[i].label : `PART ${i + 1}`).toUpperCase();
        const detail = parts[i] && parts[i].detail ? String(parts[i].detail).toUpperCase() : '';
        const up = i % 2 === 0;
        const ly = up ? c.cy - c.R - 30 : c.cy + c.R + 30;

        ctx.strokeStyle = `rgba(58, 214, 255, ${hot ? 0.8 : 0.3})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(c.cx, up ? c.cy - c.R * 0.9 : c.cy + c.R * 0.9);
        ctx.lineTo(c.cx, ly);
        ctx.stroke();

        ctx.font = mono(10, 700);
        const tw = ctx.measureText(label).width;
        const bw = tw + 16, bh = 18;
        const bx = Math.min(Math.max(c.cx - 8, 4), w - bw - 4);
        const by = up ? ly - bh : ly;
        ctx.fillStyle = hot ? 'rgba(20, 64, 78, 0.95)' : 'rgba(14, 42, 52, 0.92)';
        ctx.fillRect(bx, by, bw, bh);
        ctx.strokeStyle = `rgba(58, 214, 255, ${hot ? 0.95 : 0.4})`;
        ctx.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
        ctx.fillStyle = hot ? '#ffffff' : '#cfeefb';
        ctx.textAlign = 'left';
        ctx.fillText(label, bx + 8, by + bh / 2 + 0.5);

        if (detail) {
          ctx.font = mono(8);
          ctx.fillStyle = 'rgba(122, 200, 215, 0.6)';
          ctx.fillText(detail, bx + 8, up ? by - 7 : by + bh + 8);
        }
      });

      // corner ticks
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.4)';
      ctx.lineWidth = 1;
      for (const [cx2, cy2, dx, dy] of [[6, 6, 1, 1], [w - 6, 6, -1, 1], [6, h - 6, 1, -1], [w - 6, h - 6, -1, -1]]) {
        ctx.beginPath();
        ctx.moveTo(cx2 + dx * 8, cy2);
        ctx.lineTo(cx2, cy2);
        ctx.lineTo(cx2, cy2 + dy * 8);
        ctx.stroke();
      }

      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig, width, height]);

  function partAt(e) {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;
    const n = Math.max(parts.length, 1);
    const x0 = canvas.width * 0.15, y0 = canvas.height * 0.68;
    const x1 = canvas.width * 0.85, y1 = canvas.height * 0.26;
    const baseR = Math.min(canvas.width / (n * 2.5), canvas.height * 0.30);
    let best = -1, bestD = Infinity;
    for (let i = 0; i < n; i++) {
      const f = n === 1 ? 0.5 : i / (n - 1);
      const cx = x0 + (x1 - x0) * f, cy = y0 + (y1 - y0) * f;
      const d = Math.hypot(x - cx, y - cy);
      if (d < bestD) { bestD = d; best = i; }
    }
    return bestD < baseR * 1.25 ? best : -1;
  }

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      style={{ display: 'block', maxWidth: '100%', cursor: hover >= 0 ? 'pointer' : 'default' }}
      onMouseMove={(e) => setHover(partAt(e))}
      onMouseLeave={() => setHover(-1)}
      onClick={(e) => {
        const i = partAt(e);
        if (i >= 0 && onSelectPart) onSelectPart(i);
      }}
    ></canvas>
  );
}
