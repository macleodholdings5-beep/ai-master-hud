/** Voice waveform strip: green = operator speaking, cyan = agent responding, flatline = standby. */
export interface WaveformProps {
  userSpeaking?: boolean;
  agentSpeaking?: boolean;
  width?: number;
  height?: number;
}
export declare function Waveform(props: WaveformProps): JSX.Element;
