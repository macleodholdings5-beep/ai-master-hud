import React, { useEffect, useRef } from 'react';

// Circular gauge with a hot number center — the "167" dial from the reference HUD.
export function RingGauge({ value = 0, label, size = 120, color = '#3ad6ff' }) {
  const canvasRef = useRef(null);
  const valueRef = useRef(value);
  valueRef.current = value;

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let raf;
    let t = 0;
    let shown = 0;

    function draw() {
      t += 1;
      shown += (valueRef.current - shown) * 0.08;
      const s = canvas.width;
      const c = s / 2;
      const r = s / 2 - 8;
      ctx.clearRect(0, 0, s, s);

      // track
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.15)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(c, c, r, 0, Math.PI * 2);
      ctx.stroke();

      // value arc, from 12 o'clock
      const a0 = -Math.PI / 2;
      ctx.strokeStyle = color;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(c, c, r, a0, a0 + (Math.PI * 2 * shown) / 100);
      ctx.stroke();

      // rotating tick
      const ta = t * 0.01;
      ctx.strokeStyle = 'rgba(58, 214, 255, 0.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(c, c, r - 6, ta, ta + 0.5);
      ctx.stroke();

      // center number
      ctx.fillStyle = '#eaf7ff';
      ctx.font = `700 ${Math.round(s / 4.5)}px "SF Mono", "Fira Code", Menlo, monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(58, 214, 255, 0.55)';
      ctx.shadowBlur = 8;
      ctx.fillText(String(Math.round(shown)), c, c);
      ctx.shadowBlur = 0;

      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, [color]);

  return (
    <div style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <canvas ref={canvasRef} width={size} height={size} style={{ display: 'block' }}></canvas>
      {label ? <span className="hud-label">{label}</span> : null}
    </div>
  );
}
