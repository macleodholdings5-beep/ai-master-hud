import React, { useEffect, useRef } from 'react';

// Matrix avatar — a 3D head rendered as a green particle point-cloud.
// Slow yaw rotation, blinking eyes, articulated mouth while speaking,
// glyph-rain backdrop and a scan sweep. Fully generative, no images.

const RAIN_GLYPHS = 'アイウエオカキクケコサシスセソタチツテト0123456789';

function buildHead() {
  let seed = 970421;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const pts = [];

  // skull shell — sampled sphere, jaw taper, flattened face plane
  for (let i = 0; i < 1050; i++) {
    const th = Math.acos(2 * rnd() - 1);
    const ph = 2 * Math.PI * rnd();
    let x = Math.sin(th) * Math.cos(ph) * 0.80;
    let y = -Math.cos(th) * 1.02; // -1 crown … +1 chin
    let z = Math.sin(th) * Math.sin(ph) * 0.92;
    if (y > 0.25) { // taper toward the jaw
      const f = 1 - (y - 0.25) * 0.62;
      x *= f;
      z *= 1 - (y - 0.25) * 0.30;
    }
    if (z > 0.55) z = 0.55 + (z - 0.55) * 0.45; // flatten face plane
    pts.push({ x, y, z, kind: 'skull', s: 1.5, a: 0.55 + rnd() * 0.45 });
  }

  const feat = (x, y, z, kind, s = 2, a = 1) => pts.push({ x, y, z, kind, s, a });

  for (const side of [-1, 1]) {
    // brows
    for (let i = 0; i <= 10; i++) {
      const f = i / 10;
      feat(side * (0.16 + f * 0.22), -0.28 - Math.sin(f * Math.PI) * 0.04, 0.60, 'brow', 1.8);
    }
    // eyes — iris ring + pupil
    const ex = side * 0.30, ey = -0.155;
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2;
      feat(ex + Math.cos(a) * 0.075, ey + Math.sin(a) * 0.05, 0.585, 'eye', 1.7);
    }
    feat(ex, ey, 0.60, 'pupil', 2.6);
    // nostrils
    feat(side * 0.085, 0.255, 0.64, 'nose', 1.8);
    // ears
    for (let i = 0; i < 14; i++) {
      feat(side * (0.76 + rnd() * 0.06), -0.02 + (rnd() - 0.5) * 0.30, (rnd() - 0.5) * 0.16, 'skull', 1.4, 0.7);
    }
    // cheek lines
    for (let i = 0; i < 8; i++) {
      const f = i / 8;
      feat(side * (0.42 - f * 0.10), 0.10 + f * 0.26, 0.50 - f * 0.06, 'skull', 1.3, 0.5);
    }
  }
  // nose ridge
  for (let i = 0; i <= 8; i++) {
    const f = i / 8;
    feat(0, -0.08 + f * 0.30, 0.70 + Math.sin(f * Math.PI) * 0.10, 'nose', 1.8);
  }
  // lips — animated while speaking
  for (let i = 0; i <= 18; i++) {
    const f = i / 18;
    const x = -0.27 + f * 0.54;
    const z = 0.64 - Math.abs(x) * 0.30;
    feat(x, 0.455 - Math.sin(f * Math.PI) * 0.015, z, 'lipU', 1.9);
    feat(x, 0.505 + Math.sin(f * Math.PI) * 0.02, z, 'lipL', 1.9);
  }
  // chin
  for (let i = 0; i < 6; i++) feat((rnd() - 0.5) * 0.16, 0.72 + rnd() * 0.06, 0.46, 'skull', 1.4, 0.7);

  return pts;
}

export function AgentFace({ speaking = false, status = 'online', width = 420, height = 320, bare = false }) {
  const canvasRef = useRef(null);
  const speakingRef = useRef(speaking);
  speakingRef.current = speaking;

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pts = buildHead();
    const w = canvas.width, h = canvas.height;

    // glyph-rain columns
    const cols = Math.max(8, Math.floor(w / 16));
    const rain = Array.from({ length: cols }, (_, i) => ({
      x: i * 16 + 4,
      y: Math.random() * h,
      v: 0.8 + Math.random() * 1.4,
    }));

    let raf, t = 0, blink = 0;

    function draw() {
      t += 1;
      if (blink <= 0 && Math.random() < 0.006) blink = 9;
      if (blink > 0) blink -= 1;

      if (bare) { ctx.clearRect(0, 0, w, h); }
      else { ctx.fillStyle = '#020806'; ctx.fillRect(0, 0, w, h); }

      // matrix rain
      ctx.font = '10px "SF Mono", "Fira Code", Menlo, monospace';
      for (const c of rain) {
        c.y = (c.y + c.v) % (h + 30);
        ctx.fillStyle = 'rgba(57, 255, 122, 0.13)';
        ctx.fillText(RAIN_GLYPHS[(Math.floor(c.y / 12) + Math.floor(c.x)) % RAIN_GLYPHS.length], c.x, c.y);
        ctx.fillStyle = 'rgba(57, 255, 122, 0.05)';
        ctx.fillText(RAIN_GLYPHS[(Math.floor(c.y / 12) + 3 + Math.floor(c.x)) % RAIN_GLYPHS.length], c.x, c.y - 12);
      }

      // head
      const yaw = Math.sin(t * 0.0045) * 0.48;
      const cy = h * 0.52, cx = w / 2, scale = h * 0.40;
      const cosY = Math.cos(yaw), sinY = Math.sin(yaw);
      const amp = speakingRef.current ? 0.25 + Math.abs(Math.sin(t * 0.22)) * 0.75 : 0.05;

      for (const p of pts) {
        const X = p.x * cosY + p.z * sinY;
        const Z = -p.x * sinY + p.z * cosY;
        let Y = p.y;
        if (p.kind === 'lipL') Y += amp * 0.10 + (speakingRef.current ? (Math.random() - 0.5) * 0.012 : 0);
        if (p.kind === 'lipU') Y -= amp * 0.02;

        const depth = (Z + 1) / 2;
        let alpha = p.a * (0.08 + 0.9 * depth * depth);
        if ((p.kind === 'eye' || p.kind === 'pupil') && blink > 0) alpha *= 0.12;

        const isFeature = p.kind !== 'skull';
        ctx.fillStyle = isFeature
          ? `rgba(170, 255, 200, ${Math.min(1, alpha * 1.3)})`
          : `rgba(57, 255, 122, ${alpha})`;
        const sz = p.s * (0.6 + depth * 0.8);
        ctx.fillRect(cx + X * scale - sz / 2, cy + Y * scale - sz / 2, sz, sz);
      }

      // scan sweep
      const ly = (t * 0.7) % (h * 1.7);
      if (ly < h) {
        const g = ctx.createLinearGradient(0, ly - 10, 0, ly + 10);
        g.addColorStop(0, 'rgba(57, 255, 122, 0)');
        g.addColorStop(0.5, 'rgba(57, 255, 122, 0.06)');
        g.addColorStop(1, 'rgba(57, 255, 122, 0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, ly - 10, w, 20);
      }

      // corner status
      ctx.font = '9px "SF Mono", "Fira Code", Menlo, monospace';
      ctx.fillStyle = 'rgba(57, 255, 122, 0.5)';
      ctx.fillText(speakingRef.current ? '● TRANSMITTING' : '● ' + String(status).toUpperCase(), 10, h - 10);

      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, [status, bare]);

  if (bare) {
    return <canvas ref={canvasRef} width={width} height={height} style={{ display: 'block' }}></canvas>;
  }

  return (
    <div
      className={`agent-face ${status}`}
      style={{
        border: '1px solid var(--border)',
        borderRadius: 2,
        overflow: 'hidden',
        boxShadow: 'var(--glow-green-frame)',
        width,
      }}
    >
      <canvas ref={canvasRef} width={width} height={height} style={{ display: 'block' }}></canvas>
    </div>
  );
}
