Exploded holographic project view — what the HUD shows when the operator says "bring up project X". Cyan wireframe ring assemblies on a diagonal axis, warm orange core, annotated callouts; parts are hoverable/clickable.

```jsx
<HoloBlueprint
  parts={[
    { label: 'Gateway', detail: 'ws bridge' },
    { label: 'Voice pipeline', detail: 'realtime api' },
    { label: 'Reactor core', detail: 'agent fleet' },
    { label: 'Pipeline', detail: '6 stages' },
  ]}
  selected={sel}
  onSelectPart={setSel}
/>
```

- Use inside a `<Panel corners>` with a `<Chip>` title and a side KVList showing the selected part's stats.
- The middle part defaults to the warm core; override with `coreIndex`.
