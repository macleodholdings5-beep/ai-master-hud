/** Matrix-style pixel-grid agent avatar (always green). Mouth animates while speaking; eyes blink. */
export interface AgentFaceProps {
  /** Animates the mouth waveform while true */
  speaking?: boolean;
  /** Forwarded as a class on the frame (online/processing/warning/offline) */
  status?: 'online' | 'processing' | 'warning' | 'offline';
  width?: number;
  height?: number;
}
export declare function AgentFace(props: AgentFaceProps): JSX.Element;
