The active agent's matrix-green pixel avatar; the centerpiece of the Voice Chat tab's AVATAR mode.

```jsx
<AgentFace speaking={agentSpeaking} status="online" />
```

- Always matrix green, even in the cyan HUD — the avatar is the one green object on screen.
- Pair with `<Waveform>` below it and a status-dot header above.
