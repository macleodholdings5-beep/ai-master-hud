/** Circular dial gauge with white-hot center number and slow-rotating accent tick. */
export interface RingGaugeProps {
  /** 0–100 */
  value?: number;
  /** Micro-label rendered under the dial */
  label?: string;
  /** Canvas size in px (square) */
  size?: number;
  /** Arc color; defaults to cyan */
  color?: string;
}
export declare function RingGauge(props: RingGaugeProps): JSX.Element;
