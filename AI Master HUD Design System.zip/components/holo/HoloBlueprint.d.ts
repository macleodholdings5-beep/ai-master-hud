/** Holographic exploded blueprint: rotating wireframe ring assemblies along a
 * diagonal axis with a warm particle core and annotated callouts. Hover
 * highlights a part; click selects it.
 */
export interface HoloBlueprintProps {
  /** One entry per exploded assembly, drawn lower-left → upper-right */
  parts?: Array<{ label: string; detail?: string }>;
  /** Which part gets the warm orange core (default: middle part) */
  coreIndex?: number;
  /** Index of the currently selected part (drawn hot) */
  selected?: number;
  onSelectPart?: (index: number) => void;
  width?: number;
  height?: number;
}
export declare function HoloBlueprint(props: HoloBlueprintProps): JSX.Element;
