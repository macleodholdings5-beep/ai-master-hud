/** Dark inset text input; border brightens to cyan on focus. Lowercase placeholder. */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}
export declare function Input(props: InputProps): JSX.Element;
