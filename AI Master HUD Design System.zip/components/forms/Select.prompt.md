Dark dropdown; option labels are lowercase-technical with em-dash descriptions.

```jsx
<Select
  value={stability}
  onChange={(e) => set(Number(e.target.value))}
  options={[
    { value: 0, label: '0.0 — expressive' },
    { value: 0.5, label: '0.5 — balanced' },
    { value: 1, label: '1.0 — stable' },
  ]}
/>
```
