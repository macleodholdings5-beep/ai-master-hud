Multi-line dark input for longer text (resolutions, feedback).

```jsx
<TextArea placeholder="resolution" value={v} onChange={(e) => setV(e.target.value)} />
```
