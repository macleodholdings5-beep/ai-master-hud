Stacked form field — tracked uppercase micro-label over a full-width input.

```jsx
<SettingField label="OpenClaw gateway URL (WebSocket)">
  <Input placeholder="ws://homelab.local:18789 — leave empty for demo mode" />
</SettingField>
```
