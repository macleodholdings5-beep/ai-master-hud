import React from 'react';

export function SettingRow({ label, children }) {
  return (
    <label style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: 10, padding: '6px 0', fontSize: 12,
    }}>
      <span>{label}</span>
      {children}
    </label>
  );
}
