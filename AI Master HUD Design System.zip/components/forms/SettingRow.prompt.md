Inline setting row — label left, control right; used in settings panels.

```jsx
<SettingRow label="Voice">
  <input type="checkbox" checked={on} onChange={(e) => set(e.target.checked)} />
</SettingRow>
```
