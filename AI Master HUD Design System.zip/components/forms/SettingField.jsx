import React from 'react';

export function SettingField({ label, children }) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
      <span className="hud-label">{label}</span>
      {children}
    </label>
  );
}
