/** Stacked field: dim uppercase micro-label above a full-width control. */
export interface SettingFieldProps {
  label: string;
  children?: React.ReactNode;
}
export declare function SettingField(props: SettingFieldProps): JSX.Element;
