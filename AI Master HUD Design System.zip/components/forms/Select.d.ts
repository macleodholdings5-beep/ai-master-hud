/** Dark dropdown select. Option labels stay lowercase-technical ("0.5 — balanced"). */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  options: Array<{ value: string | number; label: string }>;
}
export declare function Select(props: SelectProps): JSX.Element;
