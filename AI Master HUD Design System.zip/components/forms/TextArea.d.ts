/** Dark inset multi-line input (wiki resolutions, feedback). */
export interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}
export declare function TextArea(props: TextAreaProps): JSX.Element;
