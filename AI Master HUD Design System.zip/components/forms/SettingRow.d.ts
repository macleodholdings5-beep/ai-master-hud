/** Horizontal setting row: label left, control right. */
export interface SettingRowProps {
  label: string;
  /** The control: checkbox, Select, etc. */
  children?: React.ReactNode;
}
export declare function SettingRow(props: SettingRowProps): JSX.Element;
