Dark inset text input; placeholders are lowercase and imperative.

```jsx
<Input placeholder="capture this idea…" value={v} onChange={(e) => setV(e.target.value)} />
```
