import React from 'react';

export function Select({ options = [], ...rest }) {
  return (
    <select {...rest}>
      {options.map((o) => (
        <option key={String(o.value)} value={o.value}>{o.label}</option>
      ))}
    </select>
  );
}
