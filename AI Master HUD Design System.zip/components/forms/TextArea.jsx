import React from 'react';

export function TextArea(props) {
  return <textarea style={{ minHeight: 60, resize: 'vertical', ...props.style }} {...props} />;
}
