# AI Master HUD — Design System

A holographic "JARVIS-style" control-room interface system for the **AI Master HUD**: a unified
Electron control center for a personal multi-agent AI ecosystem (the OpenClaw agent fleet).
The product gives a single operator voice control over a foreman-led team of AI agents, live
home-lab telemetry, an agent chat room, and an idea→product pipeline with a human review gate.

## Sources

- **Codebase**: locally-attached folder `ai-master-hud/` — Electron + React + Vite app.
  Key files: `src/styles.css` (original token sheet), `src/App.jsx` (shell + tabs),
  `src/components/{voice,agents,chatroom,pipeline,wiki,settings}/`, `agent-hud-spec.md`
  (full product spec), `src/services/mockData.js` (canonical demo copy).
- **Reference imagery** (user-provided art direction, copied to `assets/reference/`):
  JARVIS/FUI holographic dashboards — deep blue-black fields, cyan light, white-hot data,
  exploded wireframe "blueprint" views of machinery. These set the visual direction; the
  codebase sets the structure and copy.

## The product

Four tabs in one dark HUD window:

1. **Voice Chat** — the primary surface. A pixelated matrix-style avatar (green) represents the
   active agent; a live waveform shows who is speaking. On command ("bring up project X") the
   center stage switches from AVATAR mode to **BLUEPRINT mode**: a holographic exploded view of
   the named project — rotating wireframe rings, warm core, annotated callouts — like an
   interactive technical hologram.
2. **Agents** — roster with status dots, per-agent detail, and settings.
3. **Chat Room** — foreman banner, color-coded agent-to-agent log, command input, hierarchy tree.
4. **Idea Pipeline** — six-stage flow (Capture → Research → Planning → ⭐ Review Gate → Build →
   Done) with a human-in-the-loop review gate.

Plus a floating 🛠 **Troubleshooting Wiki** and a ⚙ **Settings** modal.

## CONTENT FUNDAMENTALS

*(see also `src/services/mockData.js` in the codebase — it is the canonical copy reference)*

- **Casing is hierarchy.** Labels, buttons, statuses, and headings are UPPERCASE with wide
  letter-spacing (`HOME LAB`, `COMMAND FEEDBACK`, `⭐ REVIEW GATE — human approval required`).
  Body copy and agent chatter are normal sentence case.
- **Terse, operational, telegraphic.** Status lines read like radio traffic:
  "Online. Research queue: 1 active topic." / "Slow response — retrying terminal handoff."
  No marketing voice, no exclamation marks, no fluff.
- **Em-dash and middle-dot as separators**: `Idle — awaiting commands`, `CAM-01 · no feed configured`.
- **Second person, imperative placeholders**: `capture this idea…`, `what needs to change?`,
  `Command the team… e.g. "tell the team to research X"`. Placeholders are lowercase.
- **Agents are named characters** with fixed identity colors: Foreman (green), Scout (cyan),
  Draftsman (yellow), Builder (orange), Sentinel (purple), You (white).
- **Glyphs, not icon fonts**: `◢◤` brand mark, `●/◌/○` connection states, `▶/■` start/stop,
  `✓/↩` approve/reject, `↻ RESTART`, `★ SET ACTIVE`, `☰ VIEW LOGS`, `→` stage arrows, `✕` close.
- **Emoji are rare and functional**, used as standalone icons only: ⚙ settings, 🛠 wiki,
  ⭐ review gate, 📚 sources, 🎬 videos. Never decorative, never in sentences.
- **Numbers are data**: timestamps `HH:MM`, latency `42ms`, context `200k`, models named
  exactly (`claude-opus-4.6`, `gpt-4o-realtime-preview`).

## VISUAL FOUNDATIONS

- **Color**: near-black blue field (`--bg #04080e`); all chrome is **cyan** (`--cyan #3ad6ff`)
  on hairline borders (`--border` = 16%-alpha cyan). Hottest data is **white-hot** (`--white-hot`)
  with a cyan text-glow. **Matrix green** (`--green #39ff7a`) is reserved for the agent avatar
  and "online" status. Yellow = waiting/human gate; orange = warning + the warm core of exploded
  blueprints; red = offline/FAILED/threats (used sparsely, it must startle).
- **Type**: one monospace family everywhere (`--mono`: SF Mono → Cascadia Code → Fira Code →
  Menlo). Hierarchy via size (9–18px), tracking (1–3px), UPPERCASE, and color — never a second
  typeface. Body is 13px.
- **Surfaces**: translucent panels (`rgba` blue, 55% alpha) with 1px hairline borders and
  2px corner radius — sharp, technical, not soft. Signature **corner brackets** (`.hud-corners`)
  mark important frames. Inset wells are darker translucent black.
- **Depth = light, not shadow.** No drop shadows or elevation. Glows only: status dots glow in
  their own color; frames glow faintly cyan (avatar frame: green); review-gate cards glow yellow.
- **Backgrounds**: flat color fields. No images, no gradients-as-decoration. Optional
  `.hud-scanlines` overlay adds a faint CRT texture on hero surfaces.
- **Bars**: thin solid bars for telemetry (`.stat-bar`), **segmented block bars** (`.seg-bar`)
  for progress — the blocky ▮▮▮▯▯ JARVIS look.
- **Motion**: one shared opacity pulse (`hud-pulse`, 1.2–1.4s) for anything "in progress";
  slow linear rotation (`hud-spin`) for holographic rings; 0.6s ease on bar widths. No bounces,
  no slides, no parallax. Canvas animations (avatar, waveform, blueprint) run continuous rAF.
- **Hover**: borders/text brighten toward the accent (muted → cyan). Press: background tint
  deepens + 1px translateY. Selected: 1px accent border + 5–8% accent tint fill.
- **Layout**: dense multi-column grids with fixed side rails (230/280/220/320px) and 14px gaps.
  Fixed top bar; floating round FAB bottom-right. Content never reflows — it's an instrument
  panel, not a document.
- **Radii**: 2px on panels/controls (sharp); 50% only on dots and the FAB.
- **Imagery**: there are no photographs. All "imagery" is generative canvas drawing — the
  pixel-grid avatar, waveforms, and exploded wireframe blueprints (cyan rings + warm core).

## ICONOGRAPHY

No icon font, no SVG icon set, no image icons anywhere in the product. Iconography is:

1. **Unicode glyphs** (primary system) — see CONTENT FUNDAMENTALS for the canonical set.
2. **Functional emoji** (sparing) — ⚙ 🛠 ⭐ 📚 🎬 only.
3. **Generative canvas** for anything pictorial: the avatar face, waveforms, ring gauges,
   exploded blueprints. Never draw static SVG illustrations.

When extending the system, pick glyphs that read at 13px mono and keep the one-glyph-per-action
rule (`↻`, `★`, `☰`). Do not introduce icon libraries.

## FILE INDEX

### Token files (all `@import`ed from `styles.css`)
| File | Purpose |
|---|---|
| `tokens/fonts.css` | `@import` of Fira Code from Google Fonts (system fallback stub) |
| `tokens/colors.css` | All 50+ color tokens and semantic aliases |
| `tokens/typography.css` | `--mono` font stack, type scale (9–18px), tracking, weights |
| `tokens/spacing.css` | `--space-*`, `--radius-*`, fixed layout widths |
| `tokens/effects.css` | Glow tokens, motion tokens, shared `@keyframes` |

### Base CSS
| File | Purpose |
|---|---|
| `css/base.css` | Element resets, inputs, pre, scrollbars |
| `css/components.css` | All reusable CSS classes (`.hud-panel`, `.hud-btn`, `.stat-bar`, `.seg-bar`, etc.) |

### Components
| Directory | Components |
|---|---|
| `components/core/` | `Panel`, `Button`, `IconButton`, `Chip`, `StatusDot`, `Tabs`, `ConnPill`, `Modal` |
| `components/forms/` | `Input`, `TextArea`, `Select`, `SettingRow`, `SettingField` |
| `components/data/` | `StatBar`, `SegBar`, `StageFlow`, `CmdCard`, `KVList`, `ChatLine` |
| `components/holo/` | `AgentFace`, `Waveform`, `RingGauge`, `HoloBlueprint` |

Each component directory contains `.jsx` (implementation), `.d.ts` (props contract),
`.prompt.md` (usage guide), and a `*.card.html` (Design System tab thumbnail).

### UI Kits
| Directory | Description |
|---|---|
| `ui_kits/master_hud/` | Full interactive AI Master HUD — Voice/Avatar/Blueprint tab, Agents, Chat Room, Idea Pipeline, Wiki modal, Settings modal |

### Templates (starting points for consuming projects)
| Directory | Description |
|---|---|
| `templates/master-hud/` | "HUD Control Screen" — topbar + telemetry rail + avatar ⇄ blueprint stage + feed rail, ready to rebrand |

The **Voice Chat stage pattern** is the signature interaction: `AgentFace` (matrix-green avatar)
swaps to `HoloBlueprint` (exploded cyan wireframe, warm core) when the operator says
"bring up *project*" — see `ui_kits/master_hud/VoiceTab.jsx` for the canonical wiring.

### Guidelines & Foundation Cards
| File | Card group |
|---|---|
| `guidelines/colors-accents.html` | Colors |
| `guidelines/colors-status.html` | Colors |
| `guidelines/colors-surfaces.html` | Colors |
| `guidelines/colors-agents.html` | Colors |
| `guidelines/type-family.html` | Type |
| `guidelines/type-scale.html` | Type |
| `guidelines/type-tracking.html` | Type |
| `guidelines/spacing-scale.html` | Spacing |
| `guidelines/radii.html` | Spacing |
| `guidelines/glows.html` | Spacing |
| `guidelines/bars.html` | Spacing |
| `guidelines/brand-wordmark.html` | Brand |
| `guidelines/brand-glyphs.html` | Brand |
| `guidelines/brand-voice.html` | Brand |
| `guidelines/brand-reference.html` | Brand |

### Assets
| Path | Contents |
|---|---|
| `assets/reference/` | Four user-provided JARVIS/FUI art-direction images |

### Other
| File | Purpose |
|---|---|
| `readme.md` | This file — design guide and manifest |
| `SKILL.md` | Agent skill definition for Claude Code |
